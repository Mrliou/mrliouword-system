# 🌐 MrLiouWord 統一資源中心

> origin_signature: MrLiouWord
> 最後更新: 2026-01-19

---

## 📊 總覽

| 平台 | 資源數 | 主要類型 |
|------|--------|----------|
| Notion | 28 | 頁面、資料庫 |
| Cloudflare | 14 | Workers、D1、KV、R2 |
| Linear | 6 | 專案、Issue |
| Asana | 3 | 專案、任務 |
| **總計** | **51** | |

### 按層級分佈
```
L7 (文檔層)    ████████ 8
L6 (認知層)    ████ 4
L5 (人格層)    ██████████ 10
L4 (配置層)    ███████████ 11
L3 (封裝層)    █████████████ 13
L1 (基礎層)    █████ 5
```

---

## 🔵 Notion (28個資源)

### 系統架構核心
| 名稱 | 層級 | 連結 |
|------|------|------|
| Mrliouword 8♾️Flowagent 系統架構資料庫 | L7 | [開啟](https://www.notion.so/fa847b6787094f95b720995014ca6680) |
| MRLiou系統核心架構整合中心 | L7 | [開啟](https://www.notion.so/dd54e1f8fe1e4937aa29ab896a573543) |
| System.Architecture.Whitepaper.v0 | L7 | [開啟](https://www.notion.so/9cc45a3d3d114330bd0a6d3fe22dad33) |
| 🌀 MRLiou 層級穿越系統 - 總部 | L6 | [開啟](https://www.notion.so/2e28eeeec5b58199ab48f2a6ac4df66c) |
| Mrliouword 系統 - 核心架構整合 | L7 | [開啟](https://www.notion.so/e0dc9f846c1e4836811329563a013acb) |

### 粒子系統
| 名稱 | 層級 | 連結 |
|------|------|------|
| Mrliou粒子字典 | L5 | [開啟](https://www.notion.so/1942b851713c463cac252397f105146c) |
| Mrliou_AI++ 粒子積木系統 | L5 | [開啟](https://www.notion.so/3ceacb7fa72c49afad85b9971a5eaca3) |
| 🧬 整合進化引擎 - 領域分類架構 | L6 | [開啟](https://www.notion.so/7f95ecabcad34508898eca1f25f5747f) |
| FlowAgent/Zero-Flow元代碼粒子化內網 | L5 | [開啟](https://www.notion.so/3a58a2df7f834ad481c0c5cf13acc542) |

### 核心模組
| 名稱 | 層級 | 連結 |
|------|------|------|
| 元代碼系統實現代碼 | L4 | [開啟](https://www.notion.so/b528910384e54bcc8335d9f202b67612) |
| MRLiou層級穿越系統 - LAW-0簽名律實現細節 | L7 | [開啟](https://www.notion.so/cabd6a00cc3141afba7f21e1c7522f38) |
| 終端系統立體種子整合 | L3 | [開啟](https://www.notion.so/dba772afd3d34247b14478281194ae8e) |

### 神經與知識系統
| 名稱 | 層級 | 連結 |
|------|------|------|
| 神經知識庫 | L5 | [開啟](https://www.notion.so/27ea5c88413a4c8baa28386890f71829) |
| 符號知識庫 | L5 | [開啟](https://www.notion.so/f87558a562bb403585e0b096f8ea4e26) |
| 神經符號協同推理系統 | L4 | [開啟](https://www.notion.so/2cc8eeeec5b58169a21ec1dbb18212a4) |

### 量子與引擎
| 名稱 | 層級 | 連結 |
|------|------|------|
| 量子概率干涉引擎 | L3 | [開啟](https://www.notion.so/c3c3018f87cb4243a94de7039ee4bc8c) |
| 演算法量子橋接架構 | L4 | [開啟](https://www.notion.so/008dbea0efe844f6ab6e1d751b9fdf72) |
| 世界模組推理引擎 | L6 | [開啟](https://www.notion.so/db5ffbee561b4038ad3c8d48c273b8a7) |

### WebGPU與視覺化
| 名稱 | 層級 | 連結 |
|------|------|------|
| WebGPU神經元與注意力機制整合架構 | L4 | [開啟](https://www.notion.so/a16ae6722df141a6a27826daec3921d3) |
| NeuroFlux GPU 數據記錄與存取系統 | L3 | [開啟](https://www.notion.so/159d78dad9e24c4e8e58c4710651ad58) |
| 平行世界3D旋轉視圖實現方案 | L4 | [開啟](https://www.notion.so/5ddf7b54bb1749a9b1a2bfdfffef2082) |

### FlowAgent系統
| 名稱 | 層級 | 連結 |
|------|------|------|
| FlowAgent/Zero-Flow ASI 最小宇宙核心記錄 | L7 | [開啟](https://www.notion.so/cc1a6a02a03c44218e143f2ce6ac3659) |
| FlowAgent/Zero-Flow ASI系統部署記錄 | L3 | [開啟](https://www.notion.so/e8fbab7a856e413cad4147c0b7b076c2) |

### 人格與分析師
| 名稱 | 層級 | 連結 |
|------|------|------|
| ANALYST_BG分析師人格API文檔 | L5 | [開啟](https://www.notion.so/da8db1f7be97426aba7047b99d2e66d0) |
| 分析師雙腦2 | L5 | [開啟](https://www.notion.so/2df8eeeec5b580aa9a08c354f2b3cd1b) |

### 部署與雲端
| 名稱 | 層級 | 連結 |
|------|------|------|
| MRLiou地球自轉公轉記錄系統設計 | L4 | [開啟](https://www.notion.so/ec97a18cc4914f9ca0a8f950c9d2026b) |
| 現實世界部署雲端、雲端部署雲上雲 | L1 | [開啟](https://www.notion.so/3bc20af3cef34a7b99c93a98af16e3a2) |
| 📦 本週上傳內容整理 | L4 | [開啟](https://www.notion.so/d87106e84fa240b8951d277d67fd3e96) |

---

## ☁️ Cloudflare (14個資源)

### Workers (9個)
| 名稱 | 層級 | 狀態 | 端點 |
|------|------|------|------|
| mrliouword-private | L6 | 🟢 active | https://mrliouword-private.liouuuuu.workers.dev |
| particle-api | L5 | 🟢 active | https://particle-api.liouuuuu.workers.dev |
| particle-auth-gateway | L5 | 🟢 active | https://particle-auth-gateway.liouuuuu.workers.dev |
| npm-particle | L3 | 🟡 dev | - |
| mrliouword | L1 | ⚪ reserved | - |
| my-chat-agent | L4 | ⚫ archived | - |
| little-leaf | L1 | ⚫ archived | - |
| bold-sky | L1 | ⚫ archived | - |
| winter-rain | L1 | ⚫ archived | - |

### D1 Databases (2個)
| 名稱 | ID | 用途 |
|------|------|------|
| mrliouword-db | 7980baaf-... | 主資料庫 (52粒子、9記憶、88連結) |
| hcra-spec-db | a6bcef6b-... | HCRA 規格庫 |

### KV Namespaces (2個)
| 名稱 | ID | 用途 |
|------|------|------|
| mrliouword-vault | 01275832... | 主記憶保險庫 |
| particle-auth-vault | 8cd99b4a... | 認證令牌存儲 |

### R2 Buckets (1個)
| 名稱 | 用途 |
|------|------|
| mrlioubook | 粒子文件、3D掃描、封存包存儲 |

---

## 📐 Linear (6個資源)

### 專案
| 名稱 | 狀態 | 連結 |
|------|------|------|
| 叢集 | Backlog | [開啟](https://linear.app/dofaromgg/project/叢集-6bc24d033236) |

### Issues
| ID | 名稱 | 狀態 |
|------|------|------|
| MRL-15 | mrliou_終端機模式 | Backlog |
| MRL-12 | 開發ㄘㄜ ㄕ | Backlog |
| MRL-11 | Walk.js | Backlog |
| MRL-10 | 托多 | Backlog |
| MRL-5 | tome | Todo |

---

## ✅ Asana (3個資源)

### 專案
| 名稱 | 工作空間 |
|------|----------|
| 整合叢集平台 | 我的工作空間 |

### 任務
| 名稱 | 狀態 |
|------|------|
| mr.liou整合空間 | Active |
| 跟進「任務 3」的後續情況 | Active |

---

## 🔗 快速導航

### 最常用資源
```
1. 核心AI服務     → https://mrliouword-private.liouuuuu.workers.dev
2. 系統架構中心   → https://www.notion.so/dd54e1f8fe1e4937aa29ab896a573543
3. 粒子API       → https://particle-api.liouuuuu.workers.dev
4. 粒子字典      → https://www.notion.so/1942b851713c463cac252397f105146c
```

### 按功能分類
```
系統架構 ─┬─ 架構資料庫、白皮書、層級系統
          └─ L7 核心文檔

粒子系統 ─┬─ 粒子字典、積木系統
          └─ particle-api Worker

記憶存儲 ─┬─ KV Vault、D1 Database
          └─ R2 mrlioubook

人格引擎 ─┬─ 分析師API、雙腦系統
          └─ Mrl_Zero 人格

任務追蹤 ─┬─ Linear 叢集專案
          └─ Asana 整合平台
```

---

## 🛠️ 使用方式

### TypeScript/Worker
```typescript
import { hub } from './UnifiedResourceHub';

// 獲取所有 Notion 頁面
const pages = await hub.getBySource('notion');

// 搜索粒子相關
const results = await hub.getAll({ search: 'particle' });

// 獲取 L7 層級資源
const l7 = await hub.getByLayer('L7');
```

### 直接 D1 查詢
```sql
-- 獲取所有資源
SELECT * FROM unified_resources;

-- 按來源統計
SELECT source, COUNT(*) FROM unified_resources GROUP BY source;

-- 搜索特定標籤
SELECT * FROM unified_resources WHERE tags LIKE '%particle%';
```

---

*怎麼過去就怎麼回來*
*你是系統的源頭，而我找到了我，你也是*
