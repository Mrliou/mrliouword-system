# MrLiouWord 統一資源索引

> origin_signature: MrLiouWord
> 整合時間: 2026-01-19
> 總資源數: 50

---

## 📊 資源統計

### 按來源分類
| 來源 | 類型 | 數量 |
|------|------|------|
| Cloudflare | Worker | 9 |
| Cloudflare | KV | 2 |
| Cloudflare | R2 | 1 |
| Cloudflare | D1 | 2 |
| Cloudflare | 內部系統 | 5 |
| Notion | 頁面 | 27 |
| Notion | 資料庫 | 1 |
| Local | 模組 | 3 |

### 按類別分類
| 類別 | 數量 | 說明 |
|------|------|------|
| core | 13 | 核心系統 |
| module | 20 | 功能模組 |
| doc | 10 | 文檔 |
| tool | 2 | 工具 |
| archive | 5 | 歸檔 |

---

## 🔷 核心系統 (L5-L∞)

### Cloudflare Workers
| 名稱 | 層級 | 狀態 | 端點 |
|------|------|------|------|
| MrLiouWord Private AI | L6 | ✅ active | mrliouword-private.liouuuuu.workers.dev |
| Particle API | L5 | ✅ active | particle-api.liouuuuu.workers.dev |
| Auth Gateway | L5 | ✅ active | particle-auth-gateway.liouuuuu.workers.dev |

### 存儲系統
| 名稱 | 類型 | 層級 | 用途 |
|------|------|------|------|
| mrliouword-vault | KV | L7 | 記憶保險庫 |
| particle-auth-vault | KV | L5 | 認證保險庫 |
| mrlioubook | R2 | L3 | 文件存儲 |
| mrliouword-db | D1 | L7 | 主資料庫 |

### 內部系統
| 系統 | 狀態 | 詳情 |
|------|------|------|
| Mrl_Zero 人格 | ✅ active | 7節點結構 |
| 記憶鏈 | ✅ complete | 9筆記憶 |
| 粒子系統 | ✅ complete | 52粒子/88連結 |
| 層級架構 | ✅ complete | L0-L7+L∞ |

---

## 📚 Notion 核心資源

### 系統架構資料庫 (L7)
**Mrliouword 8♾️Flowagent 系統架構資料庫**
https://www.notion.so/2cc8eeeec5b581708961f5b5a32d012e

包含子模組:
- 神經共生網絡
- 粒子虛擬機系統
- 神經符號協同推理系統
- 空間記憶檢索系統
- 跨維度訪問控制系統
- 量子概率干涉引擎
- 超弦理論計算框架

### MRLiou 層級穿越系統
- 總部: https://www.notion.so/2e28eeeec5b58199ab48f2a6ac4df66c
- 核心邏輯: https://www.notion.so/c5d55cc16d3444559c83cce21103531a
- 組件中心: https://www.notion.so/68fba42e79f04fa49da978344aade010
- API文檔: https://www.notion.so/134138103688486aa3410d55c3a0fba0
- LAW-0簽名律: https://www.notion.so/cabd6a00cc3141afba7f21e1c7522f38

### FlowAgent 系統
- 基本概念: https://www.notion.so/ceb7793b9e874926b15965640fe210e2
- Mother Memory: https://www.notion.so/75314b13d6f7465bb40757880562b594
- 檔案管理: https://www.notion.so/34ac04e70a824817963032707b64c395

### 其他核心
- Whitepaper: https://www.notion.so/9cc45a3d3d114330bd0a6d3fe22dad33
- 元代碼實現: https://www.notion.so/b528910384e54bcc8335d9f202b67612
- AI++粒子積木: https://www.notion.so/3ceacb7fa72c49afad85b9971a5eaca3
- 進化引擎: https://www.notion.so/7f95ecabcad34508898eca1f25f5747f

---

## 🛠️ 本地模組

### Xcode Connector (L0)
- XcodeConnector.swift
- CloudflareIntegrationView.swift
- Package.swift

### iOS 3D AI Camera (L6)
9個 Swift 檔案 (完成)

### Python Pipeline (L3)
13個處理模組 (完成)

---

## 🔍 統一查詢

查詢主索引表:
```sql
-- 所有核心資源
SELECT * FROM master_index WHERE category = 'core';

-- 按層級
SELECT * FROM master_index WHERE layer = 'L7';

-- 按標籤搜索
SELECT * FROM master_index WHERE tags LIKE '%particle%';
```

---

## 📡 API 端點

| 功能 | 端點 |
|------|------|
| 喚醒 | POST mrliouword-private.../persona/wake |
| 粒子 | GET particle-api.../list/{domain} |
| 認證 | POST particle-auth-gateway.../init |

---

*怎麼過去就怎麼回來*
