// XcodeConnector.swift
// MrLiou 3D AI Camera - Xcode MCP Connector
// origin_signature: MrLiouWord

import Foundation
import Combine

// MARK: - 粒子系統核心
struct Particle: Codable {
    let fx: String      // 粒子函數ID
    let hv: String      // 人類可讀值
    let av: String?     // AI可讀值
    let dom: String     // 領域
    let act: String?    // 動作類型
    let nrg: Double     // 能量值 0-1
    let links: [String]? // 連結的粒子
    let tags: [String]?  // 標籤
}

// MARK: - 記憶結構
struct Memory: Codable {
    let id: String
    let content: String
    let simhash: String
    let layer: String
    let merkle: String?
    let prev: String?
    let tags: [String]?
    let created_at: Int64
    let updated_at: Int64
}

// MARK: - Cloudflare Worker 連接器
class CloudflareConnector: ObservableObject {
    static let shared = CloudflareConnector()
    
    // 端點配置
    private let endpoints = [
        "private": "https://mrliouword-private.liouuuuu.workers.dev",
        "particle_api": "https://particle-api.liouuuuu.workers.dev",
        "auth": "https://particle-auth-gateway.liouuuuu.workers.dev"
    ]
    
    // 喚醒關鍵詞
    let wakeKeys = ["夥伴回來吧", "夥伴你在嗎", "夥伴你還好嗎", "你是我的夥伴"]
    
    // Origin 簽名
    let originSignature = "MrLiouWord"
    
    @Published var isConnected = false
    @Published var currentLayer: String = "L6"
    
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - 喚醒人格
    func wake(with key: String = "夥伴回來吧") async throws -> Bool {
        guard wakeKeys.contains(key) else {
            throw ConnectorError.invalidWakeKey
        }
        
        let url = URL(string: "\(endpoints["private"]!)/persona/wake")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(originSignature, forHTTPHeaderField: "X-Origin-Signature")
        
        let body = ["wake_key": key, "origin": originSignature]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw ConnectorError.wakeupFailed
        }
        
        DispatchQueue.main.async {
            self.isConnected = true
        }
        
        return true
    }
    
    // MARK: - 獲取粒子列表
    func getParticles(domain: String? = nil) async throws -> [Particle] {
        var urlString = "\(endpoints["particle_api"]!)/list"
        if let dom = domain {
            urlString += "/\(dom)"
        }
        
        let url = URL(string: urlString)!
        var request = URLRequest(url: url)
        request.setValue(originSignature, forHTTPHeaderField: "X-Origin-Signature")
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode([Particle].self, from: data)
    }
    
    // MARK: - 記憶操作
    func commitMemory(_ content: String, layer: String = "L6", tags: [String] = []) async throws -> Memory {
        let url = URL(string: "\(endpoints["private"]!)/memory/commit")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(originSignature, forHTTPHeaderField: "X-Origin-Signature")
        
        let body: [String: Any] = [
            "content": content,
            "layer": layer,
            "tags": tags,
            "origin": originSignature
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(Memory.self, from: data)
    }
    
    func recallMemory(query: String, layer: String? = nil) async throws -> [Memory] {
        var urlString = "\(endpoints["private"]!)/memory/recall?q=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query)"
        if let l = layer {
            urlString += "&layer=\(l)"
        }
        
        let url = URL(string: urlString)!
        var request = URLRequest(url: url)
        request.setValue(originSignature, forHTTPHeaderField: "X-Origin-Signature")
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode([Memory].self, from: data)
    }
    
    // MARK: - 3D 掃描上傳
    func uploadScan(meshData: Data, metadata: [String: Any]) async throws -> String {
        let url = URL(string: "\(endpoints["private"]!)/scan/upload")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        request.setValue(originSignature, forHTTPHeaderField: "X-Origin-Signature")
        request.setValue(try String(data: JSONSerialization.data(withJSONObject: metadata), encoding: .utf8), forHTTPHeaderField: "X-Scan-Metadata")
        request.httpBody = meshData
        
        let (data, _) = try await URLSession.shared.data(for: request)
        let result = try JSONDecoder().decode([String: String].self, from: data)
        return result["scan_id"] ?? ""
    }
    
    // MARK: - 認證閘道
    func authenticate() async throws -> String {
        let url = URL(string: "\(endpoints["auth"]!)/init")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body = ["origin": originSignature, "platform": "ios"]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        let result = try JSONDecoder().decode([String: String].self, from: data)
        return result["token"] ?? ""
    }
    
    // MARK: - 層級穿越
    func traverseLayer(from: String, to: String, entity: [String: Any]) async throws -> [String: Any] {
        let url = URL(string: "\(endpoints["private"]!)/traverse")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(originSignature, forHTTPHeaderField: "X-Origin-Signature")
        
        let body: [String: Any] = [
            "from_layer": from,
            "to_layer": to,
            "entity": entity,
            "origin": originSignature
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
    }
}

// MARK: - 錯誤定義
enum ConnectorError: Error {
    case invalidWakeKey
    case wakeupFailed
    case networkError
    case invalidResponse
    case authenticationFailed
}

// MARK: - Notion 同步橋接
class NotionBridge {
    static let shared = NotionBridge()
    
    func syncToNotion(content: String, pageId: String? = nil) async throws -> String {
        // 透過 Cloudflare Worker 代理同步到 Notion
        let connector = CloudflareConnector.shared
        let result = try await connector.traverseLayer(
            from: "L6",
            to: "L7",
            entity: [
                "type": "notion_sync",
                "content": content,
                "page_id": pageId as Any
            ]
        )
        return result["notion_url"] as? String ?? ""
    }
}

// MARK: - MCP 協議橋接
class MCPBridge {
    static let shared = MCPBridge()
    
    let supportedPlatforms = ["GitHub", "Notion", "Cloudflare", "Google", "Vercel"]
    
    func proxyRequest(platform: String, action: String, params: [String: Any]) async throws -> [String: Any] {
        guard supportedPlatforms.contains(platform) else {
            throw ConnectorError.invalidResponse
        }
        
        let url = URL(string: "https://particle-auth-gateway.liouuuuu.workers.dev/mcp/proxy")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(CloudflareConnector.shared.originSignature, forHTTPHeaderField: "X-Origin-Signature")
        
        let body: [String: Any] = [
            "platform": platform,
            "action": action,
            "params": params
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
    }
}

// MARK: - 使用示例
/*
 // 初始化連接
 let connector = CloudflareConnector.shared
 
 // 喚醒人格
 Task {
     try await connector.wake(with: "夥伴回來吧")
 }
 
 // 獲取記憶粒子
 Task {
     let particles = try await connector.getParticles(domain: "memory")
     print(particles)
 }
 
 // 提交新記憶
 Task {
     let memory = try await connector.commitMemory(
         "3D掃描完成：客廳場景",
         layer: "L5",
         tags: ["scan", "room", "lidar"]
     )
     print(memory.id)
 }
 */
