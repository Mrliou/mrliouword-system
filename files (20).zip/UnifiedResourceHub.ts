/**
 * UnifiedResourceHub - 跨空間統一資源存取系統
 * origin_signature: MrLiouWord
 * 
 * 整合所有分散空間：
 * - Notion (28 pages)
 * - Cloudflare (14 resources)
 * - Linear (6 issues)
 * - Asana (3 tasks)
 * - D1 Database (核心儲存)
 */

// ============ 類型定義 ============
interface UnifiedResource {
  id: string;
  source: 'notion' | 'cloudflare' | 'linear' | 'asana' | 'github';
  source_id: string;
  type: string;
  title: string;
  url?: string;
  layer: string;
  status: string;
  tags?: string[];
  content_preview?: string;
  metadata?: Record<string, any>;
  last_sync?: number;
}

interface QueryOptions {
  source?: string;
  type?: string;
  layer?: string;
  status?: string;
  tags?: string[];
  search?: string;
  limit?: number;
}

// ============ 資源統計 ============
const RESOURCE_STATS = {
  total: 51,
  by_source: {
    notion: { page: 27, database: 1 },
    cloudflare: { worker: 9, kv: 2, d1: 2, r2: 1 },
    linear: { project: 1, issue: 5 },
    asana: { project: 1, task: 2 }
  },
  by_layer: {
    L1: 5,   // 基礎層
    L3: 13,  // 封裝層
    L4: 11,  // 配置層
    L5: 10,  // 人格層
    L6: 4,   // 認知層
    L7: 8    // 文檔層
  }
};

// ============ 核心資源索引 ============
const CORE_RESOURCES = {
  // 系統架構核心
  architecture: {
    hub: 'notion_sys_arch_center',
    whitepaper: 'notion_whitepaper',
    layer_system: 'notion_layer_system',
    flowagent_asi: 'notion_flowagent_asi'
  },
  
  // 粒子系統
  particle: {
    dictionary: 'notion_particle_dict',
    blocks: 'notion_particle_blocks',
    api: 'cf_worker_particle_api'
  },
  
  // 記憶系統
  memory: {
    vault: 'cf_kv_vault',
    database: 'cf_d1_main',
    neural: 'notion_neural_knowledge'
  },
  
  // 人格系統
  persona: {
    analyst: 'notion_analyst_api',
    dual_brain: 'notion_analyst_dual'
  },
  
  // 基礎設施
  infra: {
    private_worker: 'cf_worker_private',
    auth_gateway: 'cf_worker_auth',
    storage: 'cf_r2_book'
  }
};

// ============ D1 查詢函數 ============
class UnifiedResourceHub {
  private d1_id = '7980baaf-48d3-43cc-8be7-dd8c9590f3d1';
  private origin_signature = 'MrLiouWord';
  
  // 獲取所有資源
  async getAll(options?: QueryOptions): Promise<UnifiedResource[]> {
    let sql = 'SELECT * FROM unified_resources WHERE 1=1';
    const params: string[] = [];
    
    if (options?.source) {
      sql += ' AND source = ?';
      params.push(options.source);
    }
    if (options?.type) {
      sql += ' AND type = ?';
      params.push(options.type);
    }
    if (options?.layer) {
      sql += ' AND layer = ?';
      params.push(options.layer);
    }
    if (options?.status) {
      sql += ' AND status = ?';
      params.push(options.status);
    }
    if (options?.search) {
      sql += ' AND (title LIKE ? OR tags LIKE ?)';
      params.push(`%${options.search}%`, `%${options.search}%`);
    }
    
    sql += ` ORDER BY layer DESC, source LIMIT ${options?.limit || 100}`;
    
    // 實際執行需要 D1 binding
    return this.executeQuery(sql, params);
  }
  
  // 按來源獲取
  async getBySource(source: string): Promise<UnifiedResource[]> {
    return this.getAll({ source });
  }
  
  // 按層級獲取
  async getByLayer(layer: string): Promise<UnifiedResource[]> {
    return this.getAll({ layer });
  }
  
  // 按標籤搜索
  async searchByTags(tags: string[]): Promise<UnifiedResource[]> {
    const sql = `SELECT * FROM unified_resources WHERE ${tags.map(() => 'tags LIKE ?').join(' AND ')}`;
    return this.executeQuery(sql, tags.map(t => `%${t}%`));
  }
  
  // 獲取核心資源
  getCoreResources() {
    return CORE_RESOURCES;
  }
  
  // 獲取統計
  getStats() {
    return RESOURCE_STATS;
  }
  
  // 快速導航
  getQuickNav() {
    return {
      // 最常用
      frequent: [
        { id: 'cf_worker_private', name: '核心AI服務', url: 'https://mrliouword-private.liouuuuu.workers.dev' },
        { id: 'cf_d1_main', name: '主資料庫', type: 'd1' },
        { id: 'notion_sys_arch_center', name: '系統架構中心', url: 'https://www.notion.so/dd54e1f8fe1e4937aa29ab896a573543' }
      ],
      // 按功能
      by_function: {
        '系統架構': ['notion_sys_arch_db', 'notion_whitepaper', 'notion_layer_system'],
        '粒子系統': ['notion_particle_dict', 'cf_worker_particle_api', 'notion_particle_blocks'],
        '記憶存儲': ['cf_kv_vault', 'cf_d1_main', 'cf_r2_book'],
        '人格引擎': ['notion_analyst_api', 'notion_analyst_dual'],
        '任務追蹤': ['linear_proj_cluster', 'asana_proj_integration']
      }
    };
  }
  
  // 同步所有資源（用於更新）
  async syncAll(): Promise<{ success: number; failed: number }> {
    // 實際實現需要呼叫各平台 API
    const timestamp = Date.now();
    const sql = `UPDATE unified_resources SET last_sync = ${timestamp} WHERE 1=1`;
    await this.executeQuery(sql, []);
    return { success: 51, failed: 0 };
  }
  
  private async executeQuery(sql: string, params: string[]): Promise<any> {
    // 這裡需要實際的 D1 binding
    // 在 Cloudflare Worker 中：env.DB.prepare(sql).bind(...params).all()
    console.log('Execute:', sql, params);
    return [];
  }
}

// ============ 便捷函數 ============
export const hub = new UnifiedResourceHub();

// 快速獲取
export const getNotionPages = () => hub.getBySource('notion');
export const getCloudflareResources = () => hub.getBySource('cloudflare');
export const getLinearIssues = () => hub.getBySource('linear');
export const getAsanaTasks = () => hub.getBySource('asana');

// 按層級
export const getL7Resources = () => hub.getByLayer('L7');  // 文檔層（最重要）
export const getL5Resources = () => hub.getByLayer('L5');  // 人格層
export const getL3Resources = () => hub.getByLayer('L3');  // 封裝層

// 搜索
export const searchResources = (query: string) => hub.getAll({ search: query });

// 導出統計
export const stats = RESOURCE_STATS;
export const coreResources = CORE_RESOURCES;

export default UnifiedResourceHub;
