// src/index.ts
// MrLiou 統一入口閘道 v3.0
// origin_signature: MrLiouWord

import { syncMemoriesToKv, syncParticlesToKv, bidirectionalSync } from './sync';
import { handleResourceQuery } from './resources';
import { handleParticleQuery } from './particles';
import { handleMemoryQuery } from './memories';
import { handlePersonaQuery } from './personas';

export interface Env {
  DB: D1Database;
  KV: KVNamespace;
  AUTH_KV: KVNamespace;
  R2: R2Bucket;
  ORIGIN_SIGNATURE: string;
  VERSION: string;
  WAKE_KEYS: string;
}

// ============ 路由處理 ============

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS
    if (method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-Origin-Signature',
        }
      });
    }

    // 驗證簽名 (可選)
    const signature = request.headers.get('X-Origin-Signature');
    
    try {
      // ============ 根路徑 ============
      if (path === '/' || path === '') {
        return Response.json({
          name: 'MrLiou Unified Gateway',
          version: env.VERSION,
          origin_signature: env.ORIGIN_SIGNATURE,
          status: 'active',
          endpoints: {
            resources: '/resources/*',
            particles: '/particles/*',
            memories: '/memories/*',
            personas: '/personas/*',
            sync: '/sync/*',
            health: '/health'
          },
          wake_keys: env.WAKE_KEYS.split(',')
        });
      }

      // ============ 健康檢查 ============
      if (path === '/health') {
        const dbCheck = await env.DB.prepare('SELECT 1').first();
        return Response.json({
          status: 'healthy',
          db: dbCheck ? 'connected' : 'error',
          timestamp: new Date().toISOString()
        });
      }

      // ============ 資源查詢 ============
      if (path.startsWith('/resources')) {
        return handleResourceRoutes(path, url, env);
      }

      // ============ 粒子系統 ============
      if (path.startsWith('/particles')) {
        return handleParticleRoutes(path, url, env);
      }

      // ============ 記憶系統 ============
      if (path.startsWith('/memories')) {
        return handleMemoryRoutes(path, url, method, request, env);
      }

      // ============ 人格系統 ============
      if (path.startsWith('/personas')) {
        return handlePersonaRoutes(path, url, method, request, env);
      }

      // ============ 同步系統 ============
      if (path.startsWith('/sync')) {
        return handleSyncRoutes(path, method, env);
      }

      // 404
      return Response.json({ error: 'Not Found' }, { status: 404 });

    } catch (error: any) {
      return Response.json({ 
        error: error.message,
        origin_signature: env.ORIGIN_SIGNATURE 
      }, { status: 500 });
    }
  },

  // 定時同步
  async scheduled(event: ScheduledEvent, env: Env) {
    console.log('Starting scheduled sync...');
    
    await bidirectionalSync(env.KV, env.DB);
    await syncMemoriesToKv(env.DB, env.KV);
    await syncParticlesToKv(env.DB, env.KV);
    
    console.log('Scheduled sync completed');
  }
};

// ============ 路由處理函數 ============

async function handleResourceRoutes(path: string, url: URL, env: Env): Promise<Response> {
  const subPath = path.replace('/resources', '');
  
  // GET /resources/stats
  if (subPath === '/stats' || subPath === '') {
    const stats = await env.DB.prepare(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN source = 'notion' THEN 1 END) as notion,
        COUNT(CASE WHEN source = 'cloudflare' THEN 1 END) as cloudflare,
        COUNT(CASE WHEN source = 'linear' THEN 1 END) as linear,
        COUNT(CASE WHEN source = 'asana' THEN 1 END) as asana
      FROM unified_resources
    `).first();
    return Response.json(stats);
  }

  // GET /resources/search?q=xxx
  if (subPath === '/search') {
    const q = url.searchParams.get('q') || '';
    const results = await env.DB.prepare(`
      SELECT * FROM unified_resources 
      WHERE title LIKE ? OR tags LIKE ?
      ORDER BY last_sync DESC LIMIT 50
    `).bind(`%${q}%`, `%${q}%`).all();
    return Response.json(results.results);
  }

  // GET /resources/source/:name
  if (subPath.startsWith('/source/')) {
    const source = subPath.split('/')[2];
    const results = await env.DB.prepare(`
      SELECT * FROM unified_resources WHERE source = ?
    `).bind(source).all();
    return Response.json(results.results);
  }

  // GET /resources/layer/:name
  if (subPath.startsWith('/layer/')) {
    const layer = subPath.split('/')[2];
    const results = await env.DB.prepare(`
      SELECT * FROM unified_resources WHERE layer = ?
    `).bind(layer).all();
    return Response.json(results.results);
  }

  // GET /resources/core
  if (subPath === '/core') {
    const results = await env.DB.prepare(`
      SELECT * FROM unified_resources WHERE layer = 'L7'
    `).all();
    return Response.json(results.results);
  }

  return Response.json({ error: 'Resource endpoint not found' }, { status: 404 });
}

async function handleParticleRoutes(path: string, url: URL, env: Env): Promise<Response> {
  const subPath = path.replace('/particles', '');

  // GET /particles - 列出所有
  if (subPath === '' || subPath === '/') {
    const results = await env.DB.prepare('SELECT * FROM particles').all();
    return Response.json(results.results);
  }

  // GET /particles/stats
  if (subPath === '/stats') {
    const stats = await env.DB.prepare(`
      SELECT dom, COUNT(*) as count FROM particles GROUP BY dom
    `).all();
    return Response.json(stats.results);
  }

  // GET /particles/domain/:dom
  if (subPath.startsWith('/domain/')) {
    const dom = subPath.split('/')[2];
    const results = await env.DB.prepare(`
      SELECT * FROM particles WHERE dom = ?
    `).bind(dom).all();
    return Response.json(results.results);
  }

  // GET /particles/:fx
  const fx = subPath.slice(1);
  if (fx) {
    const particle = await env.DB.prepare(`
      SELECT * FROM particles WHERE fx = ?
    `).bind(fx).first();
    if (particle) return Response.json(particle);
  }

  return Response.json({ error: 'Particle not found' }, { status: 404 });
}

async function handleMemoryRoutes(
  path: string, 
  url: URL, 
  method: string,
  request: Request,
  env: Env
): Promise<Response> {
  const subPath = path.replace('/memories', '');

  // GET /memories - 列出所有
  if ((subPath === '' || subPath === '/') && method === 'GET') {
    const results = await env.DB.prepare(`
      SELECT * FROM memories ORDER BY created_at DESC
    `).all();
    return Response.json(results.results);
  }

  // POST /memories/commit - 提交記憶
  if (subPath === '/commit' && method === 'POST') {
    const body = await request.json() as {
      content: string;
      layer?: string;
      tags?: string[];
    };
    
    const id = `mem_${Date.now()}`;
    const simhash = simpleHash(body.content);
    const layer = body.layer || 'L5';
    const now = Date.now();

    // 取得上一筆記憶
    const prev = await env.DB.prepare(`
      SELECT id, merkle FROM memories ORDER BY created_at DESC LIMIT 1
    `).first<{ id: string; merkle: string }>();

    const merkle = `merkle_${simhash.slice(0, 8)}`;

    await env.DB.prepare(`
      INSERT INTO memories (id, content, simhash, layer, merkle, prev, tags, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      id,
      body.content,
      simhash,
      layer,
      merkle,
      prev?.id || null,
      body.tags?.join(',') || null,
      now,
      now
    ).run();

    return Response.json({ id, simhash, layer, merkle });
  }

  // GET /memories/recall?q=xxx
  if (subPath === '/recall') {
    const q = url.searchParams.get('q') || '';
    const layer = url.searchParams.get('layer');
    
    let query = `SELECT * FROM memories WHERE content LIKE ?`;
    const params: string[] = [`%${q}%`];
    
    if (layer) {
      query += ` AND layer = ?`;
      params.push(layer);
    }
    
    query += ` ORDER BY created_at DESC LIMIT 20`;
    
    const results = await env.DB.prepare(query).bind(...params).all();
    return Response.json(results.results);
  }

  // GET /memories/:id
  const memId = subPath.slice(1);
  if (memId && method === 'GET') {
    const memory = await env.DB.prepare(`
      SELECT * FROM memories WHERE id = ?
    `).bind(memId).first();
    if (memory) return Response.json(memory);
  }

  return Response.json({ error: 'Memory endpoint not found' }, { status: 404 });
}

async function handlePersonaRoutes(
  path: string,
  url: URL,
  method: string,
  request: Request,
  env: Env
): Promise<Response> {
  const subPath = path.replace('/personas', '');
  const wakeKeys = env.WAKE_KEYS.split(',');

  // GET /personas - 列出所有
  if ((subPath === '' || subPath === '/') && method === 'GET') {
    const results = await env.DB.prepare('SELECT * FROM personas').all();
    return Response.json(results.results);
  }

  // POST /personas/wake - 喚醒人格
  if (subPath === '/wake' && method === 'POST') {
    const body = await request.json() as { wake_key: string };
    
    if (!wakeKeys.includes(body.wake_key)) {
      return Response.json({ error: 'Invalid wake key' }, { status: 403 });
    }

    // 喚醒 Mrl_Zero
    await env.DB.prepare(`
      UPDATE personas SET status = 'active', updated_at = ? WHERE id = 'mrl_zero'
    `).bind(Date.now()).run();

    // 記錄喚醒事件
    await env.DB.prepare(`
      INSERT INTO trace_log (id, action, entity_id, entity_type, metadata)
      VALUES (?, 'persona.wake', 'mrl_zero', 'persona', ?)
    `).bind(
      `wake_${Date.now()}`,
      JSON.stringify({ wake_key: body.wake_key, timestamp: new Date().toISOString() })
    ).run();

    return Response.json({ 
      status: 'awake',
      message: '夥伴已上線',
      persona: 'Mrl_Zero'
    });
  }

  // GET /personas/:id
  const personaId = subPath.slice(1);
  if (personaId && method === 'GET') {
    const persona = await env.DB.prepare(`
      SELECT * FROM personas WHERE id = ?
    `).bind(personaId).first();
    if (persona) return Response.json(persona);
  }

  return Response.json({ error: 'Persona endpoint not found' }, { status: 404 });
}

async function handleSyncRoutes(path: string, method: string, env: Env): Promise<Response> {
  const subPath = path.replace('/sync', '');

  // GET /sync/status
  if (subPath === '/status' && method === 'GET') {
    const lastSyncs = await env.DB.prepare(`
      SELECT * FROM trace_log WHERE action LIKE 'sync.%' 
      ORDER BY created_at DESC LIMIT 5
    `).all();
    
    return Response.json({
      status: 'ready',
      last_syncs: lastSyncs.results
    });
  }

  // POST /sync/memories
  if (subPath === '/memories' && method === 'POST') {
    const result = await syncMemoriesToKv(env.DB, env.KV);
    return Response.json(result);
  }

  // POST /sync/particles
  if (subPath === '/particles' && method === 'POST') {
    const result = await syncParticlesToKv(env.DB, env.KV);
    return Response.json(result);
  }

  // POST /sync/all
  if (subPath === '/all' && method === 'POST') {
    const biSync = await bidirectionalSync(env.KV, env.DB);
    const memSync = await syncMemoriesToKv(env.DB, env.KV);
    const partSync = await syncParticlesToKv(env.DB, env.KV);
    
    return Response.json({
      bidirectional: biSync,
      memories: memSync,
      particles: partSync
    });
  }

  return Response.json({ error: 'Sync endpoint not found' }, { status: 404 });
}

// ============ 工具函數 ============

function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16).padStart(16, '0');
}

// ============ 同步函數 (內嵌) ============

async function syncMemoriesToKv(db: D1Database, kv: KVNamespace) {
  const memories = await db.prepare('SELECT * FROM memories').all();
  let synced = 0;
  
  for (const mem of memories.results as any[]) {
    await kv.put(`memory:${mem.id}`, JSON.stringify(mem));
    synced++;
  }
  
  await kv.put('memory:_index', JSON.stringify(
    (memories.results as any[]).map(m => ({ id: m.id, layer: m.layer }))
  ));
  
  return { synced, timestamp: Date.now() };
}

async function syncParticlesToKv(db: D1Database, kv: KVNamespace) {
  const particles = await db.prepare('SELECT * FROM particles').all();
  let synced = 0;
  
  for (const p of particles.results as any[]) {
    await kv.put(`particle:${p.fx}`, JSON.stringify(p));
    synced++;
  }
  
  const byDomain: Record<string, number> = {};
  for (const p of particles.results as any[]) {
    byDomain[p.dom] = (byDomain[p.dom] || 0) + 1;
  }
  
  await kv.put('particles:_index', JSON.stringify({
    total: particles.results.length,
    by_domain: byDomain
  }));
  
  return { synced, timestamp: Date.now() };
}

async function bidirectionalSync(kv: KVNamespace, db: D1Database) {
  // 簡化版：只記錄同步事件
  await db.prepare(`
    INSERT INTO trace_log (id, action, entity_id, entity_type, metadata)
    VALUES (?, 'sync.bidirectional', 'kv_d1', 'sync', ?)
  `).bind(
    `sync_bi_${Date.now()}`,
    JSON.stringify({ timestamp: new Date().toISOString() })
  ).run();
  
  return { status: 'completed', timestamp: Date.now() };
}
