// unified-resource-hub.ts
// MrLiou 統一資源整合中心
// origin_signature: MrLiouWord

/**
 * 統一資源整合中心
 * 一次存取所有空間的檔案與記憶
 */

export interface UnifiedResource {
  id: string;
  source: 'notion' | 'cloudflare' | 'linear' | 'asana' | 'github' | 'google_drive';
  source_id: string;
  type: string;
  title: string;
  url?: string;
  layer: string;
  status: string;
  tags?: string[];
  content_preview?: string;
  last_sync: number;
  metadata?: Record<string, any>;
}

export interface ResourceStats {
  total: number;
  by_source: Record<string, number>;
  by_type: Record<string, number>;
  by_layer: Record<string, number>;
}

// ============ 統一資源查詢 ============

/**
 * 取得所有資源統計
 */
export async function getResourceStats(db: D1Database): Promise<ResourceStats> {
  const [total, bySource, byType, byLayer] = await Promise.all([
    db.prepare('SELECT COUNT(*) as count FROM unified_resources').first<{count: number}>(),
    db.prepare('SELECT source, COUNT(*) as count FROM unified_resources GROUP BY source').all(),
    db.prepare('SELECT type, COUNT(*) as count FROM unified_resources GROUP BY type').all(),
    db.prepare('SELECT layer, COUNT(*) as count FROM unified_resources GROUP BY layer').all(),
  ]);

  return {
    total: total?.count || 0,
    by_source: Object.fromEntries(bySource.results.map((r: any) => [r.source, r.count])),
    by_type: Object.fromEntries(byType.results.map((r: any) => [r.type, r.count])),
    by_layer: Object.fromEntries(byLayer.results.map((r: any) => [r.layer, r.count])),
  };
}

/**
 * 依來源查詢資源
 */
export async function getResourcesBySource(
  db: D1Database,
  source: string
): Promise<UnifiedResource[]> {
  const result = await db
    .prepare('SELECT * FROM unified_resources WHERE source = ? ORDER BY last_sync DESC')
    .bind(source)
    .all();
  return result.results as UnifiedResource[];
}

/**
 * 依層級查詢資源
 */
export async function getResourcesByLayer(
  db: D1Database,
  layer: string
): Promise<UnifiedResource[]> {
  const result = await db
    .prepare('SELECT * FROM unified_resources WHERE layer = ? ORDER BY source, title')
    .bind(layer)
    .all();
  return result.results as UnifiedResource[];
}

/**
 * 依標籤搜尋資源
 */
export async function searchResourcesByTags(
  db: D1Database,
  tags: string[]
): Promise<UnifiedResource[]> {
  const conditions = tags.map(() => "tags LIKE ?").join(' OR ');
  const params = tags.map(t => `%${t}%`);
  
  const result = await db
    .prepare(`SELECT * FROM unified_resources WHERE ${conditions} ORDER BY last_sync DESC`)
    .bind(...params)
    .all();
  return result.results as UnifiedResource[];
}

/**
 * 全文搜尋
 */
export async function searchResources(
  db: D1Database,
  query: string
): Promise<UnifiedResource[]> {
  const result = await db
    .prepare(`
      SELECT * FROM unified_resources 
      WHERE title LIKE ? OR tags LIKE ? OR content_preview LIKE ?
      ORDER BY last_sync DESC
      LIMIT 50
    `)
    .bind(`%${query}%`, `%${query}%`, `%${query}%`)
    .all();
  return result.results as UnifiedResource[];
}

// ============ 快速存取點 ============

/**
 * 取得核心資源 (L7層)
 */
export async function getCoreResources(db: D1Database): Promise<UnifiedResource[]> {
  return getResourcesByLayer(db, 'L7');
}

/**
 * 取得所有 Notion 頁面
 */
export async function getNotionPages(db: D1Database): Promise<UnifiedResource[]> {
  return getResourcesBySource(db, 'notion');
}

/**
 * 取得所有 Cloudflare 服務
 */
export async function getCloudflareServices(db: D1Database): Promise<UnifiedResource[]> {
  return getResourcesBySource(db, 'cloudflare');
}

/**
 * 取得所有任務 (Linear + Asana)
 */
export async function getAllTasks(db: D1Database): Promise<UnifiedResource[]> {
  const result = await db
    .prepare(`
      SELECT * FROM unified_resources 
      WHERE (source = 'linear' AND type = 'issue') 
         OR (source = 'asana' AND type = 'task')
      ORDER BY last_sync DESC
    `)
    .all();
  return result.results as UnifiedResource[];
}

// ============ 同步操作 ============

/**
 * 新增或更新資源
 */
export async function upsertResource(
  db: D1Database,
  resource: Partial<UnifiedResource>
): Promise<void> {
  await db
    .prepare(`
      INSERT OR REPLACE INTO unified_resources 
      (id, source, source_id, type, title, url, layer, status, tags, content_preview, last_sync, metadata)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .bind(
      resource.id,
      resource.source,
      resource.source_id,
      resource.type,
      resource.title,
      resource.url,
      resource.layer || 'L4',
      resource.status || 'active',
      resource.tags?.join(','),
      resource.content_preview,
      Math.floor(Date.now() / 1000),
      resource.metadata ? JSON.stringify(resource.metadata) : null
    )
    .run();
}

/**
 * 批量同步資源
 */
export async function batchSyncResources(
  db: D1Database,
  resources: Partial<UnifiedResource>[]
): Promise<{ synced: number; errors: number }> {
  let synced = 0;
  let errors = 0;

  for (const resource of resources) {
    try {
      await upsertResource(db, resource);
      synced++;
    } catch (e) {
      errors++;
      console.error(`Failed to sync ${resource.id}:`, e);
    }
  }

  return { synced, errors };
}

// ============ 報表生成 ============

/**
 * 生成完整資源報表
 */
export async function generateResourceReport(db: D1Database): Promise<string> {
  const stats = await getResourceStats(db);
  const core = await getCoreResources(db);
  
  let report = `# MrLiou 統一資源報表
origin_signature: MrLiouWord
生成時間: ${new Date().toISOString()}

## 📊 統計概覽

| 項目 | 數量 |
|------|------|
| **總資源數** | ${stats.total} |

### 依來源分類
`;

  for (const [source, count] of Object.entries(stats.by_source)) {
    report += `- ${source}: ${count}\n`;
  }

  report += `\n### 依類型分類\n`;
  for (const [type, count] of Object.entries(stats.by_type)) {
    report += `- ${type}: ${count}\n`;
  }

  report += `\n### 依層級分類\n`;
  for (const [layer, count] of Object.entries(stats.by_layer)) {
    report += `- ${layer}: ${count}\n`;
  }

  report += `\n## 🌟 核心資源 (L7層)\n\n`;
  for (const r of core) {
    report += `- **${r.title}** [${r.source}] ${r.url || ''}\n`;
  }

  return report;
}

// ============ Worker 入口 ============

export default {
  async fetch(request: Request, env: { DB: D1Database }): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    try {
      // GET /stats - 統計
      if (path === '/stats') {
        const stats = await getResourceStats(env.DB);
        return Response.json(stats);
      }

      // GET /search?q=xxx - 搜尋
      if (path === '/search') {
        const q = url.searchParams.get('q') || '';
        const results = await searchResources(env.DB, q);
        return Response.json(results);
      }

      // GET /source/:name - 依來源
      if (path.startsWith('/source/')) {
        const source = path.split('/')[2];
        const results = await getResourcesBySource(env.DB, source);
        return Response.json(results);
      }

      // GET /layer/:name - 依層級
      if (path.startsWith('/layer/')) {
        const layer = path.split('/')[2];
        const results = await getResourcesByLayer(env.DB, layer);
        return Response.json(results);
      }

      // GET /core - 核心資源
      if (path === '/core') {
        const results = await getCoreResources(env.DB);
        return Response.json(results);
      }

      // GET /tasks - 所有任務
      if (path === '/tasks') {
        const results = await getAllTasks(env.DB);
        return Response.json(results);
      }

      // GET /report - 完整報表
      if (path === '/report') {
        const report = await generateResourceReport(env.DB);
        return new Response(report, {
          headers: { 'Content-Type': 'text/markdown; charset=utf-8' }
        });
      }

      // 預設：返回統計
      const stats = await getResourceStats(env.DB);
      return Response.json({
        message: 'MrLiou Unified Resource Hub',
        origin_signature: 'MrLiouWord',
        endpoints: ['/stats', '/search?q=', '/source/:name', '/layer/:name', '/core', '/tasks', '/report'],
        stats
      });

    } catch (error: any) {
      return Response.json({ error: error.message }, { status: 500 });
    }
  }
};
