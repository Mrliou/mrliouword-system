// kv-d1-sync.ts
// MrLiou KV ↔ D1 雙向同步機制
// origin_signature: MrLiouWord

export interface SyncConfig {
  syncInterval: number;  // 同步間隔 (秒)
  conflictStrategy: 'kv_wins' | 'd1_wins' | 'latest_wins';
  enableRealtime: boolean;
}

export interface SyncRecord {
  key: string;
  value: string;
  source: 'kv' | 'd1';
  timestamp: number;
  checksum: string;
}

export interface SyncResult {
  synced: number;
  conflicts: number;
  errors: string[];
  timestamp: number;
}

// ============ 核心同步邏輯 ============

/**
 * 計算簡單校驗和
 */
function checksum(data: string): string {
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16);
}

/**
 * KV → D1 同步
 */
export async function syncKvToD1(
  kv: KVNamespace,
  db: D1Database,
  prefix: string = ''
): Promise<SyncResult> {
  const result: SyncResult = {
    synced: 0,
    conflicts: 0,
    errors: [],
    timestamp: Date.now()
  };

  try {
    // 列出 KV 中的所有 key
    const list = await kv.list({ prefix });
    
    for (const key of list.keys) {
      try {
        const kvValue = await kv.get(key.name);
        if (!kvValue) continue;

        const kvChecksum = checksum(kvValue);
        
        // 檢查 D1 中是否存在
        const d1Record = await db
          .prepare('SELECT * FROM _cf_KV WHERE key = ?')
          .bind(key.name)
          .first<{ value: string; checksum: string; updated_at: number }>();

        if (!d1Record) {
          // D1 不存在，直接寫入
          await db
            .prepare(`
              INSERT INTO _cf_KV (key, value, checksum, source, updated_at)
              VALUES (?, ?, ?, 'kv', ?)
            `)
            .bind(key.name, kvValue, kvChecksum, Date.now())
            .run();
          result.synced++;
        } else if (d1Record.checksum !== kvChecksum) {
          // 值不同，更新 D1
          await db
            .prepare(`
              UPDATE _cf_KV SET value = ?, checksum = ?, source = 'kv', updated_at = ?
              WHERE key = ?
            `)
            .bind(kvValue, kvChecksum, Date.now(), key.name)
            .run();
          result.synced++;
          result.conflicts++;
        }
      } catch (e: any) {
        result.errors.push(`KV→D1 ${key.name}: ${e.message}`);
      }
    }
  } catch (e: any) {
    result.errors.push(`KV list error: ${e.message}`);
  }

  return result;
}

/**
 * D1 → KV 同步
 */
export async function syncD1ToKv(
  db: D1Database,
  kv: KVNamespace,
  prefix: string = ''
): Promise<SyncResult> {
  const result: SyncResult = {
    synced: 0,
    conflicts: 0,
    errors: [],
    timestamp: Date.now()
  };

  try {
    // 從 D1 取得所有記錄
    const query = prefix 
      ? `SELECT * FROM _cf_KV WHERE key LIKE ?`
      : `SELECT * FROM _cf_KV`;
    
    const stmt = prefix 
      ? db.prepare(query).bind(`${prefix}%`)
      : db.prepare(query);
    
    const d1Records = await stmt.all<{
      key: string;
      value: string;
      checksum: string;
      updated_at: number;
    }>();

    for (const record of d1Records.results) {
      try {
        const kvValue = await kv.get(record.key);
        
        if (!kvValue) {
          // KV 不存在，直接寫入
          await kv.put(record.key, record.value);
          result.synced++;
        } else {
          const kvChecksum = checksum(kvValue);
          if (kvChecksum !== record.checksum) {
            // 值不同，更新 KV
            await kv.put(record.key, record.value);
            result.synced++;
            result.conflicts++;
          }
        }
      } catch (e: any) {
        result.errors.push(`D1→KV ${record.key}: ${e.message}`);
      }
    }
  } catch (e: any) {
    result.errors.push(`D1 query error: ${e.message}`);
  }

  return result;
}

/**
 * 雙向同步
 */
export async function bidirectionalSync(
  kv: KVNamespace,
  db: D1Database,
  config: SyncConfig = {
    syncInterval: 300,
    conflictStrategy: 'latest_wins',
    enableRealtime: false
  }
): Promise<{ kvToD1: SyncResult; d1ToKv: SyncResult }> {
  
  // 先 KV → D1
  const kvToD1 = await syncKvToD1(kv, db);
  
  // 再 D1 → KV
  const d1ToKv = await syncD1ToKv(db, kv);
  
  // 記錄同步日誌
  await db
    .prepare(`
      INSERT INTO trace_log (id, action, entity_id, entity_type, metadata)
      VALUES (?, 'sync.bidirectional', 'kv_d1', 'sync', ?)
    `)
    .bind(
      `sync_${Date.now()}`,
      JSON.stringify({
        kv_to_d1: { synced: kvToD1.synced, conflicts: kvToD1.conflicts },
        d1_to_kv: { synced: d1ToKv.synced, conflicts: d1ToKv.conflicts },
        timestamp: new Date().toISOString()
      })
    )
    .run();

  return { kvToD1, d1ToKv };
}

// ============ 記憶同步專用 ============

/**
 * 同步記憶到 KV (快速存取層)
 */
export async function syncMemoriesToKv(
  db: D1Database,
  kv: KVNamespace
): Promise<SyncResult> {
  const result: SyncResult = {
    synced: 0,
    conflicts: 0,
    errors: [],
    timestamp: Date.now()
  };

  try {
    const memories = await db
      .prepare('SELECT * FROM memories ORDER BY created_at DESC')
      .all();

    for (const mem of memories.results as any[]) {
      const key = `memory:${mem.id}`;
      const value = JSON.stringify(mem);
      
      await kv.put(key, value, {
        metadata: {
          layer: mem.layer,
          simhash: mem.simhash,
          updated_at: mem.updated_at
        }
      });
      result.synced++;
    }

    // 建立記憶索引
    const memoryIndex = (memories.results as any[]).map(m => ({
      id: m.id,
      layer: m.layer,
      simhash: m.simhash
    }));
    await kv.put('memory:_index', JSON.stringify(memoryIndex));

  } catch (e: any) {
    result.errors.push(`Memory sync error: ${e.message}`);
  }

  return result;
}

/**
 * 同步粒子到 KV
 */
export async function syncParticlesToKv(
  db: D1Database,
  kv: KVNamespace
): Promise<SyncResult> {
  const result: SyncResult = {
    synced: 0,
    conflicts: 0,
    errors: [],
    timestamp: Date.now()
  };

  try {
    const particles = await db
      .prepare('SELECT * FROM particles')
      .all();

    // 依領域分組存儲
    const byDomain: Record<string, any[]> = {};
    
    for (const p of particles.results as any[]) {
      if (!byDomain[p.dom]) byDomain[p.dom] = [];
      byDomain[p.dom].push(p);
      
      // 單獨存儲每個粒子
      await kv.put(`particle:${p.fx}`, JSON.stringify(p));
      result.synced++;
    }

    // 存儲領域索引
    for (const [dom, particles] of Object.entries(byDomain)) {
      await kv.put(`particles:domain:${dom}`, JSON.stringify(particles));
    }

    // 存儲總索引
    await kv.put('particles:_index', JSON.stringify({
      total: particles.results.length,
      domains: Object.keys(byDomain),
      by_domain: Object.fromEntries(
        Object.entries(byDomain).map(([k, v]) => [k, v.length])
      )
    }));

  } catch (e: any) {
    result.errors.push(`Particle sync error: ${e.message}`);
  }

  return result;
}

// ============ Worker 入口 ============

export default {
  async fetch(request: Request, env: {
    DB: D1Database;
    KV: KVNamespace;
  }): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    try {
      // POST /sync/kv-to-d1
      if (path === '/sync/kv-to-d1' && request.method === 'POST') {
        const result = await syncKvToD1(env.KV, env.DB);
        return Response.json(result);
      }

      // POST /sync/d1-to-kv
      if (path === '/sync/d1-to-kv' && request.method === 'POST') {
        const result = await syncD1ToKv(env.DB, env.KV);
        return Response.json(result);
      }

      // POST /sync/bidirectional
      if (path === '/sync/bidirectional' && request.method === 'POST') {
        const result = await bidirectionalSync(env.KV, env.DB);
        return Response.json(result);
      }

      // POST /sync/memories
      if (path === '/sync/memories' && request.method === 'POST') {
        const result = await syncMemoriesToKv(env.DB, env.KV);
        return Response.json(result);
      }

      // POST /sync/particles
      if (path === '/sync/particles' && request.method === 'POST') {
        const result = await syncParticlesToKv(env.DB, env.KV);
        return Response.json(result);
      }

      // GET /sync/status
      if (path === '/sync/status') {
        const lastSync = await env.DB
          .prepare(`
            SELECT * FROM trace_log 
            WHERE action LIKE 'sync.%' 
            ORDER BY created_at DESC LIMIT 5
          `)
          .all();
        
        return Response.json({
          status: 'ready',
          last_syncs: lastSync.results,
          endpoints: [
            'POST /sync/kv-to-d1',
            'POST /sync/d1-to-kv', 
            'POST /sync/bidirectional',
            'POST /sync/memories',
            'POST /sync/particles'
          ]
        });
      }

      return Response.json({
        service: 'KV-D1 Sync Service',
        origin_signature: 'MrLiouWord',
        endpoints: [
          'GET /sync/status',
          'POST /sync/kv-to-d1',
          'POST /sync/d1-to-kv',
          'POST /sync/bidirectional',
          'POST /sync/memories',
          'POST /sync/particles'
        ]
      });

    } catch (error: any) {
      return Response.json({ error: error.message }, { status: 500 });
    }
  },

  // 定時觸發同步
  async scheduled(event: ScheduledEvent, env: {
    DB: D1Database;
    KV: KVNamespace;
  }) {
    await bidirectionalSync(env.KV, env.DB);
    await syncMemoriesToKv(env.DB, env.KV);
    await syncParticlesToKv(env.DB, env.KV);
  }
};
