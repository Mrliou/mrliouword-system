// Aggregated TERMINAL Zig implementation
