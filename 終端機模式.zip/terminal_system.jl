# Aggregated TERMINAL Julia implementation
