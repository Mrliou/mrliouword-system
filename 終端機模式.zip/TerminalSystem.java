// Aggregated TERMINAL Java implementation
