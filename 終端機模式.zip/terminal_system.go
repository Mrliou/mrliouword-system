// Aggregated TERMINAL Go implementation
