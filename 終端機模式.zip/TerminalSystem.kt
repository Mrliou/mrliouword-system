// Aggregated TERMINAL Kotlin implementation
