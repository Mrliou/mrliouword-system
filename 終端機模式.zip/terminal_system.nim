# Aggregated TERMINAL Nim implementation
