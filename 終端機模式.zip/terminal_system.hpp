// Aggregated TERMINAL C++ implementation
