// Aggregated TERMINAL Dart implementation
