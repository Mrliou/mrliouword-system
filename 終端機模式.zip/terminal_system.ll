; Aggregated TERMINAL LLVM IR implementation
