;; Aggregated TERMINAL WebAssembly implementation
