// Aggregated TERMINAL C# implementation
