// Aggregated TERMINAL Swift implementation
