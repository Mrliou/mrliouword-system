// Aggregated TERMINAL TypeScript implementation
