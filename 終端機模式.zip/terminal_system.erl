%% Aggregated TERMINAL Erlang implementation
