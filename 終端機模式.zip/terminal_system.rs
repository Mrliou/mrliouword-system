// Aggregated TERMINAL Rust implementation
