// Aggregated TERMINAL Scala implementation
