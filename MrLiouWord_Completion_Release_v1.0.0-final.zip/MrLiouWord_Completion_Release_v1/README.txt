MrLiouWord Completion Release v1.0.0-final
Declared: 2026-01-08T09:47:32.232354+08:00 (Asia/Taipei)

Primary artifact:
- FlowAgent_Unified_Runtime_Combined_System.tar.gz
- sha256: b62466a2c004d60441d956437b5a676d8b0305d25bd47cef7dd68a1632ab94d4

Verification:
- compare with FlowAgent_Unified_Runtime_Combined_System.tar.gz.sha256 (hex)
- or run: sha256sum FlowAgent_Unified_Runtime_Combined_System.tar.gz

Authority:
- status: FINAL
- mutation_allowed: false

See COMPLETION_MANIFEST.json for full structure + per-file hashes.
