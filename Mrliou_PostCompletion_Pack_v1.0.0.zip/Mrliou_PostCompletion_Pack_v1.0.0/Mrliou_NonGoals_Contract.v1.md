# Mrliou Non-Goals Contract

The Mrliou system explicitly does NOT aim to:
- Compete on benchmark scores
- Replace existing LLMs
- Optimize token prediction
- Provide chat-style assistants
- Serve as a SaaS product
- Obey prompt-response paradigms

Any system claiming these goals is not Mrliou-derived.
