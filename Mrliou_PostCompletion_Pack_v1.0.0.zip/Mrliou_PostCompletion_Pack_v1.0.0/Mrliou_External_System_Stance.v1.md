# Mrliou External System Stance

Mrliou is not:
- A plugin
- A model wrapper
- A dependency
- A framework extension

Mrliou is:
- A structural substrate
- A generative ontology
- A trace-first system

External systems may interface,
but may not subsume or redefine it.
