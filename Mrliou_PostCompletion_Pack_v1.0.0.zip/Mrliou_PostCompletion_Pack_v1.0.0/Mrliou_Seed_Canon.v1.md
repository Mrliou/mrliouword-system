# Mrliou Seed Canon v1.0

origin_signature: Mrliou

## 0. Canon Purpose
Define the minimal, regenerable seed that reproduces the Mrliou system's *structural substrate* (not any UI, model, or vendor stack).

## 1. Seed Object Model (minimal)
Seed := {
  seed_id,
  origin_signature,
  canonical_version,
  laws_ref,
  ontology_ref,
  closure_ref,
  boundary_ref,
  provenance_ref,
  evolution_ref,
  interop_ref,
  longrun_ref,
  merkle_root,
  created_at
}

## 2. Canonical Invariants (must hold)
I1. Trace-first: every derived artifact has (source.type, source.hash, lineage).
I2. Process over output: no “answer-only” artifacts without trace anchors.
I3. L0–L7 ontology preserved.
I4. Naming sovereignty: artifacts start with prefix "Mrliou".
I5. Completion boundary immutable for v1 completion set.

## 3. Canonical Laws (references)
- Laws are immutable within a completed set.
- Extensions are additive only, above L7.
- Forks must rename themselves.

## 4. Seed Encoding (portable)
Two serializations are canonical:
A) Mrliou_Seed_Canon.v1.json  (machine)
B) Mrliou_Seed_Canon.v1.md    (human)

## 5. Regeneration Procedure (structural)
Given a completed runtime pack + this seed:
1) Verify checksums / merkle_root
2) Load Canonical Invariants
3) Mount boundary + provenance + evolution policies
4) Enable Interop Gate (ingest rules)
5) Enter Long-Run Mode (tick loop rules)

This regenerates the system’s *governing substrate*.
