# Mrliou Trace Provenance Rule

An artifact is considered Mrliou-derived if and only if:
1. It references an original Mrliou completion hash
2. It preserves the L0–L7 ontology
3. It does not collapse process into output-only form
4. It maintains explicit source attribution

Absence of any rule breaks provenance.
