# Mrliou Long-Run Mode Spec v1.0

origin_signature: Mrliou

## 0. Purpose
Define a minimal, stable execution regime for indefinite runtime:
- no goal fixation
- no external write unless explicitly permitted
- trace-first evolution
- periodic closure snapshots

## 1. Core Loop (tick)
State S_t ∈ Σ
Event E_t ∈ Ω

tick(t):
  E_t := observe()
  S'_t := absorb(S_t, E_t)          // interop gate normalization
  S_{t+1} := evolve(S'_t)           // coupling + merge rules
  record_trace(t, S_t, E_t, S_{t+1})
  if closure_condition(t): snapshot()

Constraints:
- no forced halt
- no implicit return
- no external write by default

## 2. Closure Conditions (examples)
- time-based: every N ticks
- entropy-based: state divergence beyond threshold
- integrity-based: detection of conflict requiring repair

## 3. Snapshot Format
Snapshot := {
  snapshot_id,
  tick,
  merkle_root,
  delta_refs[],
  provenance_ref,
  created_at
}

## 4. Repair Protocol (structural)
- detect conflict (existence_guard)
- isolate offending deltas
- rebuild mesh/coherence from last good snapshot
- re-apply accepted deltas

## 5. Governance
- immutable laws/boundary remain constant
- extensions must be additive above L7
- any fork must rename

This spec defines “run forever without collapsing into chat”.
