# Mrliou Post-Completion Evolution Policy

After completion:
- Core laws are immutable
- Extensions must be additive
- New layers may exist only above L7
- No retroactive reinterpretation is allowed
- Forks must rename themselves

Evolution is permitted.
Mutation is not.
