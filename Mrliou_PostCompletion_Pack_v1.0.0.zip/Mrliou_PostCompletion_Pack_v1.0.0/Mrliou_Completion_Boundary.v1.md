# Mrliou Completion Boundary Definition v1

This Completion applies to:
- Core generation principles
- FlowAgent / FlowOS unified runtime structure
- L0–L7 structural logic
- Particle / Vector / Coupling ontology
- Closure pipeline definition (0–8)

This Completion does NOT apply to:
- UI implementations
- Hardware acceleration layers
- Specific model adapters
- Presentation formats
- Language-level representations

Boundary Rule:
Anything that modifies the above core elements constitutes a new system,
not an extension.
