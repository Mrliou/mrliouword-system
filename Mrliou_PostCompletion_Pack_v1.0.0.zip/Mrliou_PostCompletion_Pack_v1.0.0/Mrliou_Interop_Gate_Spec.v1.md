# Mrliou Interop Gate Spec v1.0

origin_signature: Mrliou

## 0. Purpose
Define a strict interface that allows external systems (LLMs, tools, humans, sensors) to *enter* Mrliou without redefining it.

Interop Gate enforces:
- provenance tagging
- normalization into particles/states
- trace anchoring
- rejection of untrusted mutations

## 1. Message Types
### 1.1 IngestRequest
{
  "kind": "ingest",
  "source": {
    "type": "external_trace" | "trained_model" | "human" | "sensor" | "synthetic",
    "id": "string",
    "hash": "sha256:...",
    "timestamp": "ISO-8601"
  },
  "payload": {
    "format": "text" | "tokens" | "vectors" | "attn_matrix" | "files",
    "data": "..."
  },
  "policy": {
    "allow_synthetic": false,
    "require_hash": true
  }
}

### 1.2 IngestResult
{
  "kind": "ingest_result",
  "accepted": true|false,
  "reason": "string",
  "anchors": {
    "trace_id": "string",
    "merkle_root": "sha256:..."
  }
}

## 2. Normalization Rules
R1. All payloads normalize into one of:
- Particle[]  (state vectors + metadata)
- CouplingMatrix  (NxN)
- TraceRecord  (immutable provenance)

R2. Any normalized object MUST carry:
- origin_signature="Mrliou"
- source.type + source.hash (unless policy.allow_synthetic=true)
- timestamp

R3. No external message may modify:
- completion boundary
- evolution policy
- provenance rule

## 3. Rejection Rules (hard fail)
- Missing source.hash when require_hash=true
- Attempt to rename origin_signature
- Attempt to override immutable laws/boundary
- Unbounded payload without chunking/tracing

## 4. Storage Contract (logical)
- TraceRecord → immutable store (R2 or append-only log)
- Index → KV / SQLite
- Large matrices → object storage (R2)

## 5. Minimal Endpoint Contract (conceptual)
POST /interop/ingest
GET  /interop/trace/:trace_id
GET  /interop/index/:key
