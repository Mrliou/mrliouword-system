/**
 * KV↔D1 Sync Engine v1.0.0 - Test Suite
 * 
 * 測試案例覆蓋：
 * 1. d1_to_kv: 首次同步
 * 2. d1_to_kv: checksum 相同重跑 (冪等)
 * 3. kv_to_d1: inbox 模式消費
 * 4. 衝突: rev 相同但 value 不同
 * 5. SoT: 白名單 prefix KV 優先
 * 6. Resume: 中斷續跑
 * 
 * 執行：npm test 或 vitest run
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  computeChecksum,
  generateUUID,
  wrapEnvelope,
  unwrapEnvelope,
  determineSourceOfTruth,
  resolveConflict,
  classifyError,
  DEFAULT_CONFIG,
  type SyncConfig,
  type KVEnvelope,
  type D1Record,
} from '../kv-d1-sync';

// ============================================================================
// Mock D1 Database
// ============================================================================

interface MockD1Result {
  results: unknown[];
  success: boolean;
  meta: Record<string, unknown>;
}

class MockD1Database {
  private data: Map<string, D1Record> = new Map();
  private syncState: Map<string, { last_cursor_committed: string | null; updated_at: number }> = new Map();
  private syncRuns: Map<string, unknown> = new Map();
  private conflicts: Map<string, unknown> = new Map();
  private inbox: Map<string, unknown> = new Map();

  constructor() {
    // 初始化 sync_state
    this.syncState.set('d1_to_kv', { last_cursor_committed: null, updated_at: 0 });
    this.syncState.set('kv_to_d1', { last_cursor_committed: null, updated_at: 0 });
  }

  prepare(query: string) {
    const self = this;
    return {
      bind(...args: unknown[]) {
        return {
          async first<T>(): Promise<T | null> {
            // SELECT from records
            if (query.includes('FROM records WHERE key =')) {
              const key = args[0] as string;
              return (self.data.get(key) as T) ?? null;
            }
            // SELECT from sync_state
            if (query.includes('FROM sync_state WHERE direction =')) {
              const direction = args[0] as string;
              return (self.syncState.get(direction) as T) ?? null;
            }
            // SELECT from sync_runs
            if (query.includes('FROM sync_runs WHERE run_id =')) {
              const runId = args[0] as string;
              return (self.syncRuns.get(runId) as T) ?? null;
            }
            return null;
          },
          async all<T>(): Promise<MockD1Result> {
            // SELECT all from records with cursor
            if (query.includes('FROM records') && query.includes('updated_at >')) {
              const cursor = args[0] as number;
              const limit = args[args.length - 1] as number;
              const results = Array.from(self.data.values())
                .filter(r => r.updated_at > cursor)
                .sort((a, b) => a.updated_at - b.updated_at)
                .slice(0, limit);
              return { results, success: true, meta: {} };
            }
            // SELECT from inbox
            if (query.includes('FROM inbox') && query.includes('processed_at IS NULL')) {
              const limit = args[0] as number;
              const results = Array.from(self.inbox.values())
                .filter((r: any) => r.processed_at === null)
                .slice(0, limit);
              return { results, success: true, meta: {} };
            }
            // SELECT from sync_runs
            if (query.includes('FROM sync_runs')) {
              const results = Array.from(self.syncRuns.values());
              return { results, success: true, meta: {} };
            }
            // SELECT from conflicts
            if (query.includes('FROM conflicts')) {
              const results = Array.from(self.conflicts.values());
              return { results, success: true, meta: {} };
            }
            // SELECT from sync_state
            if (query.includes('FROM sync_state')) {
              const results = Array.from(self.syncState.entries())
                .map(([direction, state]) => ({ direction, ...state }));
              return { results, success: true, meta: {} };
            }
            return { results: [], success: true, meta: {} };
          },
          async run(): Promise<MockD1Result> {
            // INSERT into records
            if (query.includes('INSERT INTO records')) {
              const [key, value, rev, checksum, updated_at] = args as [string, string, number, string, number];
              self.data.set(key, { key, value, rev, checksum, updated_at });
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // UPDATE records
            if (query.includes('UPDATE records')) {
              if (query.includes('WHERE key = ? AND checksum != ?')) {
                const [value, rev, checksum, updated_at, key] = args as [string, number, string, number, string];
                const existing = self.data.get(key);
                if (existing && existing.checksum !== checksum) {
                  self.data.set(key, { key, value, rev, checksum, updated_at });
                  return { results: [], success: true, meta: { changes: 1 } };
                }
                return { results: [], success: true, meta: { changes: 0 } };
              }
            }
            // DELETE from records
            if (query.includes('DELETE FROM records')) {
              const key = args[0] as string;
              self.data.delete(key);
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // INSERT into sync_runs
            if (query.includes('INSERT INTO sync_runs')) {
              const [run_id, direction, started_at, cursor_start] = args as [string, string, number, string | null];
              self.syncRuns.set(run_id, {
                run_id, direction, started_at, finished_at: null,
                cursor_start, cursor_end: null, last_cursor_committed: null,
                scanned_count: 0, applied_count: 0, skipped_same_checksum_count: 0,
                conflict_count: 0, error_count: 0, duration_ms: null
              });
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // UPDATE sync_runs
            if (query.includes('UPDATE sync_runs SET')) {
              const run_id = args[args.length - 1] as string;
              const existing = self.syncRuns.get(run_id) as any;
              if (existing) {
                Object.assign(existing, {
                  finished_at: args[0],
                  cursor_end: args[1],
                  last_cursor_committed: args[2],
                  scanned_count: args[3],
                  applied_count: args[4],
                  skipped_same_checksum_count: args[5],
                  conflict_count: args[6],
                  error_count: args[7],
                  duration_ms: args[8],
                });
              }
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // INSERT/UPDATE sync_state
            if (query.includes('INSERT INTO sync_state') || query.includes('INSERT OR')) {
              const [direction, last_cursor_committed, updated_at] = args as [string, string | null, number];
              self.syncState.set(direction, { last_cursor_committed, updated_at });
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // INSERT into conflicts
            if (query.includes('INSERT INTO conflicts')) {
              const conflict_id = args[0] as string;
              self.conflicts.set(conflict_id, {
                conflict_id,
                run_id: args[1],
                key: args[2],
                d1_rev: args[3],
                kv_rev: args[4],
                d1_checksum: args[5],
                kv_checksum: args[6],
                d1_ts: args[7],
                kv_ts: args[8],
                chosen: args[9],
                strategy: args[10],
                reason: args[11],
                resolved_at: args[12],
              });
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // INSERT into inbox
            if (query.includes('INSERT INTO inbox')) {
              const inbox_id = args[0] as string;
              self.inbox.set(inbox_id, {
                inbox_id,
                key: args[1],
                action: args[2],
                envelope: args[3],
                created_at: args[4],
                processed_at: null,
                run_id: null,
              });
              return { results: [], success: true, meta: { changes: 1 } };
            }
            // UPDATE inbox
            if (query.includes('UPDATE inbox SET')) {
              const inbox_id = args[2] as string;
              const existing = self.inbox.get(inbox_id) as any;
              if (existing) {
                existing.processed_at = args[0];
                existing.run_id = args[1];
              }
              return { results: [], success: true, meta: { changes: 1 } };
            }
            return { results: [], success: true, meta: { changes: 0 } };
          },
        };
      },
    };
  }

  // Helper methods for testing
  _setRecord(key: string, record: D1Record) {
    this.data.set(key, record);
  }

  _getRecord(key: string): D1Record | undefined {
    return this.data.get(key);
  }

  _getAllRecords(): D1Record[] {
    return Array.from(this.data.values());
  }

  _getSyncState(direction: string) {
    return this.syncState.get(direction);
  }

  _getConflicts(): unknown[] {
    return Array.from(this.conflicts.values());
  }

  _setInbox(inbox_id: string, record: any) {
    this.inbox.set(inbox_id, record);
  }
}

// ============================================================================
// Mock KV Namespace
// ============================================================================

class MockKVNamespace {
  private data: Map<string, string> = new Map();

  async get(key: string): Promise<string | null> {
    return this.data.get(key) ?? null;
  }

  async put(key: string, value: string): Promise<void> {
    this.data.set(key, value);
  }

  async delete(key: string): Promise<void> {
    this.data.delete(key);
  }

  async list(): Promise<{ keys: { name: string }[] }> {
    return {
      keys: Array.from(this.data.keys()).map(name => ({ name })),
    };
  }

  // Helper methods for testing
  _getData(): Map<string, string> {
    return this.data;
  }

  _setData(key: string, value: string) {
    this.data.set(key, value);
  }
}

// ============================================================================
// Unit Tests
// ============================================================================

describe('KV↔D1 Sync Engine v1.0.0', () => {
  let db: MockD1Database;
  let kv: MockKVNamespace;
  let config: SyncConfig;

  beforeEach(() => {
    db = new MockD1Database();
    kv = new MockKVNamespace();
    config = { ...DEFAULT_CONFIG };
  });

  // --------------------------------------------------------------------------
  // Test 1: d1_to_kv 首次同步
  // --------------------------------------------------------------------------
  describe('Test 1: d1_to_kv 首次同步', () => {
    it('should sync D1 records to KV with envelope format', async () => {
      // Arrange: 在 D1 中放入測試資料
      const testRecord: D1Record = {
        key: 'test:key1',
        value: 'Hello World',
        rev: 1,
        checksum: await computeChecksum('Hello World'),
        updated_at: Date.now(),
      };
      db._setRecord('test:key1', testRecord);

      // Import and run sync
      const { syncD1ToKV } = await import('../kv-d1-sync');
      const result = await syncD1ToKV(db as any, kv as any, config);

      // Assert
      expect(result.scanned_count).toBe(1);
      expect(result.applied_count).toBe(1);
      expect(result.skipped_same_checksum_count).toBe(0);
      expect(result.error_count).toBe(0);

      // 檢查 KV 中的 envelope
      const kvValue = await kv.get('test:key1');
      expect(kvValue).not.toBeNull();
      
      const envelope = unwrapEnvelope<string>(kvValue!);
      expect(envelope).not.toBeNull();
      expect(envelope!.rev).toBe(1);
      expect(envelope!.source).toBe('d1');
      expect(envelope!.payload).toBe('Hello World');
    });
  });

  // --------------------------------------------------------------------------
  // Test 2: d1_to_kv checksum 相同重跑 (冪等)
  // --------------------------------------------------------------------------
  describe('Test 2: d1_to_kv 冪等性', () => {
    it('should skip records with same checksum on re-run', async () => {
      const value = 'Same Content';
      const checksum = await computeChecksum(value);
      
      // Arrange: D1 和 KV 都有相同內容
      const testRecord: D1Record = {
        key: 'test:idempotent',
        value,
        rev: 1,
        checksum,
        updated_at: Date.now(),
      };
      db._setRecord('test:idempotent', testRecord);

      // 預先在 KV 中放入相同內容的 envelope
      const envelope = wrapEnvelope(value, 1, 'd1', checksum);
      kv._setData('test:idempotent', JSON.stringify(envelope));

      // Import and run sync
      const { syncD1ToKV } = await import('../kv-d1-sync');
      const result = await syncD1ToKV(db as any, kv as any, config);

      // Assert: 應該 skip，不應 apply
      expect(result.scanned_count).toBe(1);
      expect(result.applied_count).toBe(0);
      expect(result.skipped_same_checksum_count).toBe(1);
      expect(result.conflict_count).toBe(0);
    });
  });

  // --------------------------------------------------------------------------
  // Test 3: kv_to_d1 inbox 模式消費
  // --------------------------------------------------------------------------
  describe('Test 3: kv_to_d1 inbox 模式', () => {
    it('should consume inbox and update D1 with rev+1', async () => {
      const value = 'New Content';
      const checksum = await computeChecksum(value);
      
      // Arrange: 在 inbox 中放入變更
      const envelope = wrapEnvelope(value, 1, 'api', checksum);
      db._setInbox('inbox_001', {
        inbox_id: 'inbox_001',
        key: 'data:new',
        action: 'put',
        envelope: JSON.stringify(envelope),
        created_at: Date.now(),
        processed_at: null,
        run_id: null,
      });

      // Import and run sync
      const { syncKVToD1 } = await import('../kv-d1-sync');
      const result = await syncKVToD1(db as any, kv as any, config);

      // Assert
      expect(result.scanned_count).toBe(1);
      expect(result.applied_count).toBe(1);
      expect(result.error_count).toBe(0);

      // 檢查 D1 中的記錄
      const d1Record = db._getRecord('data:new');
      expect(d1Record).toBeDefined();
      expect(d1Record!.rev).toBe(1); // 首次插入 rev=1
      expect(d1Record!.value).toBe(value);
    });

    it('should increment rev only when content changes', async () => {
      // 先插入一筆記錄
      const oldValue = 'Old Content';
      const oldChecksum = await computeChecksum(oldValue);
      db._setRecord('data:existing', {
        key: 'data:existing',
        value: oldValue,
        rev: 1,
        checksum: oldChecksum,
        updated_at: Date.now() - 1000,
      });

      // 在 inbox 中放入更新
      const newValue = 'Updated Content';
      const newChecksum = await computeChecksum(newValue);
      const envelope = wrapEnvelope(newValue, 2, 'api', newChecksum);
      db._setInbox('inbox_002', {
        inbox_id: 'inbox_002',
        key: 'data:existing',
        action: 'put',
        envelope: JSON.stringify(envelope),
        created_at: Date.now(),
        processed_at: null,
        run_id: null,
      });

      const { syncKVToD1 } = await import('../kv-d1-sync');
      const result = await syncKVToD1(db as any, kv as any, config);

      // D1 記錄應該更新，rev 應該 +1
      const d1Record = db._getRecord('data:existing');
      expect(d1Record!.rev).toBe(2);
      expect(d1Record!.value).toBe(newValue);
    });
  });

  // --------------------------------------------------------------------------
  // Test 4: 衝突 - rev 相同但 value 不同
  // --------------------------------------------------------------------------
  describe('Test 4: 衝突審計', () => {
    it('should record conflict when rev equal but value different', async () => {
      const d1Value = 'D1 Version';
      const kvValue = 'KV Version';
      const d1Checksum = await computeChecksum(d1Value);
      const kvChecksum = await computeChecksum(kvValue);
      
      // Arrange: D1 和 KV 有相同 rev 但不同 checksum
      db._setRecord('conflict:key', {
        key: 'conflict:key',
        value: d1Value,
        rev: 5,
        checksum: d1Checksum,
        updated_at: Date.now(),
      });

      const kvEnvelope = wrapEnvelope(kvValue, 5, 'kv', kvChecksum);
      kv._setData('conflict:key', JSON.stringify(kvEnvelope));

      // Import and run sync
      const { syncD1ToKV } = await import('../kv-d1-sync');
      const result = await syncD1ToKV(db as any, kv as any, config);

      // Assert: 應該記錄衝突
      expect(result.conflict_count).toBe(1);
      
      const conflicts = db._getConflicts();
      expect(conflicts.length).toBe(1);
      
      const conflict = conflicts[0] as any;
      expect(conflict.key).toBe('conflict:key');
      expect(conflict.d1_rev).toBe(5);
      expect(conflict.kv_rev).toBe(5);
      expect(conflict.d1_checksum).toBe(d1Checksum);
      expect(conflict.kv_checksum).toBe(kvChecksum);
    });
  });

  // --------------------------------------------------------------------------
  // Test 5: SoT - 白名單 prefix KV 優先
  // --------------------------------------------------------------------------
  describe('Test 5: SoT 白名單', () => {
    it('should use D1 as SoT for non-whitelisted prefixes', () => {
      const sot = determineSourceOfTruth('data:key1', config);
      expect(sot).toBe('d1');
    });

    it('should use KV as SoT for whitelisted prefixes', () => {
      // 預設白名單包含 'cache:', 'session:', 'temp:'
      expect(determineSourceOfTruth('cache:key1', config)).toBe('kv');
      expect(determineSourceOfTruth('session:user123', config)).toBe('kv');
      expect(determineSourceOfTruth('temp:data', config)).toBe('kv');
    });

    it('should skip KV-authoritative keys in d1_to_kv sync', async () => {
      // Arrange: 在 D1 中放入 cache: prefix 的資料
      db._setRecord('cache:skip-this', {
        key: 'cache:skip-this',
        value: 'Should be skipped',
        rev: 1,
        checksum: await computeChecksum('Should be skipped'),
        updated_at: Date.now(),
      });

      const { syncD1ToKV } = await import('../kv-d1-sync');
      const result = await syncD1ToKV(db as any, kv as any, config);

      // Assert: 應該 skip（因為 cache: 是 KV 權威）
      expect(result.scanned_count).toBe(1);
      expect(result.applied_count).toBe(0);
      expect(result.skipped_same_checksum_count).toBe(1);
      
      // KV 中不應有此 key
      const kvValue = await kv.get('cache:skip-this');
      expect(kvValue).toBeNull();
    });
  });

  // --------------------------------------------------------------------------
  // Test 6: Resume - 中斷續跑
  // --------------------------------------------------------------------------
  describe('Test 6: Resume 中斷續跑', () => {
    it('should resume from last_cursor_committed', async () => {
      // Arrange: 模擬之前已同步過部分資料
      const now = Date.now();
      
      // 已同步的舊資料 (updated_at 較小)
      db._setRecord('data:old', {
        key: 'data:old',
        value: 'Old data',
        rev: 1,
        checksum: await computeChecksum('Old data'),
        updated_at: now - 10000, // 10 秒前
      });

      // 新資料 (updated_at 較大)
      db._setRecord('data:new1', {
        key: 'data:new1',
        value: 'New data 1',
        rev: 1,
        checksum: await computeChecksum('New data 1'),
        updated_at: now - 5000, // 5 秒前
      });

      db._setRecord('data:new2', {
        key: 'data:new2',
        value: 'New data 2',
        rev: 1,
        checksum: await computeChecksum('New data 2'),
        updated_at: now, // 現在
      });

      // 設置 sync_state，模擬之前已同步到 old 資料
      // cursor 設為 old 的 updated_at，所以續跑時只會處理 new1 和 new2
      const { updateSyncState, syncD1ToKV } = await import('../kv-d1-sync');
      await updateSyncState(db as any, 'd1_to_kv', String(now - 10000));

      // 執行同步
      const result = await syncD1ToKV(db as any, kv as any, config);

      // Assert: 只應該處理 new1 和 new2，不應該重複處理 old
      expect(result.scanned_count).toBe(2);
      expect(result.applied_count).toBe(2);
      
      // 檢查 sync_state 已更新
      const state = db._getSyncState('d1_to_kv');
      expect(state).toBeDefined();
      expect(state!.last_cursor_committed).toBe(String(now));
    });
  });

  // --------------------------------------------------------------------------
  // Utility Function Tests
  // --------------------------------------------------------------------------
  describe('Utility Functions', () => {
    it('computeChecksum should be deterministic', async () => {
      const value = 'Test Value';
      const checksum1 = await computeChecksum(value);
      const checksum2 = await computeChecksum(value);
      expect(checksum1).toBe(checksum2);
    });

    it('wrapEnvelope and unwrapEnvelope should be symmetric', () => {
      const payload = 'Test Payload';
      const envelope = wrapEnvelope(payload, 5, 'd1', 'abc123');
      const json = JSON.stringify(envelope);
      const unwrapped = unwrapEnvelope<string>(json);
      
      expect(unwrapped).not.toBeNull();
      expect(unwrapped!.rev).toBe(5);
      expect(unwrapped!.source).toBe('d1');
      expect(unwrapped!.checksum).toBe('abc123');
      expect(unwrapped!.payload).toBe(payload);
    });

    it('classifyError should categorize errors correctly', () => {
      expect(classifyError(new Error('Request timeout'))).toBe('transient');
      expect(classifyError(new Error('Rate limit exceeded'))).toBe('transient');
      expect(classifyError(new Error('503 Service Unavailable'))).toBe('transient');
      expect(classifyError(new Error('Duplicate key constraint'))).toBe('data_conflict');
      expect(classifyError(new Error('Invalid JSON'))).toBe('permanent');
    });

    it('resolveConflict should use correct priority', () => {
      // Rev higher wins
      const result1 = resolveConflict(
        'test:key',
        { rev: 5, checksum: 'aaa', ts: 1000 },
        { rev: 3, checksum: 'bbb', ts: 2000 },
        config
      );
      expect(result1.chosen).toBe('d1');
      expect(result1.reason).toContain('rev_higher_d1');

      // Checksum equal = no sync needed
      const result2 = resolveConflict(
        'test:key',
        { rev: 5, checksum: 'same', ts: 1000 },
        { rev: 5, checksum: 'same', ts: 2000 },
        config
      );
      expect(result2.chosen).toBe('none');
      expect(result2.reason).toBe('checksum_equal');
    });
  });
});
