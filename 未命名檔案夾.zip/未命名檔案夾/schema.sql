-- ============================================================================
-- KV↔D1 Sync Engine v1.0.0 - D1 Schema
-- 
-- 執行方式：
--   wrangler d1 execute <DB_NAME> --file=./schema.sql
--
-- 如果 records 表已存在，使用 schema-alter.sql 對齊
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. records 表 (主資料表)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS records (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  rev INTEGER NOT NULL DEFAULT 1,
  checksum TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);

-- 索引：用於 cursor 分頁掃描
CREATE INDEX IF NOT EXISTS idx_records_updated_at ON records(updated_at);

-- 索引：用於 prefix 過濾
CREATE INDEX IF NOT EXISTS idx_records_key_prefix ON records(key);

-- ----------------------------------------------------------------------------
-- 2. sync_runs 表 (同步運行記錄)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sync_runs (
  run_id TEXT PRIMARY KEY,
  direction TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  cursor_start TEXT,
  cursor_end TEXT,
  last_cursor_committed TEXT,
  scanned_count INTEGER NOT NULL DEFAULT 0,
  applied_count INTEGER NOT NULL DEFAULT 0,
  skipped_same_checksum_count INTEGER NOT NULL DEFAULT 0,
  conflict_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  duration_ms INTEGER
);

-- 索引：按時間查詢
CREATE INDEX IF NOT EXISTS idx_sync_runs_started_at ON sync_runs(started_at DESC);

-- 索引：按方向查詢
CREATE INDEX IF NOT EXISTS idx_sync_runs_direction ON sync_runs(direction, started_at DESC);

-- ----------------------------------------------------------------------------
-- 3. sync_state 表 (同步狀態/cursor)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sync_state (
  direction TEXT PRIMARY KEY,
  last_cursor_committed TEXT,
  updated_at INTEGER NOT NULL
);

-- ----------------------------------------------------------------------------
-- 4. conflicts 表 (衝突審計)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conflicts (
  conflict_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  key TEXT NOT NULL,
  d1_rev INTEGER,
  kv_rev INTEGER,
  d1_checksum TEXT,
  kv_checksum TEXT,
  d1_ts INTEGER,
  kv_ts INTEGER,
  chosen TEXT NOT NULL,
  strategy TEXT NOT NULL,
  reason TEXT NOT NULL,
  resolved_at INTEGER,
  FOREIGN KEY (run_id) REFERENCES sync_runs(run_id)
);

-- 索引：按 key 查詢
CREATE INDEX IF NOT EXISTS idx_conflicts_key ON conflicts(key);

-- 索引：未解決的衝突
CREATE INDEX IF NOT EXISTS idx_conflicts_unresolved ON conflicts(resolved_at) WHERE resolved_at IS NULL;

-- 索引：按 run_id 查詢
CREATE INDEX IF NOT EXISTS idx_conflicts_run_id ON conflicts(run_id);

-- ----------------------------------------------------------------------------
-- 5. inbox 表 (KV→D1 推送模式的變更佇列)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS inbox (
  inbox_id TEXT PRIMARY KEY,
  key TEXT NOT NULL,
  action TEXT NOT NULL CHECK(action IN ('put', 'delete')),
  envelope TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  processed_at INTEGER,
  run_id TEXT,
  FOREIGN KEY (run_id) REFERENCES sync_runs(run_id)
);

-- 索引：未處理的 inbox 記錄
CREATE INDEX IF NOT EXISTS idx_inbox_unprocessed ON inbox(created_at) WHERE processed_at IS NULL;

-- 索引：按 key 查詢
CREATE INDEX IF NOT EXISTS idx_inbox_key ON inbox(key);

-- ----------------------------------------------------------------------------
-- 初始化 sync_state (如果不存在)
-- ----------------------------------------------------------------------------
INSERT OR IGNORE INTO sync_state (direction, last_cursor_committed, updated_at) 
VALUES ('d1_to_kv', NULL, 0);

INSERT OR IGNORE INTO sync_state (direction, last_cursor_committed, updated_at) 
VALUES ('kv_to_d1', NULL, 0);
