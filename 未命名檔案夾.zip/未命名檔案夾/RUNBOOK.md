# KV↔D1 Sync Engine v1.0.0 - RUNBOOK

> **怎麼過去就怎麼回來** — MrLiouWord

## 快速開始

### 1. 初始化資料庫

```bash
# 建立所有表和索引
npm run db:init

# 或使用 wrangler 直接執行
wrangler d1 execute mrliouword-db --file=./schema.sql

# 如果 records 表已存在，使用 alter 腳本對齊
npm run db:alter
```

### 2. 部署 Worker

```bash
# 安裝依賴
npm install

# 本地開發
npm run dev

# 部署到生產環境
npm run deploy
```

### 3. 執行同步

```bash
# D1 → KV (推送權威資料到快取)
curl -X POST https://kv-d1-sync.<account>.workers.dev/sync/d1-to-kv

# KV → D1 (消費 inbox 變更)
curl -X POST https://kv-d1-sync.<account>.workers.dev/sync/kv-to-d1

# 雙向同步
curl -X POST https://kv-d1-sync.<account>.workers.dev/sync/bidirectional
```

---

## API 端點

| 方法 | 路徑 | 說明 |
|------|------|------|
| GET | `/health` | 健康檢查 |
| POST | `/sync/d1-to-kv` | D1 → KV 同步 |
| POST | `/sync/kv-to-d1` | KV → D1 同步 (inbox) |
| POST | `/sync/bidirectional` | 雙向同步 |
| GET | `/sync/runs` | 查詢同步記錄 |
| GET | `/sync/runs/:run_id` | 查詢單次同步 |
| GET | `/sync/conflicts` | 查詢衝突記錄 |
| GET | `/sync/state` | 查詢同步狀態 |
| PUT | `/kv/:key` | 寫入 KV (含 inbox) |
| GET | `/kv/:key` | 讀取 KV |
| DELETE | `/kv/:key` | 刪除 KV (含 inbox) |

---

## 查詢同步記錄

### 最近 20 次同步

```bash
curl https://kv-d1-sync.<account>.workers.dev/sync/runs
```

### 特定同步詳情

```bash
curl https://kv-d1-sync.<account>.workers.dev/sync/runs/run_d1_to_kv_1705xxxxx_abc123
```

### 使用 D1 直接查詢

```bash
# 最近 10 次同步
wrangler d1 execute mrliouword-db --command \
  "SELECT run_id, direction, scanned_count, applied_count, conflict_count, duration_ms 
   FROM sync_runs ORDER BY started_at DESC LIMIT 10"

# 查看同步狀態
wrangler d1 execute mrliouword-db --command \
  "SELECT * FROM sync_state"
```

---

## 查詢衝突

### 所有衝突

```bash
curl https://kv-d1-sync.<account>.workers.dev/sync/conflicts
```

### 只查未解決的衝突

```bash
curl "https://kv-d1-sync.<account>.workers.dev/sync/conflicts?unresolved=true"
```

### D1 直接查詢

```bash
# 未解決的衝突
wrangler d1 execute mrliouword-db --command \
  "SELECT conflict_id, key, d1_rev, kv_rev, reason, chosen 
   FROM conflicts WHERE resolved_at IS NULL"

# 特定 key 的衝突歷史
wrangler d1 execute mrliouword-db --command \
  "SELECT * FROM conflicts WHERE key = 'your:key'"
```

---

## 故障排查

### 問題 1: 同步卡住 / 無進度

**症狀**: `applied_count` 一直是 0

**檢查步驟**:
```bash
# 1. 檢查 sync_state cursor 是否正確
wrangler d1 execute mrliouword-db --command \
  "SELECT * FROM sync_state"

# 2. 檢查 records 表是否有資料
wrangler d1 execute mrliouword-db --command \
  "SELECT COUNT(*) FROM records"

# 3. 檢查最新的 updated_at
wrangler d1 execute mrliouword-db --command \
  "SELECT MAX(updated_at) FROM records"
```

**解決方案**: 重設 cursor
```bash
wrangler d1 execute mrliouword-db --command \
  "UPDATE sync_state SET last_cursor_committed = NULL, updated_at = 0 WHERE direction = 'd1_to_kv'"
```

### 問題 2: inbox 堆積

**症狀**: KV→D1 同步 `scanned_count` 很高但 `applied_count` 很低

**檢查步驟**:
```bash
# 查看未處理的 inbox 數量
wrangler d1 execute mrliouword-db --command \
  "SELECT COUNT(*) FROM inbox WHERE processed_at IS NULL"

# 查看最舊的未處理記錄
wrangler d1 execute mrliouword-db --command \
  "SELECT inbox_id, key, created_at FROM inbox 
   WHERE processed_at IS NULL ORDER BY created_at LIMIT 10"
```

**解決方案**: 手動標記問題記錄
```bash
# 標記特定 inbox 為已處理 (跳過)
wrangler d1 execute mrliouword-db --command \
  "UPDATE inbox SET processed_at = strftime('%s','now')*1000, run_id = 'manual_skip' 
   WHERE inbox_id = 'inbox_xxx'"
```

### 問題 3: 衝突過多

**症狀**: `conflict_count` 持續增加

**檢查步驟**:
```bash
# 分析衝突原因分布
wrangler d1 execute mrliouword-db --command \
  "SELECT reason, COUNT(*) as cnt FROM conflicts GROUP BY reason ORDER BY cnt DESC"

# 查看特定 key 的衝突
wrangler d1 execute mrliouword-db --command \
  "SELECT * FROM conflicts WHERE key LIKE 'problem:%'"
```

**解決方案**:
1. 調整 `conflict_strategy` (在 wrangler.toml 的 SYNC_CONFIG)
2. 將問題 prefix 加入 `kv_authoritative_prefixes`
3. 手動解決並標記 `resolved_at`

### 問題 4: KV 超過大小限制

**症狀**: 錯誤訊息 `KV value exceeds max size`

**解決方案**:
1. 檢查 payload 大小，考慮拆分
2. 調整 `kv_max_value_size` (最大 25MB)
3. 使用 R2 存儲大型資料

---

## 配置說明

### SYNC_CONFIG 參數

| 參數 | 預設值 | 說明 |
|------|--------|------|
| `batch_size` | 100 | 每批處理數量 |
| `kv_authoritative_prefixes` | `["cache:", "session:", "temp:"]` | KV 為權威的 prefix |
| `conflict_strategy` | `latest_wins` | 衝突策略 |
| `kv_max_value_size` | 25MB | KV 最大 value 大小 |
| `enable_inbox_mode` | true | 啟用 inbox 模式 |

### 衝突策略

| 策略 | 說明 |
|------|------|
| `latest_wins` | 依 rev > checksum > ts 決定 |
| `d1_wins` | D1 永遠勝出 |
| `kv_wins` | KV 永遠勝出 |
| `manual` | 不自動解決，記錄後等待人工處理 |

---

## 定時同步

Worker 已配置 cron trigger，每 5 分鐘自動執行雙向同步：

```toml
[triggers]
crons = ["*/5 * * * *"]
```

查看定時執行日誌：
```bash
wrangler tail kv-d1-sync
```

---

## 緊急操作

### 停止自動同步

暫時移除 cron trigger：
```bash
# 編輯 wrangler.toml，註解掉 triggers
# 然後重新部署
npm run deploy
```

### 清空所有同步狀態

```bash
# ⚠️ 危險操作：會導致完整重新同步
wrangler d1 execute mrliouword-db --command \
  "DELETE FROM sync_state"
```

### 回滾到特定時間點

```bash
# 1. 找到目標時間的 run_id
wrangler d1 execute mrliouword-db --command \
  "SELECT run_id, last_cursor_committed FROM sync_runs 
   WHERE direction = 'd1_to_kv' AND started_at < 1705000000000 
   ORDER BY started_at DESC LIMIT 1"

# 2. 設置 cursor 到該點
wrangler d1 execute mrliouword-db --command \
  "UPDATE sync_state SET last_cursor_committed = '<cursor_value>' 
   WHERE direction = 'd1_to_kv'"
```

---

## 監控指標

建議監控以下指標：

| 指標 | 閾值 | 告警 |
|------|------|------|
| `error_count` per run | > 10 | Warning |
| `conflict_count` per run | > 50 | Warning |
| `duration_ms` | > 30000 | Warning |
| Unresolved conflicts | > 100 | Critical |
| Inbox backlog | > 1000 | Critical |

---

## 跑測試

```bash
# 安裝依賴
npm install

# 執行所有測試
npm test

# 監看模式
npm run test:watch
```

---

## 版本資訊

- **版本**: 1.0.0
- **作者**: MR.liou
- **Origin Signature**: MrLiouWord
- **建立日期**: 2026-01-19
