/**
 * META WORLD PORTAL - 元世界入口系統
 * 整合：粒子宇宙 + 平行人格 + MetaEnv 沙盒
 * 作者：Mr. Liou Yu Lin & Claude
 * 版本：v1.0.0-alpha
 */

import { Redis } from '@upstash/redis';
import express from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

// ===== 配置 =====
const redis = new Redis({
  url: 'https://blessed-vervet-16893.upstash.io',
  token: 'AUH9AAIncDFjNDBiZjc0MDM5YjM0NGNlYmY4MWY2Yjk5YjI4YjY2MHAxMTY4OTM',
});

const app = express();
app.use(express.json());
app.use(express.static('public'));

// ===== META ENV 控制器 =====
class MetaEnvController {
  constructor() {
    this.environments = new Map();
    this.snapshots = new Map();
    this.policies = new Map();
    this.channelMaps = new Map();
  }

  // 啟動元代碼沙盒
  async spawnEnv(config) {
    const envId = config.env_id || `env_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const env = {
      id: envId,
      role: config.role || 'core',
      shape: config.shape,
      policy: config.policy || 'Mr.liou.MetaCode.Guard.v1',
      status: 'running',
      created_at: new Date().toISOString(),
      attestation: this.generateAttestation(envId)
    };

    this.environments.set(envId, env);
    
    console.log(`🌐 MetaEnv 已啟動: ${envId}`);
    return { ok: true, env_id: envId, status: 'running' };
  }

  // 生成 Attestation（證明）
  generateAttestation(envId) {
    const data = `${envId}:${Date.now()}`;
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  // 套用安全政策
  applyPolicy(envId, policyName) {
    const env = this.environments.get(envId);
    if (!env) return { ok: false, error: 'Environment not found' };

    env.policy = policyName;
    this.policies.set(envId, {
      name: policyName,
      rules: this.loadPolicyRules(policyName),
      applied_at: new Date().toISOString()
    });

    return { ok: true, env_id: envId, policy: policyName };
  }

  // 載入政策規則
  loadPolicyRules(policyName) {
    const defaultRules = {
      'Mr.liou.MetaCode.Guard.v1': {
        network: 'isolated',
        filesystem: 'sandboxed',
        memory: 'encrypted',
        snapshots: 'non-exportable',
        canary: 'enabled'
      }
    };
    return defaultRules[policyName] || defaultRules['Mr.liou.MetaCode.Guard.v1'];
  }

  // 創建加密快照
  createSnapshot(envId, options = {}) {
    const env = this.environments.get(envId);
    if (!env) return { ok: false, error: 'Environment not found' };

    const snapshotId = `snap_${envId}_${Date.now()}`;
    const snapshot = {
      id: snapshotId,
      env_id: envId,
      encrypted: options.encrypted !== false,
      exportable: options.exportable || false,
      label: options.label || `Snapshot at ${new Date().toISOString()}`,
      data_hash: crypto.randomBytes(32).toString('hex'),
      created_at: new Date().toISOString()
    };

    this.snapshots.set(snapshotId, snapshot);
    
    return { 
      ok: true, 
      snapshot_id: snapshotId,
      encrypted: snapshot.encrypted,
      exportable: snapshot.exportable 
    };
  }

  // 通道地圖掛載
  applyChannelMap(config) {
    const { app, mode, from, to, map } = config;
    
    const channelId = `channel_${app}_${Date.now()}`;
    const channel = {
      id: channelId,
      app,
      mode: mode || 'dry-run',
      from,
      to,
      map: map || this.getDefaultChannelMap(app),
      applied_at: new Date().toISOString(),
      revert_token: crypto.randomBytes(16).toString('hex')
    };

    this.channelMaps.set(channelId, channel);

    const changes = this.simulateChannelChanges(channel);

    return {
      ok: true,
      changes,
      revert_token: channel.revert_token
    };
  }

  getDefaultChannelMap(app) {
    return {
      mappings: [
        { source: 'FlowMemory:/persona', target: '%USERPROFILE%/Documents' },
        { source: 'FlowMemory:/cache', target: '%TEMP%/FlowCache' }
      ]
    };
  }

  simulateChannelChanges(channel) {
    return [
      `Mapped: ${channel.from} -> ${channel.to}`,
      `Mode: ${channel.mode}`,
      `Revert token: ${channel.revert_token}`
    ];
  }

  // 鎖死機制
  lockdown(envId, reason) {
    const env = this.environments.get(envId);
    if (!env) return { ok: false, error: 'Environment not found' };

    const actions = [
      '🔒 Network disconnected',
      '🔒 All tokens revoked',
      '🔒 Snapshots frozen',
      '🔒 File system read-only',
      '🔒 Canary triggered'
    ];

    env.status = 'locked';
    env.locked_at = new Date().toISOString();
    env.lock_reason = reason;

    console.log(`🚨 LOCKDOWN: ${envId} - ${reason}`);

    return { ok: true, actions };
  }

  // 健康檢查
  health(envId = null) {
    if (envId) {
      const env = this.environments.get(envId);
      return {
        ok: !!env,
        time: new Date().toISOString(),
        env_id: envId,
        status: env ? env.status : 'not_found'
      };
    }

    return {
      ok: true,
      time: new Date().toISOString(),
      total_envs: this.environments.size,
      active_envs: Array.from(this.environments.values()).filter(e => e.status === 'running').length
    };
  }
}

// ===== 平行人格引擎 =====
class ParallelPersonaEngine {
  constructor() {
    this.personas = new Map();
    this.decisions = [];
    this.corePersona = null;
  }

  // 載入核心人格
  loadCorePersona(personaData) {
    this.corePersona = {
      code: personaData.code || 'MrLiou.CoreSeedPersona.v1',
      traits: personaData.traits || ['冷靜', '結構導向', '觀察者'],
      loaded_at: new Date().toISOString()
    };
    
    console.log(`👤 核心人格已載入: ${this.corePersona.code}`);
    return this.corePersona;
  }

  // 創建決策分支
  createDecisionFork(question) {
    const now = new Date().toISOString();
    const questionId = `q_${Date.now()}`;

    const forkY = {
      code: `⋄persona.sim.${questionId}.Y`,
      from: this.corePersona.code,
      decision: question,
      choice: 'YES',
      consequence: '探索新路徑、改變節奏',
      timestamp: now,
      memory: this.simulateMemory('YES', question)
    };

    const forkN = {
      code: `⋄persona.sim.${questionId}.N`,
      from: this.corePersona.code,
      decision: question,
      choice: 'NO',
      consequence: '維持現狀、穩定結構',
      timestamp: now,
      memory: this.simulateMemory('NO', question)
    };

    this.personas.set(forkY.code, forkY);
    this.personas.set(forkN.code, forkN);

    const decision = {
      id: questionId,
      question,
      forks: [forkY.code, forkN.code],
      created_at: now
    };

    this.decisions.push(decision);

    return { decision, forkY, forkN };
  }

  // 模擬記憶
  simulateMemory(choice, question) {
    const memories = {
      'YES': {
        result: `選擇了 ${question}，進入新的體驗領域`,
        emotion: ['興奮', '不確定', '期待'],
        energy_shift: +15
      },
      'NO': {
        result: `選擇不改變 ${question}，保持原有節奏`,
        emotion: ['平靜', '安全', '可能的遺憾'],
        energy_shift: -5
      }
    };

    return memories[choice];
  }

  // 導出為 .flpkg 格式
  exportPersona(personaCode) {
    const persona = this.personas.get(personaCode);
    if (!persona) return null;

    return {
      format: 'flpkg',
      version: '1.0',
      persona
    };
  }

  // 導出為 .fltnz 記憶封存
  exportMemory(personaCode) {
    const persona = this.personas.get(personaCode);
    if (!persona) return null;

    return {
      format: 'fltnz',
      version: '1.0',
      persona: personaCode,
      memory: persona.memory,
      timestamp: new Date().toISOString()
    };
  }
}

// ===== 粒子宇宙引擎 =====
class ParticleUniverse {
  constructor() {
    this.particles = [];
    this.history = [];
  }

  sandboxFormulas = {
    Child1: val => val.split('').reverse().join(''),
    Child2: val => val.replace(/0/g,'x').replace(/1/g,'0').replace(/x/g,'1'),
    Child3: val => val.split('').map(b=>b==='0'?'1':'0').join('')
  };

  async fetchParticles() {
    const keys = ['p001', 'p002', 'p003'];
    this.particles = [];
    for(const key of keys) {
      const p = await redis.get(key);
      if(p) this.particles.push(p);
    }
    return this.particles;
  }

  magnify(val) { return val + val; }
  shrink(val) { return val.slice(0, val.length / 2); }
  
  calcDiff(original, modified) {
    let count = 0;
    for(let i = 0; i < original.length; i++) {
      if(original[i] !== modified[i]) count++;
    }
    return count / original.length;
  }

  simulateRound() {
    const timestamp = new Date().toISOString();
    const roundResult = { timestamp, particles: [] };

    for(const p of this.particles) {
      const sandboxes = Object.keys(this.sandboxFormulas);
      const sandbox = sandboxes[Math.floor(Math.random() * sandboxes.length)];
      const val = this.sandboxFormulas[sandbox](p.binary);
      const magnified = this.magnify(val);
      const shrunk = this.shrink(magnified);
      const diff = this.calcDiff(p.binary, shrunk);

      if(!p.history) p.history = [];
      p.history.push({ sandbox, value: shrunk, diff, timestamp });
      
      roundResult.particles.push({
        id: p.id,
        sandbox,
        diff,
        resonance: this.calculateResonance(diff)
      });
    }

    this.history.push(roundResult);
    return roundResult;
  }

  calculateResonance(diff) {
    return (1 - diff) * 100;
  }
}

// ===== 證據溯源系統 =====
class ProvenanceSystem {
  constructor() {
    this.evidenceLog = [];
    this.snapshots = [];
    this.timeline = [];
  }

  // 記錄證據
  logEvidence(type, data) {
    const entry = {
      date: new Date().toISOString().split('T')[0],
      title: data.title || 'Untitled',
      type,
      url_or_path: data.path || data.url || '',
      sha256: data.hash || this.calculateHash(JSON.stringify(data)),
      notes: data.notes || ''
    };

    this.evidenceLog.push(entry);
    this.saveToCSV();
    
    return entry;
  }

  // 計算 SHA-256
  calculateHash(data) {
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  // 創建 PU 快照
  createPUSnapshot(id, bodyData) {
    const bodyStr = JSON.stringify(bodyData);
    const hash = this.calculateHash(bodyStr);

    const snapshot = {
      header: {
        type: "custom",
        version: "0.2",
        id: `pu:${id}`,
        parent: [],
        timestamp: new Date().toISOString(),
        env: { spec: "ParticleLanguage-0.2" }
      },
      body: {
        mediaType: "application/json",
        encoding: null,
        bytes: bodyStr
      },
      proof: {
        hash: { algo: "sha256", value: hash },
        merkle: { algo: "sha256", root: hash }
      }
    };

    this.snapshots.push(snapshot);
    this.logEvidence('snapshot', {
      title: `Snapshot ${id}`,
      path: `SNAPSHOT-${id}.json`,
      hash
    });

    return snapshot;
  }

  // 保存 CSV
  saveToCSV() {
    const csv = [
      'date,title,type,url_or_path,sha256,notes',
      ...this.evidenceLog.map(e => 
        `${e.date},${e.title},${e.type},${e.url_or_path},${e.sha256},"${e.notes}"`
      )
    ].join('\n');

    fs.writeFileSync('EVIDENCE_LOG.csv', csv);
  }

  // 添加時間線
  addTimeline(event) {
    const entry = `- ${new Date().toISOString().split('T')[0]} • ${event}`;
    this.timeline.push(entry);
    
    const timelineContent = '# TIMELINE（事件時間線）\n' + this.timeline.join('\n');
    fs.writeFileSync('TIMELINE.md', timelineContent);
  }
}

// ===== 整合控制器 =====
class MetaWorldPortal {
  constructor() {
    this.metaEnv = new MetaEnvController();
    this.personaEngine = new ParallelPersonaEngine();
    this.particleUniverse = new ParticleUniverse();
    this.provenance = new ProvenanceSystem();
    this.mainEnvId = null;
  }

  async initialize() {
    console.log('🌍 初始化 Meta World Portal...');

    // 1. 啟動主要 MetaEnv
    const envResult = await this.metaEnv.spawnEnv({
      role: 'core',
      shape: { cpu: 4, gpu: 2, ram: '16G' },
      policy: 'Mr.liou.MetaCode.Guard.v1'
    });
    this.mainEnvId = envResult.env_id;

    // 2. 載入粒子
    await this.particleUniverse.fetchParticles();

    // 3. 載入核心人格
    this.personaEngine.loadCorePersona({
      code: 'MrLiou.CoreSeedPersona.v1',
      traits: ['冷靜', '結構導向', '觀察者']
    });

    // 4. 記錄初始化事件
    this.provenance.addTimeline('Meta World Portal 初始化完成');

    console.log(`✅ 初始化完成 - Env ID: ${this.mainEnvId}`);
  }

  // 創建決策並演化
  async createDecisionWithEvolution(question) {
    // 1. 創建人格分支
    const { decision, forkY, forkN } = this.personaEngine.createDecisionFork(question);

    // 2. 執行粒子演化
    const evolution = this.particleUniverse.simulateRound();

    // 3. 創建快照
    const snapshotY = this.provenance.createPUSnapshot(forkY.code, forkY);
    const snapshotN = this.provenance.createPUSnapshot(forkN.code, forkN);

    // 4. 記錄時間線
    this.provenance.addTimeline(`決策創建: ${question}`);

    return {
      decision,
      forks: { yes: forkY, no: forkN },
      evolution,
      snapshots: { yes: snapshotY, no: snapshotN }
    };
  }

  // 穿越到平行世界
  async travelToParallel(personaCode) {
    const persona = this.personaEngine.personas.get(personaCode);
    if (!persona) {
      return { ok: false, error: 'Persona not found' };
    }

    // 創建新的 MetaEnv 用於此人格
    const envResult = await this.metaEnv.spawnEnv({
      role: 'node',
      shape: { cpu: 2, gpu: 1, ram: '8G' },
      policy: 'Mr.liou.MetaCode.Guard.v1'
    });

    // 套用通道地圖
    const channelResult = this.metaEnv.applyChannelMap({
      app: personaCode,
      mode: 'apply',
      from: `FlowMemory:/persona/${personaCode}`,
      to: `%USERPROFILE%/ParallelWorlds/${personaCode}`
    });

    // 創建快照
    const snapshot = this.metaEnv.createSnapshot(envResult.env_id, {
      label: `Entry to ${personaCode}`
    });

    this.provenance.addTimeline(`穿越至平行世界: ${personaCode}`);

    return {
      ok: true,
      persona,
      env_id: envResult.env_id,
      channel: channelResult,
      snapshot
    };
  }

  // 緊急鎖死
  emergencyLockdown(reason) {
    const result = this.metaEnv.lockdown(this.mainEnvId, reason);
    this.provenance.addTimeline(`緊急鎖死: ${reason}`);
    return result;
  }
}

// ===== API 路由 =====
const portal = new MetaWorldPortal();

// 初始化
app.post('/api/portal/init', async (req, res) => {
  try {
    await portal.initialize();
    res.json({ ok: true, message: 'Portal initialized' });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// MetaEnv 控制
app.post('/api/metaenv/spawn', async (req, res) => {
  const result = await portal.metaEnv.spawnEnv(req.body);
  res.json(result);
});

app.get('/api/metaenv/health', (req, res) => {
  const result = portal.metaEnv.health(req.query.env_id);
  res.json(result);
});

app.post('/api/metaenv/snapshot', (req, res) => {
  const { env_id, ...options } = req.body;
  const result = portal.metaEnv.createSnapshot(env_id, options);
  res.json(result);
});

app.post('/api/metaenv/lockdown', (req, res) => {
  const { env_id, reason } = req.body;
  const result = portal.metaEnv.lockdown(env_id, reason);
  res.json(result);
});

// 人格引擎
app.post('/api/persona/decision', async (req, res) => {
  const { question } = req.body;
  const result = await portal.createDecisionWithEvolution(question);
  res.json(result);
});

app.post('/api/persona/travel', async (req, res) => {
  const { persona_code } = req.body;
  const result = await portal.travelToParallel(persona_code);
  res.json(result);
});

app.get('/api/persona/list', (req, res) => {
  const personas = Array.from(portal.personaEngine.personas.entries()).map(([code, data]) => ({
    code,
    choice: data.choice,
    consequence: data.consequence
  }));
  res.json({ personas });
});

// 粒子宇宙
app.post('/api/particle/evolve', (req, res) => {
  const result = portal.particleUniverse.simulateRound();
  res.json(result);
});

app.get('/api/particle/history', (req, res) => {
  res.json({
    total_rounds: portal.particleUniverse.history.length,
    history: portal.particleUniverse.history
  });
});

// 證據溯源
app.get('/api/provenance/evidence', (req, res) => {
  res.json({ evidence: portal.provenance.evidenceLog });
});

app.get('/api/provenance/timeline', (req, res) => {
  res.json({ timeline: portal.provenance.timeline });
});

app.get('/api/provenance/snapshots', (req, res) => {
  res.json({ snapshots: portal.provenance.snapshots });
});

// 綜合狀態
app.get('/api/portal/status', (req, res) => {
  res.json({
    meta_env: {
      main_id: portal.mainEnvId,
      total_envs: portal.metaEnv.environments.size,
      snapshots: portal.metaEnv.snapshots.size
    },
    personas: {
      core: portal.personaEngine.corePersona?.code,
      branches: portal.personaEngine.personas.size,
      decisions: portal.personaEngine.decisions.length
    },
    particles: {
      count: portal.particleUniverse.particles.length,
      rounds: portal.particleUniverse.history.length
    },
    provenance: {
      evidence_count: portal.provenance.evidenceLog.length,
      timeline_events: portal.provenance.timeline.length,
      snapshots: portal.provenance.snapshots.length
    }
  });
});

// ===== 啟動伺服器 =====
const PORT = process.env.PORT || 3000;

app.listen(PORT, async () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║           🌍 META WORLD PORTAL v1.0.0                      ║
║           元世界入口系統                                      ║
║                                                            ║
║   "穿越維度，連結平行世界，守護演化證據"                        ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝

🚀 Server: http://localhost:${PORT}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📡 CORE APIs
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST /api/portal/init              🔧 初始化整個系統
GET  /api/portal/status            📊 綜合狀態檢查

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 MetaEnv 沙盒控制
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST /api/metaenv/spawn            啟動新環境
GET  /api/metaenv/health           健康檢查
POST /api/metaenv/snapshot         創建快照
POST /api/metaenv/lockdown         緊急鎖死

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 平行人格引擎
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST /api/persona/decision         創建決策分支
POST /api/persona/travel           穿越平行世界
GET  /api/persona/list             列出所有人格

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚛️  粒子宇宙
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST /api/particle/evolve          執行一輪演化
GET  /api/particle/history         演化歷史

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 證據溯源
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GET  /api/provenance/evidence      證據日誌
GET  /api/provenance/timeline      時間線
GET  /api/provenance/snapshots     所有快照

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  `);

  console.log('⏳ 正在初始化系統...\n');
  
  try {
    await portal.initialize();
    console.log('✅ 系統就緒！Claude 已連接到你的世界。\n');
  } catch (error) {
    console.error('❌ 初始化失敗:', error.message);
  }
});

export default app;
