/**
 * DIMENSIONAL ESCALATION SYSTEM
 * 維度升降系統 - 完整實現
 * 
 * 基於 Mr. Liou 的 Dimensional Escalation Playbook v1
 * "遇到難題，不找藉口；換維度、再回來"
 */

import crypto from 'crypto';
import fs from 'fs';

// ===== 六層座標系統 =====
class DimensionalCoordinateSystem {
  constructor() {
    this.dimensions = {
      D: { name: 'Data', level: 1, status: 'ok' },
      S: { name: 'Structure', level: 2, status: 'ok' },
      P: { name: 'Process', level: 3, status: 'ok' },
      R: { name: 'Principle', level: 4, status: 'ok' },
      C: { name: 'Composite', level: 5, status: 'ok' },
      M: { name: 'Meta', level: 6, status: 'ok' }
    };
    
    this.current_dimension = 'D';
    this.trace = [];
    
    console.log('📐 Dimensional Coordinate System 已初始化');
    console.log('   六層座標: D → S → P → R → C → M\n');
  }

  // 檢查當前維度狀態
  checkDimensionHealth(dimension) {
    const checks = {
      'D': this.checkDataLayer,
      'S': this.checkStructureLayer,
      'P': this.checkProcessLayer,
      'R': this.checkPrincipleLayer,
      'C': this.checkCompositeLayer,
      'M': this.checkMetaLayer
    };
    
    return checks[dimension].call(this);
  }

  // D層檢查：資料層
  checkDataLayer() {
    console.log('🔍 [D層] 檢查資料層...');
    // 模擬檢查
    const issues = [];
    
    // 檢查：編碼、欄位、單位
    const encoding_ok = Math.random() > 0.2;
    const fields_ok = Math.random() > 0.2;
    const empty_ratio = Math.random() * 0.1;
    
    if (!encoding_ok) issues.push('編碼錯誤');
    if (!fields_ok) issues.push('欄位缺失');
    if (empty_ratio > 0.05) issues.push(`空欄比例過高 (${(empty_ratio*100).toFixed(1)}%)`);
    
    const passed = issues.length === 0;
    console.log(`   ${passed ? '✅' : '❌'} ${passed ? '通過' : '問題: ' + issues.join(', ')}\n`);
    
    return { passed, issues, dimension: 'D' };
  }

  // S層檢查：結構層
  checkStructureLayer() {
    console.log('🔍 [S層] 檢查結構層...');
    const issues = [];
    
    // 檢查：索引、跳點、映射
    const index_ok = Math.random() > 0.2;
    const jump_points_ok = Math.random() > 0.2;
    const map_ok = Math.random() > 0.2;
    
    if (!index_ok) issues.push('索引破損');
    if (!jump_points_ok) issues.push('跳點找不到');
    if (!map_ok) issues.push('.flynz.map 缺失');
    
    const passed = issues.length === 0;
    console.log(`   ${passed ? '✅' : '❌'} ${passed ? '通過' : '問題: ' + issues.join(', ')}\n`);
    
    return { passed, issues, dimension: 'S' };
  }

  // P層檢查：流程層
  checkProcessLayer() {
    console.log('🔍 [P層] 檢查流程層...');
    const issues = [];
    
    // 檢查：吸收→標準化→對齊→融合→進化
    const stages = ['吸收', '標準化', '對齊', '融合', '進化'];
    const failed_stage = Math.random() > 0.7 ? stages[Math.floor(Math.random() * stages.length)] : null;
    
    if (failed_stage) issues.push(`${failed_stage}階段輸出不符預期`);
    
    const passed = issues.length === 0;
    console.log(`   ${passed ? '✅' : '❌'} ${passed ? '通過' : '問題: ' + issues.join(', ')}\n`);
    
    return { passed, issues, dimension: 'P' };
  }

  // R層檢查：原理層
  checkPrincipleLayer() {
    console.log('🔍 [R層] 檢查原理層...');
    const issues = [];
    
    // 檢查：守恆、對稱、五因子平衡
    const conservation_ok = Math.random() > 0.3;
    const symmetry_ok = Math.random() > 0.3;
    const factors_balanced = Math.random() > 0.3;
    
    if (!conservation_ok) issues.push('違背守恆定律');
    if (!symmetry_ok) issues.push('對稱性破缺');
    if (!factors_balanced) issues.push('五因子失衡');
    
    const passed = issues.length === 0;
    console.log(`   ${passed ? '✅' : '❌'} ${passed ? '通過' : '問題: ' + issues.join(', ')}\n`);
    
    return { passed, issues, dimension: 'R' };
  }

  // C層檢查：綜合法
  checkCompositeLayer() {
    console.log('🔍 [C層] 檢查綜合法...');
    const issues = [];
    
    // 檢查：跨端一致性、快照可播
    const cross_platform_ok = Math.random() > 0.3;
    const snapshot_ok = Math.random() > 0.3;
    
    if (!cross_platform_ok) issues.push('iOS/Windows 結果不一致');
    if (!snapshot_ok) issues.push('快照無法獨立運轉');
    
    const passed = issues.length === 0;
    console.log(`   ${passed ? '✅' : '❌'} ${passed ? '通過' : '問題: ' + issues.join(', ')}\n`);
    
    return { passed, issues, dimension: 'C' };
  }

  // M層檢查：元層
  checkMetaLayer() {
    console.log('🔍 [M層] 檢查元層...');
    const issues = [];
    
    // 檢查：目標函數清晰度、成功定義
    const goal_clear = Math.random() > 0.2;
    const success_defined = Math.random() > 0.2;
    
    if (!goal_clear) issues.push('目標函數不清晰');
    if (!success_defined) issues.push('成功定義模糊');
    
    const passed = issues.length === 0;
    console.log(`   ${passed ? '✅' : '❌'} ${passed ? '通過' : '問題: ' + issues.join(', ')}\n`);
    
    return { passed, issues, dimension: 'M' };
  }

  // 升維
  escalate(from_dimension) {
    const levels = ['D', 'S', 'P', 'R', 'C', 'M'];
    const current_index = levels.indexOf(from_dimension);
    
    if (current_index >= levels.length - 1) {
      console.log('⚠️  已在最高維度 (M層)，無法繼續升維\n');
      return null;
    }
    
    const to_dimension = levels[current_index + 1];
    
    console.log(`⬆️  升維: ${from_dimension}層 → ${to_dimension}層`);
    console.log(`   原因: ${from_dimension}層檢查未通過\n`);
    
    this.trace.push({
      action: 'escalate',
      from: from_dimension,
      to: to_dimension,
      timestamp: new Date().toISOString()
    });
    
    this.current_dimension = to_dimension;
    return to_dimension;
  }

  // 降維回補
  descalate(from_dimension, constraints) {
    const levels = ['D', 'S', 'P', 'R', 'C', 'M'];
    const current_index = levels.indexOf(from_dimension);
    
    if (current_index <= 0) {
      console.log('⚠️  已在最低維度 (D層)，無需降維\n');
      return null;
    }
    
    const to_dimension = levels[current_index - 1];
    
    console.log(`⬇️  降維回補: ${from_dimension}層 → ${to_dimension}層`);
    console.log(`   回寫約束: ${JSON.stringify(constraints).substring(0, 50)}...\n`);
    
    this.trace.push({
      action: 'descalate',
      from: from_dimension,
      to: to_dimension,
      constraints,
      timestamp: new Date().toISOString()
    });
    
    this.current_dimension = to_dimension;
    return to_dimension;
  }

  // 顯示追蹤記錄
  displayTrace() {
    console.log('\n📋 維度升降追蹤記錄:\n');
    this.trace.forEach((entry, i) => {
      const arrow = entry.action === 'escalate' ? '⬆️' : '⬇️';
      console.log(`${i+1}. ${arrow} ${entry.from} → ${entry.to}`);
      if (entry.constraints) {
        console.log(`   約束: ${JSON.stringify(entry.constraints)}`);
      }
      console.log(`   時間: ${entry.timestamp}\n`);
    });
  }
}

// ===== 注意力分數計算器 =====
class AttentionScoreCalculator {
  constructor() {
    // 權重配置
    this.weights = {
      structure: 0.35,
      topic: 0.25,
      persona: 0.20,
      recency: 0.10,
      credibility: 0.10
    };
    
    console.log('🎯 AttentionScoreCalculator 已初始化');
    console.log(`   公式: s = ${this.weights.structure}·Structure + ${this.weights.topic}·Topic + ${this.weights.persona}·Persona + ${this.weights.recency}·Recency + ${this.weights.credibility}·Cred\n`);
  }

  calculate(input) {
    console.log('🧮 計算注意力分數...\n');
    
    // 計算各項分數 (0-1)
    const structure = this._calculateStructure(input);
    const topic = this._calculateTopic(input);
    const persona = this._calculatePersona(input);
    const recency = this._calculateRecency(input);
    const credibility = this._calculateCredibility(input);
    
    // 加權總分
    const total = 
      this.weights.structure * structure +
      this.weights.topic * topic +
      this.weights.persona * persona +
      this.weights.recency * recency +
      this.weights.credibility * credibility;
    
    console.log(`   結構性: ${structure.toFixed(3)} × ${this.weights.structure} = ${(structure * this.weights.structure).toFixed(3)}`);
    console.log(`   主題性: ${topic.toFixed(3)} × ${this.weights.topic} = ${(topic * this.weights.topic).toFixed(3)}`);
    console.log(`   人格性: ${persona.toFixed(3)} × ${this.weights.persona} = ${(persona * this.weights.persona).toFixed(3)}`);
    console.log(`   時效性: ${recency.toFixed(3)} × ${this.weights.recency} = ${(recency * this.weights.recency).toFixed(3)}`);
    console.log(`   可信度: ${credibility.toFixed(3)} × ${this.weights.credibility} = ${(credibility * this.weights.credibility).toFixed(3)}`);
    console.log(`   ────────────────────────────────────────`);
    console.log(`   總分: ${total.toFixed(3)}\n`);
    
    return {
      total,
      breakdown: { structure, topic, persona, recency, credibility }
    };
  }

  _calculateStructure(input) {
    // 結構完整性評分
    const has_type = !!input.type;
    const has_data = !!input.data || !!input.content;
    const has_metadata = !!input.metadata || !!input.timestamp;
    
    return (has_type + has_data + has_metadata) / 3;
  }

  _calculateTopic(input) {
    // 主題相關性評分（簡化）
    const keywords = ['dimension', 'collapse', 'persona', 'memory', 'evolution'];
    const text = JSON.stringify(input).toLowerCase();
    const matches = keywords.filter(kw => text.includes(kw)).length;
    
    return matches / keywords.length;
  }

  _calculatePersona(input) {
    // 人格匹配度（隨機模擬）
    return 0.5 + Math.random() * 0.5;
  }

  _calculateRecency(input) {
    // 時效性（如果有時間戳）
    if (input.timestamp) {
      const age_hours = (Date.now() - new Date(input.timestamp).getTime()) / (1000 * 60 * 60);
      return Math.max(0, 1 - age_hours / 24); // 24小時內線性衰減
    }
    return 0.7; // 默認值
  }

  _calculateCredibility(input) {
    // 可信度評估（簡化）
    if (input.source) {
      const trusted_sources = ['system', 'user', 'verified'];
      return trusted_sources.includes(input.source) ? 1.0 : 0.5;
    }
    return 0.6; // 默認值
  }
}

// ===== 溫度控制器 =====
class TemperatureController {
  constructor() {
    this.temperature = 0.85; // 默認收斂模式
    this.modes = {
      convergence: 0.85,
      exploration: 1.30
    };
    
    console.log('🌡️  TemperatureController 已初始化');
    console.log(`   收斂模式: T=${this.modes.convergence}`);
    console.log(`   探索模式: T=${this.modes.exploration}\n`);
  }

  setMode(mode) {
    if (mode === 'convergence') {
      this.temperature = this.modes.convergence;
      console.log(`🌡️  切換到收斂模式 (T=${this.temperature})\n`);
    } else if (mode === 'exploration') {
      this.temperature = this.modes.exploration;
      console.log(`🌡️  切換到探索模式 (T=${this.temperature})\n`);
    }
  }

  // 根據溫度選擇人格
  selectPersona(personas, scores) {
    if (this.temperature < 1.0) {
      // 收斂模式：選擇最高分
      console.log('   模式: 收斂 - 選擇最高權重人格');
      const max_score = Math.max(...scores);
      const max_index = scores.indexOf(max_score);
      return personas[max_index];
    } else {
      // 探索模式：加權隨機
      console.log('   模式: 探索 - 加權隨機選擇人格');
      const total = scores.reduce((sum, s) => sum + s, 0);
      let random = Math.random() * total;
      for (let i = 0; i < personas.length; i++) {
        random -= scores[i];
        if (random <= 0) return personas[i];
      }
      return personas[personas.length - 1];
    }
  }
}

// ===== 標準操作流程 (SOP) =====
class StandardOperatingProcedure {
  constructor() {
    this.dimSystem = new DimensionalCoordinateSystem();
    this.attentionCalc = new AttentionScoreCalculator();
    this.tempController = new TemperatureController();
    
    console.log('📋 Standard Operating Procedure 已初始化\n');
  }

  // 執行完整 SOP
  async execute(input) {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║     🔄 執行標準操作流程 (SOP)                             ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    // Step 1: 計算注意力分數
    const attention = this.attentionCalc.calculate(input);
    
    // 如果分數太低，直接跳過
    if (attention.total < 0.3) {
      console.log('⚠️  注意力分數過低，跳過處理\n');
      return { skipped: true, reason: 'low_attention_score' };
    }

    // Step 2: D → S → P → R → C → M 逐層檢查
    const dimensions = ['D', 'S', 'P', 'R', 'C', 'M'];
    let current_dim = 'D';
    let all_passed = true;

    for (const dim of dimensions) {
      console.log('═'.repeat(60));
      console.log(`檢查 ${dim}層 (${this.dimSystem.dimensions[dim].name})`);
      console.log('═'.repeat(60) + '\n');

      const result = this.dimSystem.checkDimensionHealth(dim);
      
      if (!result.passed) {
        all_passed = false;
        
        // 升維
        const next_dim = this.dimSystem.escalate(dim);
        
        if (next_dim) {
          // 在更高維度重新定義約束
          console.log(`💡 在 ${next_dim}層 重新定義約束...\n`);
          const constraints = this.redefineConstraints(next_dim, result.issues);
          
          // 降維回補
          this.dimSystem.descalate(next_dim, constraints);
          console.log(`🔧 回補到 ${dim}層，修復問題\n`);
        }
        
        break; // 遇到問題就停止，等修復
      }
    }

    // Step 3: 根據溫度選擇處理模式
    if (all_passed) {
      console.log('✅ 所有維度檢查通過！\n');
      this.tempController.setMode('convergence');
    } else {
      console.log('⚠️  存在問題，切換探索模式\n');
      this.tempController.setMode('exploration');
    }

    // Step 4: 顯示追蹤記錄
    this.dimSystem.displayTrace();

    return {
      attention_score: attention.total,
      all_dimensions_passed: all_passed,
      final_dimension: this.dimSystem.current_dimension,
      temperature: this.tempController.temperature,
      trace: this.dimSystem.trace
    };
  }

  // 重新定義約束
  redefineConstraints(dimension, issues) {
    const constraints = {
      dimension,
      issues,
      timestamp: new Date().toISOString(),
      rules: []
    };

    // 根據維度生成約束規則
    if (dimension === 'S') {
      constraints.rules.push('重建索引');
      constraints.rules.push('修復跳點映射');
    } else if (dimension === 'P') {
      constraints.rules.push('調整流程驗證點');
      constraints.rules.push('更新 schema 定義');
    } else if (dimension === 'R') {
      constraints.rules.push('重新套用守恆定律');
      constraints.rules.push('檢查對稱性');
    } else if (dimension === 'C') {
      constraints.rules.push('跨端對齊測試');
      constraints.rules.push('快照獨立性驗證');
    } else if (dimension === 'M') {
      constraints.rules.push('重新定義成功函數');
      constraints.rules.push('縮減問題範圍');
    }

    return constraints;
  }
}

// ===== 演示 =====
async function demo() {
  console.log('\n╔════════════════════════════════════════════════════════════╗');
  console.log('║                                                            ║');
  console.log('║   🌌 DIMENSIONAL ESCALATION SYSTEM                         ║');
  console.log('║   維度升降系統 - 完整演示                                    ║');
  console.log('║                                                            ║');
  console.log('║   "遇到難題，不找藉口；換維度、再回來"                        ║');
  console.log('║                                                            ║');
  console.log('╚════════════════════════════════════════════════════════════╝\n');

  const sop = new StandardOperatingProcedure();

  // 測試輸入
  const test_input = {
    type: 'dimension_escalation_test',
    data: {
      question: '如何處理跨維度的複雜問題？',
      context: 'system_evolution'
    },
    metadata: {
      source: 'user',
      priority: 'high'
    },
    timestamp: new Date().toISOString()
  };

  // 執行 SOP
  const result = await sop.execute(test_input);

  console.log('\n═'.repeat(60));
  console.log('🎉 演示完成！');
  console.log('═'.repeat(60) + '\n');

  console.log('📊 最終結果:');
  console.log(`   注意力分數: ${result.attention_score.toFixed(3)}`);
  console.log(`   所有維度通過: ${result.all_dimensions_passed ? '是' : '否'}`);
  console.log(`   最終維度: ${result.final_dimension}層`);
  console.log(`   溫度設定: ${result.temperature}`);
  console.log(`   操作追蹤: ${result.trace.length} 條記錄\n`);
}

// 運行演示
demo().catch(console.error);

// 導出
export {
  DimensionalCoordinateSystem,
  AttentionScoreCalculator,
  TemperatureController,
  StandardOperatingProcedure
};
