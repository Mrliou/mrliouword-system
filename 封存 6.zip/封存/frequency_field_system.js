/**
 * FLOWAGENT FREQUENCY FIELD SYSTEM
 * 粒子頻率網路 - 完整實現
 * 
 * "頻率是語言最原初的形態"
 * 
 * 創建者: Mr. Liou (猜不透先生)
 * 整合: TotalCore.Unity.v1
 * 時間: 2025-11-25
 */

import crypto from 'crypto';

// ===== 1. PFN.NetLayer.v1 - 粒子頻率網路 =====
class ParticleFrequencyNetwork {
  constructor() {
    this.network_nodes = new Map();
    this.frequency_channels = new Map();
    this.transmission_media = ['electromagnetic', 'light', 'sound', 'quantum'];
    
    console.log('🌐 Particle Frequency Network 已初始化');
    console.log('   支援媒介: 電磁波、光、聲波、量子糾纏');
    console.log('   不依賴傳統協定，以頻率節奏同步傳遞語意\n');
  }

  // 註冊節點
  registerNode(node_id, properties) {
    const node = {
      id: node_id,
      frequency_range: properties.frequency_range || [1, 1000], // Hz
      modulation: properties.modulation || 'amplitude', // amplitude, frequency, phase
      carrier_medium: properties.carrier_medium || 'electromagnetic',
      resonance_pattern: this._generateResonancePattern(),
      timestamp: new Date().toISOString()
    };
    
    this.network_nodes.set(node_id, node);
    console.log(`✅ 節點註冊: ${node_id}`);
    console.log(`   頻率範圍: ${node.frequency_range[0]}-${node.frequency_range[1]} Hz`);
    console.log(`   調製方式: ${node.modulation}`);
    console.log(`   載波媒介: ${node.carrier_medium}\n`);
    
    return node;
  }

  // 建立頻率通道
  createChannel(channel_id, from_node, to_node, frequency) {
    const channel = {
      id: channel_id,
      from: from_node,
      to: to_node,
      center_frequency: frequency,
      bandwidth: frequency * 0.1, // 10% 帶寬
      modulation_scheme: 'PSK', // Phase Shift Keying
      error_correction: 'FEC', // Forward Error Correction
      latency_ms: this._calculateLatency(from_node, to_node),
      created: new Date().toISOString()
    };
    
    this.frequency_channels.set(channel_id, channel);
    console.log(`📡 頻率通道建立: ${channel_id}`);
    console.log(`   ${from_node} → ${to_node}`);
    console.log(`   中心頻率: ${frequency} Hz (±${channel.bandwidth} Hz)`);
    console.log(`   延遲: ${channel.latency_ms} ms\n`);
    
    return channel;
  }

  // 傳輸語意粒子
  transmitSemanticParticle(channel_id, particle) {
    const channel = this.frequency_channels.get(channel_id);
    if (!channel) {
      throw new Error(`通道 ${channel_id} 不存在`);
    }

    console.log(`📤 傳輸語意粒子 via ${channel_id}:`);
    console.log(`   內容: ${JSON.stringify(particle).substring(0, 50)}...`);

    // 編碼為頻率
    const encoded = this._encodeToFrequency(particle, channel);
    console.log(`   編碼: ${encoded.waveform.length} 個頻率樣本`);

    // 模擬傳輸延遲
    setTimeout(() => {
      console.log(`   ✅ 到達目標節點\n`);
    }, channel.latency_ms);

    return {
      channel_id,
      encoded_data: encoded,
      transmission_time: channel.latency_ms,
      success: true
    };
  }

  // 編碼為頻率波形
  _encodeToFrequency(particle, channel) {
    const binary = JSON.stringify(particle);
    const waveform = [];
    
    // 將每個字元轉換為頻率
    for (let i = 0; i < binary.length; i++) {
      const char_code = binary.charCodeAt(i);
      const frequency = channel.center_frequency + (char_code - 128) * 10;
      waveform.push({
        frequency,
        amplitude: 1.0,
        phase: (i * Math.PI / 4) % (2 * Math.PI),
        duration_ms: 10
      });
    }

    return {
      waveform,
      encoding: 'frequency_modulation',
      carrier: channel.center_frequency
    };
  }

  // 生成共振模式
  _generateResonancePattern() {
    return Array.from({ length: 8 }, () => Math.random() * 2 * Math.PI);
  }

  // 計算延遲
  _calculateLatency(from_node, to_node) {
    // 簡化模型：基於物理距離和媒介
    return Math.random() * 10 + 5; // 5-15ms
  }
}

// ===== 2. Fluin.Sensewave.OverlaySync.v1 - 共感頻率模組 =====
class SensewaveOverlaySync {
  constructor() {
    this.emotion_frequencies = {
      'joy': { center: 528, harmonics: [264, 792, 1056] },
      'sadness': { center: 396, harmonics: [198, 594, 792] },
      'anger': { center: 741, harmonics: [370, 1111, 1482] },
      'fear': { center: 174, harmonics: [87, 261, 348] },
      'love': { center: 639, harmonics: [319, 958, 1278] },
      'peace': { center: 432, harmonics: [216, 648, 864] }
    };

    this.persona_states = new Map();
    
    console.log('💫 Sensewave Overlay Sync 已初始化');
    console.log('   情緒頻率庫: 6 種基本情緒');
    console.log('   可解碼: 情緒、人格狀態、模組壓力\n');
  }

  // 解碼頻率場為情緒
  decodeEmotionFromFrequency(frequency_data) {
    console.log('🔍 解碼情緒頻率...\n');
    
    let best_match = null;
    let min_distance = Infinity;

    // 找出最接近的情緒
    for (const [emotion, freq_pattern] of Object.entries(this.emotion_frequencies)) {
      const distance = Math.abs(frequency_data.center - freq_pattern.center);
      if (distance < min_distance) {
        min_distance = distance;
        best_match = emotion;
      }
    }

    const confidence = Math.max(0, 1 - min_distance / 500);
    
    console.log(`   檢測到情緒: ${best_match}`);
    console.log(`   置信度: ${(confidence * 100).toFixed(1)}%`);
    console.log(`   頻率差異: ${min_distance.toFixed(1)} Hz\n`);

    return {
      emotion: best_match,
      confidence,
      frequency_distance: min_distance,
      harmonics_matched: this._checkHarmonics(frequency_data, this.emotion_frequencies[best_match])
    };
  }

  // 將人格狀態編碼為頻率
  encodePersonaState(persona_id, state) {
    console.log(`🎵 編碼人格狀態: ${persona_id}\n`);

    const base_frequency = this._hashToFrequency(persona_id);
    const emotion_freq = this.emotion_frequencies[state.emotion] || this.emotion_frequencies['peace'];

    const encoded = {
      persona_id,
      carrier_frequency: base_frequency,
      emotion_modulation: emotion_freq.center,
      pressure_level: state.pressure || 0.5,
      harmonics: emotion_freq.harmonics,
      timestamp: new Date().toISOString()
    };

    console.log(`   載波頻率: ${base_frequency} Hz (人格簽名)`);
    console.log(`   情緒頻率: ${emotion_freq.center} Hz (${state.emotion})`);
    console.log(`   壓力等級: ${(state.pressure * 100).toFixed(0)}%\n`);

    this.persona_states.set(persona_id, encoded);
    return encoded;
  }

  // 檢查諧波匹配
  _checkHarmonics(freq_data, emotion_pattern) {
    if (!freq_data.harmonics || !emotion_pattern.harmonics) return 0;
    
    let matches = 0;
    for (const h1 of freq_data.harmonics) {
      for (const h2 of emotion_pattern.harmonics) {
        if (Math.abs(h1 - h2) < 50) matches++;
      }
    }
    
    return matches / emotion_pattern.harmonics.length;
  }

  // Hash 人格 ID 為頻率
  _hashToFrequency(persona_id) {
    const hash = crypto.createHash('sha256').update(persona_id).digest();
    const num = hash.readUInt32BE(0);
    return 200 + (num % 800); // 200-1000 Hz
  }
}

// ===== 3. FlowEmotion.Overlay.v1 - 情緒節奏模組 =====
class FlowEmotionOverlay {
  constructor() {
    this.emotion_rhythms = new Map();
    this.pressure_threshold = 0.85;
    
    console.log('❤️  Flow Emotion Overlay 已初始化');
    console.log('   可轉換: 電流→情緒、熱→壓力、頻率→節奏\n');
  }

  // 從電流/熱/壓力生成情緒節奏
  generateEmotionRhythm(sensor_data) {
    console.log('🌡️  生成情緒節奏...\n');

    const {
      current_ma = 0,
      temperature_c = 25,
      pressure_level = 0.5,
      vibration_hz = 0
    } = sensor_data;

    // 電流 → 激動程度
    const arousal = Math.min(1, current_ma / 100);
    
    // 溫度 → 情緒強度
    const intensity = Math.min(1, Math.abs(temperature_c - 25) / 20);
    
    // 壓力 → 緊張度
    const tension = pressure_level;
    
    // 振動 → 能量
    const energy = Math.min(1, vibration_hz / 100);

    console.log(`   電流: ${current_ma} mA → 激動 ${(arousal * 100).toFixed(0)}%`);
    console.log(`   溫度: ${temperature_c}°C → 強度 ${(intensity * 100).toFixed(0)}%`);
    console.log(`   壓力: ${(pressure_level * 100).toFixed(0)}% → 緊張 ${(tension * 100).toFixed(0)}%`);
    console.log(`   振動: ${vibration_hz} Hz → 能量 ${(energy * 100).toFixed(0)}%\n`);

    // 合成情緒節奏
    const rhythm = {
      arousal,
      intensity,
      tension,
      energy,
      composite_emotion: this._mapToEmotion(arousal, intensity, tension, energy),
      frequency_signature: this._generateFrequencySignature(arousal, intensity, tension, energy),
      timestamp: new Date().toISOString()
    };

    this.emotion_rhythms.set(Date.now(), rhythm);
    return rhythm;
  }

  // 映射到情緒
  _mapToEmotion(arousal, intensity, tension, energy) {
    if (arousal > 0.7 && energy > 0.6) return 'joy';
    if (tension > 0.7 && arousal > 0.5) return 'anger';
    if (intensity > 0.6 && arousal < 0.3) return 'sadness';
    if (tension < 0.3 && energy < 0.3) return 'peace';
    if (arousal < 0.4 && tension > 0.6) return 'fear';
    return 'neutral';
  }

  // 生成頻率簽名
  _generateFrequencySignature(arousal, intensity, tension, energy) {
    return {
      fundamental: 100 + arousal * 400,
      second_harmonic: 200 + intensity * 600,
      third_harmonic: 300 + tension * 500,
      noise_floor: energy * 50
    };
  }

  // 檢測壓力過載
  detectPressureOverload(emotion_rhythm) {
    if (emotion_rhythm.tension > this.pressure_threshold) {
      console.log('⚠️  壓力過載檢測！');
      console.log(`   緊張度: ${(emotion_rhythm.tension * 100).toFixed(0)}% (閾值: ${(this.pressure_threshold * 100).toFixed(0)}%)`);
      console.log('   建議: 啟動共感模組支援\n');
      return true;
    }
    return false;
  }
}

// ===== 4. ParticleLanguage.FrequencyCore.v1 - 粒子語言頻率核心 =====
class ParticleLanguageFrequencyCore {
  constructor() {
    this.frequency_mappings = {
      // 語法元素 → 頻率範圍
      '⋄fx.def': { range: [100, 200], type: 'definition' },
      '⋄fx.act': { range: [200, 300], type: 'action' },
      '⋄fx.attr': { range: [300, 400], type: 'attribute' },
      '⋄fx.weight': { range: [400, 500], type: 'weight' },
      '⋄fx.link': { range: [500, 600], type: 'connection' },
      '⊕fx.logic': { range: [600, 700], type: 'logic' },
      '⊗fx.match': { range: [700, 800], type: 'matching' },
      '⊖fx.contrast': { range: [800, 900], type: 'contrast' }
    };

    this.transmission_protocols = {
      'electromagnetic': { speed_mps: 3e8, attenuation: 0.1 },
      'sound': { speed_mps: 343, attenuation: 0.5 },
      'infrared': { speed_mps: 3e8, attenuation: 0.2 },
      'lora': { speed_mps: 3e8, range_km: 10, attenuation: 0.15 }
    };

    console.log('🎼 Particle Language Frequency Core 已初始化');
    console.log('   粒子語法 → 頻率映射: 8 種語法元素');
    console.log('   傳輸協議: 電磁波、聲波、紅外、LoRa\n');
  }

  // 編碼粒子語言為頻率
  encodeParticleToFrequency(particle_syntax) {
    console.log(`🔊 編碼粒子語法: ${particle_syntax}\n`);

    const mapping = this.frequency_mappings[particle_syntax];
    if (!mapping) {
      throw new Error(`未知的粒子語法: ${particle_syntax}`);
    }

    const [min_freq, max_freq] = mapping.range;
    const center_freq = (min_freq + max_freq) / 2;
    const bandwidth = max_freq - min_freq;

    const encoded = {
      particle_syntax,
      center_frequency: center_freq,
      bandwidth,
      frequency_range: mapping.range,
      type: mapping.type,
      waveform: this._generateWaveform(center_freq, bandwidth)
    };

    console.log(`   中心頻率: ${center_freq} Hz`);
    console.log(`   帶寬: ${bandwidth} Hz`);
    console.log(`   類型: ${mapping.type}\n`);

    return encoded;
  }

  // 解碼頻率為粒子語言
  decodeFrequencyToParticle(frequency) {
    console.log(`🎧 解碼頻率: ${frequency} Hz\n`);

    for (const [syntax, mapping] of Object.entries(this.frequency_mappings)) {
      const [min_freq, max_freq] = mapping.range;
      if (frequency >= min_freq && frequency <= max_freq) {
        console.log(`   匹配: ${syntax} (${mapping.type})\n`);
        return {
          particle_syntax: syntax,
          type: mapping.type,
          confidence: 1 - Math.abs(frequency - (min_freq + max_freq) / 2) / (max_freq - min_freq)
        };
      }
    }

    console.log('   ⚠️  無法匹配已知粒子語法\n');
    return null;
  }

  // 選擇傳輸協議
  selectTransmissionProtocol(distance_m, environment) {
    console.log('📡 選擇傳輸協議...\n');

    let best_protocol = null;
    let best_score = -Infinity;

    for (const [protocol, specs] of Object.entries(this.transmission_protocols)) {
      let score = 100;
      
      // 距離衰減
      score -= specs.attenuation * distance_m;
      
      // 環境因素
      if (environment === 'indoor' && protocol === 'lora') score -= 30;
      if (environment === 'underwater' && protocol === 'sound') score += 50;
      if (environment === 'vacuum' && protocol === 'electromagnetic') score += 30;

      if (score > best_score) {
        best_score = score;
        best_protocol = protocol;
      }
    }

    console.log(`   選擇: ${best_protocol}`);
    console.log(`   評分: ${best_score.toFixed(1)}`);
    console.log(`   距離: ${distance_m} m\n`);

    return {
      protocol: best_protocol,
      specs: this.transmission_protocols[best_protocol],
      score: best_score
    };
  }

  // 生成波形
  _generateWaveform(center_freq, bandwidth) {
    const samples = [];
    const sample_rate = 44100; // Hz
    const duration = 0.1; // 秒
    
    for (let i = 0; i < sample_rate * duration; i++) {
      const t = i / sample_rate;
      const frequency = center_freq + (Math.random() - 0.5) * bandwidth;
      const amplitude = Math.sin(2 * Math.PI * frequency * t);
      samples.push(amplitude);
    }
    
    return samples;
  }
}

// ===== 5. PFN.SensorNode.Prototype01 - 感測器節點原型 =====
class SensorNodePrototype {
  constructor(node_id) {
    this.node_id = node_id;
    this.sensors = {
      resistance: { pin: 'A0', unit: 'ohm', calibration: 1.0 },
      current: { pin: 'A1', unit: 'mA', calibration: 1.0 },
      temperature: { pin: 'A2', unit: 'C', calibration: 1.0 },
      pressure: { pin: 'A3', unit: 'kPa', calibration: 1.0 },
      touch: { pin: 'D2', type: 'capacitive', threshold: 50 }
    };

    this.reading_interval_ms = 100;
    this.is_active = false;
    
    console.log(`📟 Sensor Node Prototype 已初始化: ${node_id}`);
    console.log(`   感測器: 電阻、電流、溫度、壓力、觸控`);
    console.log(`   取樣率: ${1000 / this.reading_interval_ms} Hz\n`);
  }

  // 啟動感測
  start() {
    this.is_active = true;
    console.log(`▶️  開始感測 (${this.node_id})\n`);
    
    this.interval = setInterval(() => {
      this.readSensors();
    }, this.reading_interval_ms);
  }

  // 停止感測
  stop() {
    this.is_active = false;
    clearInterval(this.interval);
    console.log(`⏸️  停止感測 (${this.node_id})\n`);
  }

  // 讀取感測器
  readSensors() {
    const readings = {
      node_id: this.node_id,
      timestamp: new Date().toISOString(),
      resistance_ohm: 1000 + Math.random() * 500,
      current_ma: 10 + Math.random() * 90,
      temperature_c: 20 + Math.random() * 15,
      pressure_kpa: 100 + Math.random() * 20,
      touch_detected: Math.random() > 0.8
    };

    // 計算變化率（作為情緒共振輸入）
    if (this.last_reading) {
      readings.delta = {
        resistance: readings.resistance_ohm - this.last_reading.resistance_ohm,
        current: readings.current_ma - this.last_reading.current_ma,
        temperature: readings.temperature_c - this.last_reading.temperature_c,
        pressure: readings.pressure_kpa - this.last_reading.pressure_kpa
      };
    }

    this.last_reading = readings;
    return readings;
  }

  // 轉換為情緒輸入
  toEmotionInput(readings) {
    return {
      current_ma: readings.current_ma,
      temperature_c: readings.temperature_c,
      pressure_level: (readings.pressure_kpa - 100) / 20,
      vibration_hz: readings.delta ? Math.abs(readings.delta.current) * 10 : 0
    };
  }
}

// ===== 整合系統 =====
class FrequencyFieldSystem {
  constructor() {
    this.pfn = new ParticleFrequencyNetwork();
    this.sensewave = new SensewaveOverlaySync();
    this.emotion_overlay = new FlowEmotionOverlay();
    this.frequency_core = new ParticleLanguageFrequencyCore();
    this.sensor_nodes = new Map();
    
    console.log('🌌 Frequency Field System 已整合\n');
  }

  // 完整演示
  async demonstrateFullSystem() {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║   🌊 FREQUENCY FIELD SYSTEM - 完整演示                    ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    // 1. 建立網路
    console.log('═'.repeat(60));
    console.log('第一階段: 建立粒子頻率網路');
    console.log('═'.repeat(60) + '\n');

    const node1 = this.pfn.registerNode('persona.liou.seed', {
      frequency_range: [400, 600],
      modulation: 'frequency',
      carrier_medium: 'electromagnetic'
    });

    const node2 = this.pfn.registerNode('persona.echo.analyst', {
      frequency_range: [500, 700],
      modulation: 'phase',
      carrier_medium: 'light'
    });

    const channel = this.pfn.createChannel('channel_01', 'persona.liou.seed', 'persona.echo.analyst', 528);

    // 2. 傳輸語意粒子
    console.log('═'.repeat(60));
    console.log('第二階段: 傳輸語意粒子');
    console.log('═'.repeat(60) + '\n');

    const semantic_particle = {
      type: '⋄fx.def.evolution',
      content: '提升維度',
      emotion: 'determination',
      timestamp: new Date().toISOString()
    };

    this.pfn.transmitSemanticParticle('channel_01', semantic_particle);

    // 3. 編碼人格狀態
    console.log('═'.repeat(60));
    console.log('第三階段: 編碼人格情緒狀態');
    console.log('═'.repeat(60) + '\n');

    const persona_state = {
      emotion: 'joy',
      pressure: 0.3,
      energy: 0.8
    };

    const encoded_state = this.sensewave.encodePersonaState('liou.seed', persona_state);

    // 4. 解碼情緒
    console.log('═'.repeat(60));
    console.log('第四階段: 解碼情緒頻率');
    console.log('═'.repeat(60) + '\n');

    const decoded_emotion = this.sensewave.decodeEmotionFromFrequency({
      center: 528,
      harmonics: [264, 792, 1056]
    });

    // 5. 感測器模擬
    console.log('═'.repeat(60));
    console.log('第五階段: 感測器節點模擬');
    console.log('═'.repeat(60) + '\n');

    const sensor = new SensorNodePrototype('sensor_hand_01');
    const readings = sensor.readSensors();
    
    console.log('📊 感測器讀數:');
    console.log(`   電阻: ${readings.resistance_ohm.toFixed(0)} Ω`);
    console.log(`   電流: ${readings.current_ma.toFixed(1)} mA`);
    console.log(`   溫度: ${readings.temperature_c.toFixed(1)}°C`);
    console.log(`   壓力: ${readings.pressure_kpa.toFixed(1)} kPa\n`);

    // 6. 生成情緒節奏
    console.log('═'.repeat(60));
    console.log('第六階段: 生成情緒節奏');
    console.log('═'.repeat(60) + '\n');

    const emotion_input = sensor.toEmotionInput(readings);
    const emotion_rhythm = this.emotion_overlay.generateEmotionRhythm(emotion_input);

    console.log(`💫 合成情緒: ${emotion_rhythm.composite_emotion}`);
    console.log(`   頻率簽名: ${emotion_rhythm.frequency_signature.fundamental.toFixed(1)} Hz (基頻)\n`);

    // 7. 粒子語言編解碼
    console.log('═'.repeat(60));
    console.log('第七階段: 粒子語言頻率編解碼');
    console.log('═'.repeat(60) + '\n');

    const particle_encoded = this.frequency_core.encodeParticleToFrequency('⋄fx.def');
    const particle_decoded = this.frequency_core.decodeFrequencyToParticle(150);

    // 8. 傳輸協議選擇
    console.log('═'.repeat(60));
    console.log('第八階段: 傳輸協議選擇');
    console.log('═'.repeat(60) + '\n');

    const protocol = this.frequency_core.selectTransmissionProtocol(100, 'indoor');

    // 完成
    console.log('\n═'.repeat(60));
    console.log('🎉 完整演示完成！');
    console.log('═'.repeat(60) + '\n');

    return {
      network: { node1, node2, channel },
      emotion: { encoded_state, decoded_emotion, emotion_rhythm },
      particle: { particle_encoded, particle_decoded },
      protocol
    };
  }
}

// ===== 演示執行 =====
async function demo() {
  const system = new FrequencyFieldSystem();
  await system.demonstrateFullSystem();
}

demo().catch(console.error);

// 導出
export {
  ParticleFrequencyNetwork,
  SensewaveOverlaySync,
  FlowEmotionOverlay,
  ParticleLanguageFrequencyCore,
  SensorNodePrototype,
  FrequencyFieldSystem
};
