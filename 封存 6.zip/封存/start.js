#!/usr/bin/env node

/**
 * META WORLD PORTAL - 快速啟動腳本
 * 自動安裝依賴並啟動系統
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function banner() {
  console.log(`
${colors.magenta}╔════════════════════════════════════════════════════════════╗
║                                                            ║
║           🌍 META WORLD PORTAL v1.0.0                      ║
║           元世界入口系統                                      ║
║                                                            ║
║   "穿越維度，連結平行世界，守護演化證據"                        ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝${colors.reset}
  `);
}

function checkDependencies() {
  log('\n📦 檢查依賴...', 'cyan');
  
  const packageJsonPath = path.join(process.cwd(), 'package.json');
  const nodeModulesPath = path.join(process.cwd(), 'node_modules');
  
  if (!fs.existsSync(packageJsonPath)) {
    log('❌ 找不到 package.json', 'red');
    process.exit(1);
  }
  
  if (!fs.existsSync(nodeModulesPath)) {
    log('⚠️  未安裝依賴，開始安裝...', 'yellow');
    try {
      execSync('npm install', { stdio: 'inherit' });
      log('✅ 依賴安裝完成', 'green');
    } catch (error) {
      log('❌ 依賴安裝失敗', 'red');
      process.exit(1);
    }
  } else {
    log('✅ 依賴已安裝', 'green');
  }
}

function checkPublicFolder() {
  log('\n📁 檢查公共文件夾...', 'cyan');
  
  const publicPath = path.join(process.cwd(), 'public');
  
  if (!fs.existsSync(publicPath)) {
    log('⚠️  創建 public 文件夾...', 'yellow');
    fs.mkdirSync(publicPath, { recursive: true });
  }
  
  const indexPath = path.join(publicPath, 'index.html');
  if (!fs.existsSync(indexPath)) {
    log('❌ 找不到 public/index.html', 'red');
    log('提示：請確保 index.html 在 public 文件夾中', 'yellow');
  } else {
    log('✅ Web 介面就緒', 'green');
  }
}

function displayInfo() {
  log('\n' + '━'.repeat(60), 'blue');
  log('🚀 啟動資訊', 'blue');
  log('━'.repeat(60), 'blue');
  log('伺服器地址: http://localhost:3000', 'green');
  log('API 文檔: 參見 README.md', 'cyan');
  log('測試腳本: node test.js', 'cyan');
  log('━'.repeat(60) + '\n', 'blue');
}

function startServer() {
  log('🔧 啟動 Meta World Portal...', 'cyan');
  log('按 Ctrl+C 停止服務器\n', 'yellow');
  
  try {
    execSync('node meta_world_portal.js', { stdio: 'inherit' });
  } catch (error) {
    if (error.signal !== 'SIGINT') {
      log('\n❌ 服務器異常退出', 'red');
      process.exit(1);
    }
  }
}

// 主程序
async function main() {
  banner();
  
  try {
    checkDependencies();
    checkPublicFolder();
    displayInfo();
    startServer();
  } catch (error) {
    log(`\n❌ 啟動失敗: ${error.message}`, 'red');
    process.exit(1);
  }
}

// 處理退出信號
process.on('SIGINT', () => {
  log('\n\n👋 感謝使用 Meta World Portal！', 'magenta');
  log('Goodbye!\n', 'cyan');
  process.exit(0);
});

main();
