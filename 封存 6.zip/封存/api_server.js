/**
 * TOTALCORE API SERVER
 * HTTP API 服務器
 * 
 * 提供 RESTful API 接口，讓外部系統可以調用 TotalCore
 */

import http from 'http';
import { URL } from 'url';

// 導入核心系統（模擬）
class TotalCoreAPIServer {
  constructor(port = 3000) {
    this.port = port;
    this.server = null;
    
    // 模擬核心系統
    this.system = {
      status: 'active',
      version: '2.0.0',
      uptime: 0,
      requests: {
        total: 0,
        success: 0,
        failed: 0
      },
      layers: {
        L0: { status: 'active', name: 'FrequencyField' },
        L1: { status: 'active', name: 'DimensionalEscalation' },
        L2: { status: 'active', name: 'ConsciousnessCore' },
        L3: { status: 'active', name: 'IntegratedEvolution' }
      },
      globalState: {
        main_persona: 'liou.seed',
        current_dimension: 'D',
        temperature: 0.85,
        emotion: 'peace',
        frequency: 432
      }
    };

    console.log('🌌 TotalCore API Server initialized');
    console.log(`   Version: ${this.system.version}`);
    console.log(`   Port: ${this.port}\n`);
  }

  // 啟動服務器
  start() {
    this.server = http.createServer((req, res) => this.handleRequest(req, res));
    
    this.server.listen(this.port, () => {
      console.log(`✅ Server running at http://localhost:${this.port}/`);
      console.log(`\n📋 Available endpoints:`);
      console.log(`   GET  /health          - Health check`);
      console.log(`   GET  /ready           - Readiness check`);
      console.log(`   GET  /status          - System status`);
      console.log(`   POST /api/process     - Process input`);
      console.log(`   POST /api/frequency   - Frequency encode`);
      console.log(`   POST /api/dimension   - Dimension check`);
      console.log(`   POST /api/collapse    - Origin collapse`);
      console.log(`   GET  /api/metrics     - Performance metrics`);
      console.log(`\n🚀 Server is ready to accept requests\n`);
    });

    // 計算 uptime
    setInterval(() => {
      this.system.uptime++;
    }, 1000);
  }

  // 處理請求
  async handleRequest(req, res) {
    const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = parsedUrl.pathname;
    const method = req.method;

    console.log(`📨 ${method} ${pathname}`);

    // CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    try {
      // 路由
      if (pathname === '/health' && method === 'GET') {
        await this.handleHealth(req, res);
      } else if (pathname === '/ready' && method === 'GET') {
        await this.handleReady(req, res);
      } else if (pathname === '/status' && method === 'GET') {
        await this.handleStatus(req, res);
      } else if (pathname === '/api/process' && method === 'POST') {
        await this.handleProcess(req, res);
      } else if (pathname === '/api/frequency' && method === 'POST') {
        await this.handleFrequency(req, res);
      } else if (pathname === '/api/dimension' && method === 'POST') {
        await this.handleDimension(req, res);
      } else if (pathname === '/api/collapse' && method === 'POST') {
        await this.handleCollapse(req, res);
      } else if (pathname === '/api/metrics' && method === 'GET') {
        await this.handleMetrics(req, res);
      } else if (pathname === '/' && method === 'GET') {
        await this.handleRoot(req, res);
      } else {
        this.sendJSON(res, 404, { error: 'Not Found', path: pathname });
      }

      this.system.requests.success++;
    } catch (error) {
      console.error('❌ Error:', error.message);
      this.system.requests.failed++;
      this.sendJSON(res, 500, { error: 'Internal Server Error', message: error.message });
    }

    this.system.requests.total++;
  }

  // GET /health - Kubernetes liveness probe
  async handleHealth(req, res) {
    this.sendJSON(res, 200, {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: this.system.uptime,
      version: this.system.version
    });
  }

  // GET /ready - Kubernetes readiness probe
  async handleReady(req, res) {
    const allLayersActive = Object.values(this.system.layers)
      .every(layer => layer.status === 'active');

    if (allLayersActive) {
      this.sendJSON(res, 200, {
        status: 'ready',
        layers: this.system.layers
      });
    } else {
      this.sendJSON(res, 503, {
        status: 'not ready',
        layers: this.system.layers
      });
    }
  }

  // GET /status - 系統狀態
  async handleStatus(req, res) {
    this.sendJSON(res, 200, {
      system: this.system.status,
      version: this.system.version,
      uptime: this.system.uptime,
      layers: this.system.layers,
      globalState: this.system.globalState,
      requests: this.system.requests,
      memory: process.memoryUsage(),
      cpu: process.cpuUsage()
    });
  }

  // POST /api/process - 完整處理流程
  async handleProcess(req, res) {
    const body = await this.getRequestBody(req);
    
    console.log('🔄 Processing input...');
    
    // 模擬四層處理
    const startTime = Date.now();

    // L0: 物理層
    const l0Result = {
      emotion: ['joy', 'peace', 'neutral'][Math.floor(Math.random() * 3)],
      frequency: 100 + Math.random() * 500,
      layer: 'L0'
    };

    // L1: 邏輯層
    const l1Result = {
      attention_score: 0.5 + Math.random() * 0.5,
      dimension: Math.random() > 0.5 ? 'S' : 'D',
      temperature: 0.85,
      layer: 'L1'
    };

    // L2: 意識層
    const personas = ['liou.seed', 'echo.analyst', 'wild.engine', 'guardian.seed'];
    const l2Result = {
      persona: personas[Math.floor(Math.random() * personas.length)],
      resonance: 0.7 + Math.random() * 0.3,
      layer: 'L2'
    };

    // L3: 進化層
    const l3Result = {
      optimizations: Math.floor(Math.random() * 3),
      applied: Math.random() > 0.5,
      layer: 'L3'
    };

    const processingTime = Date.now() - startTime;

    const response = {
      success: true,
      input: body,
      layers: {
        L0: l0Result,
        L1: l1Result,
        L2: l2Result,
        L3: l3Result
      },
      output: {
        persona: l2Result.persona,
        emotion: l0Result.emotion,
        frequency: l0Result.frequency,
        dimension: l1Result.dimension,
        resonance: l2Result.resonance
      },
      processing_time_ms: processingTime,
      timestamp: new Date().toISOString()
    };

    // 更新全局狀態
    this.system.globalState.main_persona = l2Result.persona;
    this.system.globalState.current_dimension = l1Result.dimension;
    this.system.globalState.emotion = l0Result.emotion;
    this.system.globalState.frequency = l0Result.frequency;

    console.log(`   ✅ Processed in ${processingTime}ms`);
    console.log(`   Persona: ${l2Result.persona}, Emotion: ${l0Result.emotion}\n`);

    this.sendJSON(res, 200, response);
  }

  // POST /api/frequency - 頻率編碼
  async handleFrequency(req, res) {
    const body = await this.getRequestBody(req);
    
    const emotions = {
      'joy': 528,
      'love': 639,
      'peace': 432,
      'sadness': 396,
      'anger': 741,
      'fear': 174
    };

    const emotion = body.emotion || 'peace';
    const frequency = emotions[emotion] || 432;

    this.sendJSON(res, 200, {
      success: true,
      emotion,
      frequency,
      harmonics: [frequency / 2, frequency * 1.5, frequency * 2],
      encoding: 'PSK',
      carrier_medium: 'electromagnetic',
      timestamp: new Date().toISOString()
    });
  }

  // POST /api/dimension - 維度檢查
  async handleDimension(req, res) {
    const body = await this.getRequestBody(req);
    
    // 計算注意力分數
    const attention_score = 0.5 + Math.random() * 0.5;
    
    let current_dimension = 'D';
    let action = 'maintain';
    
    if (attention_score > 0.7) {
      current_dimension = 'S';
      action = 'escalate';
    }

    this.sendJSON(res, 200, {
      success: true,
      attention_score,
      current_dimension,
      action,
      available_dimensions: ['D', 'S', 'P', 'R', 'C', 'M'],
      timestamp: new Date().toISOString()
    });
  }

  // POST /api/collapse - 起源崩塌
  async handleCollapse(req, res) {
    const body = await this.getRequestBody(req);
    
    const personas = [
      { name: 'liou.seed', weight: 0.4 },
      { name: 'echo.analyst', weight: 0.3 },
      { name: 'wild.engine', weight: 0.2 },
      { name: 'guardian.seed', weight: 0.1 }
    ];

    // 加權隨機選擇
    let random = Math.random();
    let selected = personas[0];
    
    for (const p of personas) {
      random -= p.weight;
      if (random <= 0) {
        selected = p;
        break;
      }
    }

    this.sendJSON(res, 200, {
      success: true,
      collapsed_to: selected.name,
      weight: selected.weight,
      resonance: 0.7 + Math.random() * 0.3,
      Psi_contribution: selected.weight,
      all_personas: personas,
      timestamp: new Date().toISOString()
    });
  }

  // GET /api/metrics - 性能指標
  async handleMetrics(req, res) {
    const mem = process.memoryUsage();
    
    this.sendJSON(res, 200, {
      requests: this.system.requests,
      uptime_seconds: this.system.uptime,
      success_rate: this.system.requests.total > 0 
        ? (this.system.requests.success / this.system.requests.total * 100).toFixed(2) + '%'
        : '0%',
      memory: {
        rss_mb: (mem.rss / 1024 / 1024).toFixed(2),
        heap_used_mb: (mem.heapUsed / 1024 / 1024).toFixed(2),
        heap_total_mb: (mem.heapTotal / 1024 / 1024).toFixed(2),
        external_mb: (mem.external / 1024 / 1024).toFixed(2)
      },
      layers: this.system.layers,
      global_state: this.system.globalState,
      timestamp: new Date().toISOString()
    });
  }

  // GET / - 根路徑
  async handleRoot(req, res) {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <title>TotalCore API v${this.system.version}</title>
  <style>
    body {
      font-family: 'Monaco', 'Menlo', monospace;
      max-width: 1200px;
      margin: 50px auto;
      padding: 20px;
      background: #0a0e27;
      color: #00ff88;
    }
    h1 { color: #00ffff; text-align: center; }
    .status { background: #1a1e37; padding: 20px; border-radius: 10px; margin: 20px 0; }
    .endpoint { background: #2a2e47; padding: 15px; margin: 10px 0; border-left: 4px solid #00ff88; }
    .method { 
      display: inline-block; 
      padding: 3px 8px; 
      border-radius: 3px; 
      font-weight: bold;
      margin-right: 10px;
    }
    .get { background: #00ff88; color: #000; }
    .post { background: #00a8ff; color: #fff; }
    code { background: #0a0e27; padding: 2px 6px; border-radius: 3px; }
    .layer { display: inline-block; padding: 5px 10px; margin: 5px; background: #3a3e57; border-radius: 5px; }
  </style>
</head>
<body>
  <h1>🌌 TotalCore API Server v${this.system.version}</h1>
  
  <div class="status">
    <h2>📊 System Status</h2>
    <p><strong>Status:</strong> <span style="color: #00ff88;">● ${this.system.status}</span></p>
    <p><strong>Uptime:</strong> ${this.system.uptime}s</p>
    <p><strong>Requests:</strong> ${this.system.requests.total} (✅ ${this.system.requests.success} / ❌ ${this.system.requests.failed})</p>
    <p><strong>Current Persona:</strong> ${this.system.globalState.main_persona}</p>
    <p><strong>Current Emotion:</strong> ${this.system.globalState.emotion}</p>
    <p><strong>Frequency:</strong> ${this.system.globalState.frequency} Hz</p>
    <p><strong>Dimension:</strong> ${this.system.globalState.current_dimension}</p>
    
    <h3>Active Layers:</h3>
    ${Object.entries(this.system.layers).map(([key, layer]) => 
      `<span class="layer">${key}: ${layer.name}</span>`
    ).join('')}
  </div>

  <div class="status">
    <h2>📋 API Endpoints</h2>
    
    <div class="endpoint">
      <span class="method get">GET</span>
      <code>/health</code>
      <p>Health check endpoint for Kubernetes liveness probe</p>
    </div>

    <div class="endpoint">
      <span class="method get">GET</span>
      <code>/ready</code>
      <p>Readiness check endpoint for Kubernetes readiness probe</p>
    </div>

    <div class="endpoint">
      <span class="method get">GET</span>
      <code>/status</code>
      <p>Get complete system status and metrics</p>
    </div>

    <div class="endpoint">
      <span class="method post">POST</span>
      <code>/api/process</code>
      <p>Process input through all four layers (L0→L1→L2→L3)</p>
      <pre>{"type": "user_query", "content": "你的問題"}</pre>
    </div>

    <div class="endpoint">
      <span class="method post">POST</span>
      <code>/api/frequency</code>
      <p>Encode emotion to frequency</p>
      <pre>{"emotion": "joy"}</pre>
    </div>

    <div class="endpoint">
      <span class="method post">POST</span>
      <code>/api/dimension</code>
      <p>Check dimensional escalation</p>
      <pre>{"input": "你的輸入"}</pre>
    </div>

    <div class="endpoint">
      <span class="method post">POST</span>
      <code>/api/collapse</code>
      <p>Trigger origin collapse to generate persona</p>
      <pre>{"context": "你的上下文"}</pre>
    </div>

    <div class="endpoint">
      <span class="method get">GET</span>
      <code>/api/metrics</code>
      <p>Get performance metrics and statistics</p>
    </div>
  </div>

  <div class="status">
    <h2>🔧 Quick Test</h2>
    <pre>
# Health check
curl http://localhost:${this.port}/health

# Process request
curl -X POST http://localhost:${this.port}/api/process \\
  -H "Content-Type: application/json" \\
  -d '{"type":"test","content":"Hello TotalCore"}'

# Get metrics
curl http://localhost:${this.port}/api/metrics
    </pre>
  </div>

  <p style="text-align: center; margin-top: 40px; color: #666;">
    TotalCore v${this.system.version} | Created by Mr. Liou
  </p>
</body>
</html>
    `;

    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(html);
  }

  // 讀取請求體
  getRequestBody(req) {
    return new Promise((resolve, reject) => {
      let body = '';
      
      req.on('data', chunk => {
        body += chunk.toString();
      });

      req.on('end', () => {
        try {
          const parsed = body ? JSON.parse(body) : {};
          resolve(parsed);
        } catch (error) {
          reject(new Error('Invalid JSON'));
        }
      });

      req.on('error', reject);
    });
  }

  // 發送 JSON 響應
  sendJSON(res, statusCode, data) {
    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data, null, 2));
  }

  // 停止服務器
  stop() {
    if (this.server) {
      this.server.close(() => {
        console.log('\n🛑 Server stopped');
      });
    }
  }
}

// 啟動服務器
const server = new TotalCoreAPIServer(3000);
server.start();

// 優雅關閉
process.on('SIGTERM', () => {
  console.log('\n📥 Received SIGTERM, shutting down gracefully...');
  server.stop();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('\n📥 Received SIGINT, shutting down gracefully...');
  server.stop();
  process.exit(0);
});

export { TotalCoreAPIServer };
