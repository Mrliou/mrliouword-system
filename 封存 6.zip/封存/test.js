/**
 * META WORLD PORTAL - 系統測試腳本
 * 驗證所有功能模組
 */

const BASE_URL = 'http://localhost:3000';

// 顏色輸出
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

async function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 測試套件
class TestSuite {
  constructor(name) {
    this.name = name;
    this.tests = [];
    this.passed = 0;
    this.failed = 0;
  }

  async test(name, fn) {
    try {
      log(`\n  ▶ ${name}`, 'cyan');
      await fn();
      this.passed++;
      log(`  ✓ ${name} 通過`, 'green');
    } catch (error) {
      this.failed++;
      log(`  ✗ ${name} 失敗: ${error.message}`, 'red');
    }
  }

  summary() {
    log(`\n${'='.repeat(60)}`, 'blue');
    log(`${this.name} 測試結果`, 'blue');
    log(`${'='.repeat(60)}`, 'blue');
    log(`✓ 通過: ${this.passed}`, 'green');
    log(`✗ 失敗: ${this.failed}`, 'red');
    log(`總計: ${this.passed + this.failed}`, 'yellow');
    log(`${'='.repeat(60)}\n`, 'blue');
  }
}

// HTTP 請求封裝
async function request(method, path, body = null) {
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' }
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(`${BASE_URL}${path}`, options);
  return await response.json();
}

// ===== 測試開始 =====
async function runTests() {
  log('\n🌍 META WORLD PORTAL 系統測試\n', 'magenta');

  // ===== 1. 系統初始化測試 =====
  const suite1 = new TestSuite('系統初始化');

  await suite1.test('初始化 Portal', async () => {
    const result = await request('POST', '/api/portal/init');
    if (!result.ok) throw new Error('初始化失敗');
  });

  await wait(1000);

  await suite1.test('檢查系統狀態', async () => {
    const status = await request('GET', '/api/portal/status');
    if (!status.meta_env) throw new Error('MetaEnv 未啟動');
    if (!status.personas) throw new Error('Persona 引擎未啟動');
    if (!status.particles) throw new Error('Particle 系統未啟動');
    log(`    粒子數量: ${status.particles.count}`, 'yellow');
  });

  suite1.summary();

  // ===== 2. MetaEnv 沙盒測試 =====
  const suite2 = new TestSuite('MetaEnv 沙盒');

  let testEnvId = null;

  await suite2.test('啟動新環境', async () => {
    const result = await request('POST', '/api/metaenv/spawn', {
      role: 'node',
      shape: { cpu: 2, gpu: 1, ram: '8G' },
      policy: 'Mr.liou.MetaCode.Guard.v1'
    });
    if (!result.ok) throw new Error('環境啟動失敗');
    testEnvId = result.env_id;
    log(`    Env ID: ${testEnvId.substring(0, 20)}...`, 'yellow');
  });

  await suite2.test('健康檢查', async () => {
    const health = await request('GET', `/api/metaenv/health?env_id=${testEnvId}`);
    if (!health.ok) throw new Error('環境不健康');
  });

  await suite2.test('創建快照', async () => {
    const snapshot = await request('POST', '/api/metaenv/snapshot', {
      env_id: testEnvId,
      label: '測試快照'
    });
    if (!snapshot.ok) throw new Error('快照創建失敗');
    log(`    Snapshot ID: ${snapshot.snapshot_id.substring(0, 20)}...`, 'yellow');
  });

  suite2.summary();

  // ===== 3. 平行人格引擎測試 =====
  const suite3 = new TestSuite('平行人格引擎');

  let personaCodeY = null;
  let personaCodeN = null;

  await suite3.test('創建決策分支', async () => {
    const result = await request('POST', '/api/persona/decision', {
      question: '我該參加這個測試嗎？'
    });
    if (!result.decision) throw new Error('決策創建失敗');
    personaCodeY = result.forks.yes.code;
    personaCodeN = result.forks.no.code;
    log(`    YES: ${personaCodeY}`, 'yellow');
    log(`    NO: ${personaCodeN}`, 'yellow');
  });

  await suite3.test('列出人格', async () => {
    const result = await request('GET', '/api/persona/list');
    if (!result.personas || result.personas.length === 0) {
      throw new Error('人格列表為空');
    }
    log(`    人格數量: ${result.personas.length}`, 'yellow');
  });

  await suite3.test('穿越到 YES 世界', async () => {
    const result = await request('POST', '/api/persona/travel', {
      persona_code: personaCodeY
    });
    if (!result.ok) throw new Error('穿越失敗');
    log(`    新 Env ID: ${result.env_id.substring(0, 20)}...`, 'yellow');
  });

  suite3.summary();

  // ===== 4. 粒子宇宙測試 =====
  const suite4 = new TestSuite('粒子宇宙');

  await suite4.test('執行粒子演化 (Round 1)', async () => {
    const result = await request('POST', '/api/particle/evolve');
    if (!result.particles) throw new Error('演化失敗');
    log(`    演化粒子數: ${result.particles.length}`, 'yellow');
  });

  await wait(500);

  await suite4.test('執行粒子演化 (Round 2)', async () => {
    const result = await request('POST', '/api/particle/evolve');
    if (!result.particles) throw new Error('演化失敗');
  });

  await wait(500);

  await suite4.test('執行粒子演化 (Round 3)', async () => {
    const result = await request('POST', '/api/particle/evolve');
    if (!result.particles) throw new Error('演化失敗');
  });

  await suite4.test('獲取演化歷史', async () => {
    const history = await request('GET', '/api/particle/history');
    if (!history.history || history.history.length === 0) {
      throw new Error('歷史為空');
    }
    log(`    演化輪數: ${history.total_rounds}`, 'yellow');
  });

  suite4.summary();

  // ===== 5. 證據溯源測試 =====
  const suite5 = new TestSuite('證據溯源');

  await suite5.test('獲取證據日誌', async () => {
    const result = await request('GET', '/api/provenance/evidence');
    if (!result.evidence) throw new Error('證據日誌獲取失敗');
    log(`    證據條目: ${result.evidence.length}`, 'yellow');
  });

  await suite5.test('獲取時間線', async () => {
    const result = await request('GET', '/api/provenance/timeline');
    if (!result.timeline) throw new Error('時間線獲取失敗');
    log(`    時間線事件: ${result.timeline.length}`, 'yellow');
  });

  await suite5.test('獲取 PU 快照', async () => {
    const result = await request('GET', '/api/provenance/snapshots');
    if (!result.snapshots) throw new Error('快照獲取失敗');
    log(`    PU 快照數: ${result.snapshots.length}`, 'yellow');
  });

  suite5.summary();

  // ===== 6. 最終狀態檢查 =====
  const suite6 = new TestSuite('最終狀態檢查');

  await suite6.test('完整狀態驗證', async () => {
    const status = await request('GET', '/api/portal/status');
    
    log('\n    📊 最終系統狀態:', 'cyan');
    log(`    ├─ MetaEnv: ${status.meta_env.total_envs} 個環境`, 'yellow');
    log(`    ├─ 人格: ${status.personas.branches} 個分支`, 'yellow');
    log(`    ├─ 決策: ${status.personas.decisions} 個決策`, 'yellow');
    log(`    ├─ 粒子: ${status.particles.count} 個`, 'yellow');
    log(`    ├─ 演化輪數: ${status.particles.rounds}`, 'yellow');
    log(`    ├─ 證據: ${status.provenance.evidence_count} 條`, 'yellow');
    log(`    └─ 時間線: ${status.provenance.timeline_events} 個事件`, 'yellow');
  });

  suite6.summary();

  // ===== 總結 =====
  const totalPassed = suite1.passed + suite2.passed + suite3.passed + 
                      suite4.passed + suite5.passed + suite6.passed;
  const totalFailed = suite1.failed + suite2.failed + suite3.failed + 
                      suite4.failed + suite5.failed + suite6.failed;

  log('\n' + '═'.repeat(60), 'magenta');
  log('🎉 全部測試完成', 'magenta');
  log('═'.repeat(60), 'magenta');
  log(`✓ 總通過: ${totalPassed}`, 'green');
  log(`✗ 總失敗: ${totalFailed}`, 'red');
  log(`成功率: ${((totalPassed / (totalPassed + totalFailed)) * 100).toFixed(2)}%`, 'yellow');
  log('═'.repeat(60) + '\n', 'magenta');

  if (totalFailed === 0) {
    log('🌟 所有測試通過！系統運行正常。\n', 'green');
  } else {
    log('⚠️  部分測試失敗，請檢查系統。\n', 'yellow');
  }
}

// 執行測試
log('等待服務器啟動...', 'yellow');
setTimeout(() => {
  runTests().catch(error => {
    log(`\n❌ 測試執行錯誤: ${error.message}\n`, 'red');
    process.exit(1);
  });
}, 2000);
