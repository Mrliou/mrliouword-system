# MrLiouWord Particle Systems License v1.0
# MrLiouWord 粒子系統授權條款 v1.0

```
╔══════════════════════════════════════════════════════════════════╗
║                                                                    ║
║   PROPRIETARY LICENSE / 專有授權                                  ║
║   Version 1.0 / 版本 1.0                                          ║
║   Effective Date: January 14, 2026                                 ║
║                                                                    ║
║   Origin Signature: MrLiouWord                                     ║
║                                                                    ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## PREAMBLE / 前言

This license governs the use of all software, documentation, algorithms, architectures, and related materials (collectively, the "Work") created by Mr. Liou under the MrLiouWord origin signature.

本授權條款規範由劉先生以 MrLiouWord 原始簽章創作的所有軟體、文件、演算法、架構及相關材料（統稱「作品」）的使用。

---

## ARTICLE 1: DEFINITIONS / 第一條：定義

**1.1 "Work"** means all source code, object code, documentation, algorithms, data structures, architectures, designs, concepts, and any other materials contained in or associated with the MrLiouWord Particle Systems.

**「作品」** 指 MrLiouWord 粒子系統中包含或相關的所有原始碼、目的碼、文件、演算法、資料結構、架構、設計、概念及任何其他材料。

**1.2 "Licensor"** means Mr. Liou (劉先生), the sole creator and owner of the Work.

**「授權人」** 指作品的唯一創作者和所有者劉先生 (Mr. Liou)。

**1.3 "You" / "Licensee"** means any individual or legal entity exercising rights under this License.

**「您」/「被授權人」** 指依據本授權條款行使權利的任何個人或法人實體。

**1.4 "Commercial Use"** means any use intended for or directed toward commercial advantage or monetary compensation.

**「商業使用」** 指任何以商業利益或金錢補償為目的或導向的使用。

**1.5 "Derivative Work"** means any work based upon the Work, including translations, adaptations, modifications, or any form that may be recast, transformed, or adapted.

**「衍生作品」** 指任何基於本作品的作品，包括翻譯、改編、修改或任何可能被重製、轉換或改編的形式。

---

## ARTICLE 2: GRANT OF RIGHTS / 第二條：權利授予

### 2.1 Permitted Uses / 允許的使用

Subject to the terms of this License, Licensor grants You a limited, non-exclusive, non-transferable, revocable license to:

在遵守本授權條款的前提下，授權人授予您有限的、非專屬的、不可轉讓的、可撤銷的授權，以：

| Permission | Conditions | 權限 | 條件 |
|------------|------------|------|------|
| ✅ **Personal Study** | Non-commercial, private use only | ✅ **個人學習** | 僅限非商業、私人使用 |
| ✅ **Academic Research** | Must cite source, non-commercial | ✅ **學術研究** | 須註明來源，非商業 |
| ✅ **View Source Code** | Read-only, no copying | ✅ **查看原始碼** | 僅限閱讀，不可複製 |
| ✅ **Educational Reference** | With attribution, non-commercial | ✅ **教育參考** | 須註明出處，非商業 |

### 2.2 Prohibited Uses / 禁止的使用

You may NOT, without prior written authorization from Licensor:

未經授權人事先書面同意，您不得：

| Prohibition | Reason | 禁止事項 | 原因 |
|-------------|--------|----------|------|
| ❌ **Commercial Use** | Requires commercial license | ❌ **商業使用** | 需商業授權 |
| ❌ **Redistribute** | Protects distribution rights | ❌ **再散布** | 保護散布權 |
| ❌ **Create Derivatives** | Protects creative integrity | ❌ **創作衍生作品** | 保護創作完整性 |
| ❌ **Sublicense** | No delegation permitted | ❌ **再授權** | 不允許委託 |
| ❌ **Remove Attribution** | Violates moral rights | ❌ **移除署名** | 侵犯著作人格權 |
| ❌ **Patent Claims** | Reserved by Licensor | ❌ **專利主張** | 由授權人保留 |
| ❌ **AI Training** | Data not for ML models | ❌ **AI 訓練** | 資料不得用於機器學習模型 |
| ❌ **Reverse Engineering** | Trade secret protection | ❌ **逆向工程** | 商業機密保護 |

---

## ARTICLE 3: ATTRIBUTION REQUIREMENTS / 第三條：署名要求

### 3.1 Required Attribution / 必要署名

Any permitted use must include the following attribution:

任何允許的使用必須包含以下署名：

```
MrLiouWord Particle Systems
Copyright © 2024-2026 Mr. Liou
Origin Signature: MrLiouWord
https://github.com/dofaromg/mrliouword-system
```

### 3.2 Attribution Placement / 署名位置

- In source code: As a comment header in every file
- In documentation: In a prominent location, first page or equivalent
- In presentations: On the title slide and credits
- In academic work: In the citations/references section

---

## ARTICLE 4: COMMERCIAL LICENSING / 第四條：商業授權

### 4.1 Commercial License Required / 需商業授權

Any commercial use requires a separate Commercial License Agreement. Contact:

任何商業使用需另行簽訂商業授權合約。聯繫方式：

- **Email**: [To be specified by Mr. Liou]
- **GitHub**: @dofaromg

### 4.2 Commercial License Types / 商業授權類型

| License Type | Scope | 授權類型 | 範圍 |
|--------------|-------|----------|------|
| **Single Project** | One product/service | **單一專案** | 一項產品/服務 |
| **Enterprise** | Unlimited internal use | **企業** | 無限內部使用 |
| **OEM** | Integration into commercial products | **OEM** | 整合至商業產品 |
| **Full Transfer** | Complete IP acquisition | **完整轉讓** | 完整智財取得 |

---

## ARTICLE 5: INTELLECTUAL PROPERTY / 第五條：智慧財產權

### 5.1 Ownership / 所有權

All intellectual property rights in the Work remain exclusively with the Licensor. This License does not transfer any ownership rights.

作品中的所有智慧財產權仍專屬於授權人。本授權不轉讓任何所有權。

### 5.2 Reserved Rights / 保留權利

Licensor expressly reserves all rights not explicitly granted herein, including but not limited to:

授權人明確保留本文未明確授予的所有權利，包括但不限於：

- Patent rights (專利權)
- Trademark rights (商標權)
- Trade secret rights (商業機密權)
- Moral rights (著作人格權)

---

## ARTICLE 6: WARRANTY DISCLAIMER / 第六條：保證免責聲明

THE WORK IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.

本作品按「現狀」提供，不附帶任何明示或暗示的保證，包括但不限於適銷性、特定目的適用性和不侵權的保證。

---

## ARTICLE 7: LIMITATION OF LIABILITY / 第七條：責任限制

IN NO EVENT SHALL THE LICENSOR BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE WORK.

在任何情況下，授權人均不對因本作品引起或與之相關的任何索賠、損害或其他責任負責，無論是合約訴訟、侵權訴訟或其他訴訟。

---

## ARTICLE 8: TERMINATION / 第八條：終止

### 8.1 Automatic Termination / 自動終止

This License automatically terminates if You violate any of its terms.

如您違反本授權條款的任何條款，本授權將自動終止。

### 8.2 Effects of Termination / 終止效果

Upon termination:
終止後：

- All rights granted hereunder immediately cease (所有授予的權利立即終止)
- You must destroy all copies of the Work in Your possession (您必須銷毀您持有的所有作品副本)
- Licensor may pursue all available legal remedies (授權人可尋求所有可用的法律救濟)

---

## ARTICLE 9: MISCELLANEOUS / 第九條：其他條款

### 9.1 Governing Law / 準據法

This License shall be governed by the laws of the Republic of China (Taiwan).

本授權條款應受中華民國（台灣）法律管轄。

### 9.2 Severability / 可分割性

If any provision of this License is held invalid or unenforceable, the remaining provisions shall continue in full force and effect.

如本授權條款的任何條款被認定無效或不可執行，其餘條款應繼續完全有效。

### 9.3 Entire Agreement / 完整協議

This License constitutes the entire agreement between the parties concerning the Work.

本授權條款構成雙方關於本作品的完整協議。

### 9.4 Amendments / 修訂

This License may only be amended by a written document signed by the Licensor.

本授權條款僅能通過授權人簽署的書面文件進行修訂。

---

## SIGNATURE / 簽章

```
Origin Signature: MrLiouWord
Licensor: Mr. Liou (劉先生)
Date: January 14, 2026
Version: 1.0
```

---

**© 2024-2026 Mr. Liou. All Rights Reserved.**
**怎麼過去，就怎麼回來**
