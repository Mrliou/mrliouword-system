# COPYRIGHT NOTICE / 版權聲明

```
╔══════════════════════════════════════════════════════════════════╗
║                                                                    ║
║   MrLiouWord Particle Systems / MrLiouWord 粒子系統               ║
║                                                                    ║
║   Copyright © 2024-2026 Mr. Liou (劉先生)                         ║
║   All Rights Reserved / 版權所有                                  ║
║                                                                    ║
║   Origin Signature: MrLiouWord                                     ║
║   Creation Date: 2024                                              ║
║   Registration Date: January 2026                                  ║
║                                                                    ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## 📜 English Version

### INTELLECTUAL PROPERTY NOTICE

This repository and all its contents, including but not limited to:

- **Source Code** - All programming code in any language (TypeScript, Python, Pascal/Delphi, JavaScript, C, Shell, F++, etc.)
- **Architecture Designs** - System architecture, L0-L7 layer structure, particle system design
- **Algorithms** - All algorithms including but not limited to: Octree spatial indexing, SAT/PEF collision detection, SimHash64 semantic fingerprinting, δP₀ micro-units, Origin Collapse mechanism
- **Data Structures** - atom_t 40-byte structures, compressed_seq/compressed_map, MemoryVault seven-layer architecture
- **Documentation** - All technical documentation, specifications, and explanatory materials
- **Concepts & Philosophy** - "怎麼過去就怎麼回來" (How you go is how you come back), complete reversibility principle, Liou Closure Law
- **Brand Elements** - "MrLiouWord", "Particle Globe", "LUX Engine", "FluinOS", "FlowAgent", "F++ Language"

are the **exclusive intellectual property** of **Mr. Liou (劉先生)**.

### PROTECTED ELEMENTS

| Category | Components | Protection Type |
|----------|------------|-----------------|
| **Core System** | L0-L7 Architecture, Particle Systems | Trade Secret + Copyright |
| **Engines** | LUX 3D Geometry Engine | Copyright + Patent Pending |
| **Frameworks** | FluinOS, FlowAgent, F++ Language | Copyright + Trademark |
| **Algorithms** | Origin Collapse, SimHash64, δP₀ | Patent Pending |
| **Data Formats** | .flpkg, atom_t, compressed_seq | Copyright |
| **Brand** | MrLiouWord, origin_signature | Trademark |

### OWNERSHIP DECLARATION

The undersigned hereby declares:

1. I am the **sole creator and owner** of all intellectual property contained herein
2. All work was created **independently** with AI assistance as tools
3. No third-party proprietary code or algorithms were incorporated without proper licensing
4. This work represents **original creative and technical expression**

---

## 📜 中文版本

### 智慧財產權聲明

本儲存庫及其所有內容，包括但不限於：

- **原始碼** - 所有程式語言的程式碼（TypeScript、Python、Pascal/Delphi、JavaScript、C、Shell、F++ 等）
- **架構設計** - 系統架構、L0-L7 分層結構、粒子系統設計
- **演算法** - 所有演算法，包括但不限於：Octree 空間索引、SAT/PEF 碰撞檢測、SimHash64 語義指紋、δP₀ 微單位、Origin Collapse 機制
- **資料結構** - atom_t 40位元組結構、compressed_seq/compressed_map、MemoryVault 七層架構
- **文件** - 所有技術文件、規格說明和解釋性材料
- **概念與哲學** - 「怎麼過去就怎麼回來」、完全可逆性原則、Liou 閉合定律
- **品牌元素** - 「MrLiouWord」、「Particle Globe」、「LUX Engine」、「FluinOS」、「FlowAgent」、「F++ Language」

均為 **劉先生 (Mr. Liou)** 的**專有智慧財產**。

### 所有權聲明

本人在此聲明：

1. 本人為本文所含所有智慧財產的**唯一創作者和所有者**
2. 所有作品均為**獨立創作**，AI 僅作為輔助工具
3. 未納入任何未經適當授權的第三方專有程式碼或演算法
4. 本作品代表**原創的創意和技術表達**

---

## ⚖️ Legal Enforcement / 法律執行

Any unauthorized use, reproduction, distribution, or creation of derivative works will be subject to legal action under applicable intellectual property laws, including but not limited to:

任何未經授權的使用、複製、分發或創作衍生作品，將依據適用的智慧財產權法律追究法律責任，包括但不限於：

- **中華民國著作權法** (Taiwan Copyright Act)
- **中華民國專利法** (Taiwan Patent Act)
- **中華民國商標法** (Taiwan Trademark Act)
- **United States Copyright Act (17 U.S.C.)**
- **United States Patent Act (35 U.S.C.)**
- **Berne Convention for the Protection of Literary and Artistic Works**
- **WIPO Copyright Treaty**
- **Trade-Related Aspects of Intellectual Property Rights (TRIPS)**

---

## 📅 Timestamp / 時間戳記

```
Document Created: 2026-01-14
Origin Signature: MrLiouWord
Hash Verification: [To be filled with blockchain timestamp]
```

---

**© 2024-2026 Mr. Liou. All Rights Reserved.**
**Origin Signature: MrLiouWord**
