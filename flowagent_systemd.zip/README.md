FlowAgent systemd installer package
==================================

Contents:
- flowagent.service        -> Systemd unit file content
- installer.sh             -> Root-install script (copies unit to /etc/systemd/system and enables it)
- README.md                -> This file

Usage:
1. Place docker-compose.yml and other artifacts in /srv/flowagent as in previous package.
2. Copy flowagent.service to /etc/systemd/system/flowagent.service (or run installer.sh as root).
3. Run: systemctl daemon-reload
4. Start service: systemctl start flowagent
5. Enable at boot: systemctl enable flowagent

Notes:
- The unit uses `docker compose` command. Ensure Docker Compose CLI is installed and available at /usr/bin/docker compose.
- The unit currently runs ExecStart as root for simplicity. For stricter security, create a dedicated user 'flowagent', grant it docker group membership, and change 'User=' accordingly.
