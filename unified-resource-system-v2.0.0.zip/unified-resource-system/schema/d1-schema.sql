-- MrLiouWord Unified Resource System - D1 Schema
-- 
-- 核心原則：
-- - SoT (Source of Truth): 明確的來源權威
-- - Revision: 單調遞增版本線
-- - Resume: 冪等續跑機制
-- - Conflicts: 衝突審計記錄
--
-- Author: MR.liou × Claude
-- Philosophy: 怎麼過去，就怎麼回來

-- ============================================
-- 統一資源表
-- ============================================
CREATE TABLE IF NOT EXISTS unified_resources (
    id TEXT PRIMARY KEY,
    rev INTEGER NOT NULL DEFAULT 1,
    sot TEXT NOT NULL CHECK (sot IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    layer TEXT NOT NULL CHECK (layer IN ('L∞', 'L7', 'L6', 'L5', 'L4', 'L3', 'L2', 'L1', 'L0')),
    type TEXT NOT NULL,
    name TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    content_type TEXT,
    size INTEGER,
    encoding TEXT DEFAULT 'utf-8',
    checksum TEXT,
    origin_signature TEXT NOT NULL DEFAULT 'MrLiouWord',
    sync_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (sync_status IN ('PENDING', 'SYNCING', 'SYNCED', 'CONFLICT', 'FAILED', 'SKIPPED')),
    custom_metadata TEXT,  -- JSON 格式的自定義元資料
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    deleted_at INTEGER,
    
    -- 確保版本單調遞增的檢查在應用層實現
    UNIQUE(id, rev)
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_resources_type ON unified_resources(type);
CREATE INDEX IF NOT EXISTS idx_resources_layer ON unified_resources(layer);
CREATE INDEX IF NOT EXISTS idx_resources_sot ON unified_resources(sot);
CREATE INDEX IF NOT EXISTS idx_resources_sync_status ON unified_resources(sync_status);
CREATE INDEX IF NOT EXISTS idx_resources_rev ON unified_resources(rev);
CREATE INDEX IF NOT EXISTS idx_resources_updated ON unified_resources(updated_at);
CREATE INDEX IF NOT EXISTS idx_resources_content_hash ON unified_resources(content_hash);

-- ============================================
-- 資源標籤關聯表（正規化設計）
-- ============================================
CREATE TABLE IF NOT EXISTS resource_tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    resource_id TEXT NOT NULL,
    tag TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (resource_id) REFERENCES unified_resources(id) ON DELETE CASCADE,
    UNIQUE(resource_id, tag)
);

CREATE INDEX IF NOT EXISTS idx_tags_resource ON resource_tags(resource_id);
CREATE INDEX IF NOT EXISTS idx_tags_tag ON resource_tags(tag);

-- ============================================
-- 記憶表（with SoT/Revision）
-- ============================================
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    rev INTEGER NOT NULL DEFAULT 1,
    sot TEXT NOT NULL DEFAULT 'D1' CHECK (sot IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    content TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'general',
    prev_hash TEXT NOT NULL,
    current_hash TEXT NOT NULL,
    layer TEXT NOT NULL DEFAULT 'L1' CHECK (layer IN ('L∞', 'L7', 'L6', 'L5', 'L4', 'L3', 'L2', 'L1', 'L0')),
    sync_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (sync_status IN ('PENDING', 'SYNCING', 'SYNCED', 'CONFLICT', 'FAILED', 'SKIPPED')),
    timestamp INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    deleted_at INTEGER,
    
    UNIQUE(id, rev)
);

CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
CREATE INDEX IF NOT EXISTS idx_memories_hash ON memories(current_hash);
CREATE INDEX IF NOT EXISTS idx_memories_sync ON memories(sync_status);
CREATE INDEX IF NOT EXISTS idx_memories_layer ON memories(layer);

-- 記憶標籤表
CREATE TABLE IF NOT EXISTS memory_tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_id TEXT NOT NULL,
    tag TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
    UNIQUE(memory_id, tag)
);

CREATE INDEX IF NOT EXISTS idx_memory_tags_memory ON memory_tags(memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_tags_tag ON memory_tags(tag);

-- ============================================
-- 粒子表（with SoT/Revision）
-- ============================================
CREATE TABLE IF NOT EXISTS particles (
    id TEXT PRIMARY KEY,
    rev INTEGER NOT NULL DEFAULT 1,
    sot TEXT NOT NULL DEFAULT 'D1' CHECK (sot IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    type TEXT NOT NULL,  -- 型態
    data TEXT NOT NULL,  -- JSON 格式資料
    embedding BLOB,      -- Float32Array 序列化
    layer TEXT NOT NULL DEFAULT 'L1' CHECK (layer IN ('L∞', 'L7', 'L6', 'L5', 'L4', 'L3', 'L2', 'L1', 'L0')),
    freq REAL NOT NULL DEFAULT 7.83,
    sync_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (sync_status IN ('PENDING', 'SYNCING', 'SYNCED', 'CONFLICT', 'FAILED', 'SKIPPED')),
    timestamp INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    deleted_at INTEGER,
    
    UNIQUE(id, rev)
);

CREATE INDEX IF NOT EXISTS idx_particles_type ON particles(type);
CREATE INDEX IF NOT EXISTS idx_particles_layer ON particles(layer);
CREATE INDEX IF NOT EXISTS idx_particles_sync ON particles(sync_status);

-- ============================================
-- 同步操作表
-- ============================================
CREATE TABLE IF NOT EXISTS sync_operations (
    id TEXT PRIMARY KEY,
    batch_id TEXT NOT NULL,
    source TEXT NOT NULL CHECK (source IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    target TEXT NOT NULL CHECK (target IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    resource_id TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    operation TEXT NOT NULL CHECK (operation IN ('CREATE', 'UPDATE', 'DELETE')),
    source_rev INTEGER NOT NULL,
    target_rev INTEGER,
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'SYNCING', 'SYNCED', 'CONFLICT', 'FAILED', 'SKIPPED')),
    error_category TEXT CHECK (error_category IN ('VERSION_MISMATCH', 'SOT_VIOLATION', 'INTEGRITY_ERROR', 'NETWORK_ERROR', 'PERMISSION_DENIED', 'RESOURCE_NOT_FOUND', 'CONFLICT_DETECTED', 'IDEMPOTENCY_CHECK', 'UNKNOWN')),
    error_message TEXT,
    idempotency_key TEXT NOT NULL UNIQUE,
    started_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    completed_at INTEGER,
    
    UNIQUE(batch_id, resource_id, operation)
);

CREATE INDEX IF NOT EXISTS idx_sync_batch ON sync_operations(batch_id);
CREATE INDEX IF NOT EXISTS idx_sync_status ON sync_operations(status);
CREATE INDEX IF NOT EXISTS idx_sync_resource ON sync_operations(resource_id);
CREATE INDEX IF NOT EXISTS idx_sync_idempotency ON sync_operations(idempotency_key);

-- ============================================
-- 衝突記錄表
-- ============================================
CREATE TABLE IF NOT EXISTS conflicts (
    id TEXT PRIMARY KEY,
    resource_id TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    source_a TEXT NOT NULL CHECK (source_a IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    source_b TEXT NOT NULL CHECK (source_b IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    rev_a INTEGER NOT NULL,
    rev_b INTEGER NOT NULL,
    content_hash_a TEXT NOT NULL,
    content_hash_b TEXT NOT NULL,
    data_a TEXT,  -- JSON snapshot
    data_b TEXT,  -- JSON snapshot
    detected_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    resolution TEXT CHECK (resolution IN ('SOT_WINS', 'LATEST_WINS', 'MANUAL', 'MERGE')),
    resolved_at INTEGER,
    resolved_by TEXT,
    winner TEXT CHECK (winner IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    audit_log TEXT NOT NULL DEFAULT '[]'  -- JSON array
);

CREATE INDEX IF NOT EXISTS idx_conflicts_resource ON conflicts(resource_id);
CREATE INDEX IF NOT EXISTS idx_conflicts_resolved ON conflicts(resolved_at);
CREATE INDEX IF NOT EXISTS idx_conflicts_detected ON conflicts(detected_at);

-- ============================================
-- 追蹤日誌表
-- ============================================
CREATE TABLE IF NOT EXISTS trace_log (
    id TEXT PRIMARY KEY,
    timestamp INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    level TEXT NOT NULL CHECK (level IN ('DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL')),
    category TEXT NOT NULL,
    message TEXT NOT NULL,
    resource_id TEXT,
    batch_id TEXT,
    operation TEXT,
    error_category TEXT,
    stack_trace TEXT,
    metadata TEXT,  -- JSON
    origin TEXT NOT NULL DEFAULT 'MrLiouWord'
);

CREATE INDEX IF NOT EXISTS idx_trace_timestamp ON trace_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_trace_level ON trace_log(level);
CREATE INDEX IF NOT EXISTS idx_trace_category ON trace_log(category);
CREATE INDEX IF NOT EXISTS idx_trace_resource ON trace_log(resource_id);
CREATE INDEX IF NOT EXISTS idx_trace_batch ON trace_log(batch_id);

-- ============================================
-- 版本歷史表（支援版本回溯）
-- ============================================
CREATE TABLE IF NOT EXISTS version_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    resource_id TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    rev INTEGER NOT NULL,
    prev_rev INTEGER,
    content_hash TEXT NOT NULL,
    data_snapshot TEXT NOT NULL,  -- JSON 完整快照
    change_type TEXT NOT NULL CHECK (change_type IN ('CREATE', 'UPDATE', 'DELETE', 'RESTORE')),
    changed_by TEXT NOT NULL DEFAULT 'system',
    changed_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    
    UNIQUE(resource_id, rev)
);

CREATE INDEX IF NOT EXISTS idx_version_resource ON version_history(resource_id);
CREATE INDEX IF NOT EXISTS idx_version_rev ON version_history(rev);
CREATE INDEX IF NOT EXISTS idx_version_changed ON version_history(changed_at);

-- ============================================
-- 冪等批次追蹤表
-- ============================================
CREATE TABLE IF NOT EXISTS idempotency_records (
    idempotency_key TEXT PRIMARY KEY,
    batch_id TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    result TEXT NOT NULL,  -- JSON
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    expires_at INTEGER NOT NULL  -- 過期時間（避免無限增長）
);

CREATE INDEX IF NOT EXISTS idx_idempotency_batch ON idempotency_records(batch_id);
CREATE INDEX IF NOT EXISTS idx_idempotency_expires ON idempotency_records(expires_at);

-- ============================================
-- 人格表（personas）
-- ============================================
CREATE TABLE IF NOT EXISTS personas (
    id TEXT PRIMARY KEY,
    rev INTEGER NOT NULL DEFAULT 1,
    sot TEXT NOT NULL DEFAULT 'D1' CHECK (sot IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    name TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 0,
    data TEXT NOT NULL,  -- JSON
    layer TEXT NOT NULL DEFAULT 'L5' CHECK (layer IN ('L∞', 'L7', 'L6', 'L5', 'L4', 'L3', 'L2', 'L1', 'L0')),
    sync_status TEXT NOT NULL DEFAULT 'PENDING',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    deleted_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_personas_name ON personas(name);
CREATE INDEX IF NOT EXISTS idx_personas_active ON personas(is_active);

-- ============================================
-- 吸收記錄表（absorbed）
-- ============================================
CREATE TABLE IF NOT EXISTS absorbed (
    id TEXT PRIMARY KEY,
    rev INTEGER NOT NULL DEFAULT 1,
    sot TEXT NOT NULL DEFAULT 'D1' CHECK (sot IN ('KV', 'D1', 'R2', 'EXTERNAL')),
    filename TEXT NOT NULL,
    size INTEGER NOT NULL,
    content_hash TEXT NOT NULL,
    file_type TEXT NOT NULL,
    layer TEXT NOT NULL DEFAULT 'L3' CHECK (layer IN ('L∞', 'L7', 'L6', 'L5', 'L4', 'L3', 'L2', 'L1', 'L0')),
    r2_key TEXT,
    sync_status TEXT NOT NULL DEFAULT 'PENDING',
    absorbed_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    deleted_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_absorbed_hash ON absorbed(content_hash);
CREATE INDEX IF NOT EXISTS idx_absorbed_type ON absorbed(file_type);

-- ============================================
-- 清理過期冪等記錄的觸發器
-- ============================================
-- 注意：D1 不支援觸發器，需在應用層實現清理邏輯

-- ============================================
-- 初始化元資料
-- ============================================
INSERT OR REPLACE INTO unified_resources (
    id, rev, sot, layer, type, name, content_hash, origin_signature, sync_status
) VALUES (
    'system:schema:init',
    1,
    'D1',
    'L7',
    'system',
    'Schema Initialization',
    'init-v2.0.0',
    'MrLiouWord',
    'SYNCED'
);
