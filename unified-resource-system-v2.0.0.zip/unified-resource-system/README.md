# MrLiouWord Unified Resource System v2.0

> **「怎麼過去，就怎麼回來」**

統一資源管理系統，實現 KV/D1 雙向同步，具備完整的版本控制、衝突處理與冪等保證。

---

## 🎯 核心設計原則

### 1. SoT (Source of Truth) - 來源權威
- 每種資源類型有明確的權威來源
- D1 為結構化資料的 SoT
- KV 為快取層，由 D1 同步而來
- 避免雙向覆寫造成的資料遺失

### 2. Revision - 單調版本線
- 每次寫入版本號 +1
- 永不接受版本倒退
- 支援版本歷史查詢與回溯

### 3. Resume - 冪等續跑
- 每個批次有唯一 batch_id
- 相同操作不會重複執行
- 支援斷點恢復

### 4. Conflicts - 衝突審計
- 自動檢測版本衝突
- 記錄衝突詳情與決策過程
- 支援多種解決策略

---

## 📐 資料模型

### 統一資源表 (unified_resources)

| 欄位 | 類型 | 說明 |
|------|------|------|
| id | TEXT | 唯一識別符 (UUID) |
| rev | INTEGER | 版本號（單調遞增）|
| sot | TEXT | 來源權威 (KV/D1/R2/EXTERNAL) |
| layer | TEXT | 頻率層級 (L0-L7, L∞) |
| type | TEXT | 資源類型 |
| name | TEXT | 資源名稱 |
| content_hash | TEXT | 內容雜湊 (SimHash64) |
| sync_status | TEXT | 同步狀態 |
| created_at | INTEGER | 建立時間 |
| updated_at | INTEGER | 更新時間 |
| deleted_at | INTEGER | 軟刪除時間 |

### 標籤關聯表 (resource_tags)

正規化設計，支援高效索引：

```sql
CREATE TABLE resource_tags (
  resource_id TEXT NOT NULL,
  tag TEXT NOT NULL,
  UNIQUE(resource_id, tag)
);
```

### 衝突記錄表 (conflicts)

完整的衝突審計：

| 欄位 | 說明 |
|------|------|
| source_a/source_b | 衝突雙方來源 |
| rev_a/rev_b | 衝突雙方版本 |
| content_hash_a/b | 內容雜湊 |
| resolution | 解決策略 |
| winner | 勝出方 |
| audit_log | 決策過程 JSON 陣列 |

---

## 🚀 API 端點

### 系統

```
GET  /              系統資訊
GET  /status        系統狀態（含同步統計）
GET  /health        健康檢查
GET  /frequencies   頻率常數
```

### 資源管理

```
GET    /resources              查詢資源
GET    /resources/:id          取得單一資源
POST   /resources              建立/更新資源（冪等）
DELETE /resources/:id          刪除資源（軟刪除）
GET    /resources/:id/history  版本歷史
GET    /resources/by-tags      依標籤查詢
```

### 同步管理

```
POST   /sync/batch           批次同步
GET    /sync/status          同步狀態總覽
GET    /sync/status/:batchId 特定批次狀態
```

### 衝突管理

```
GET    /conflicts            查詢衝突
POST   /conflicts/:id/resolve 解決衝突
```

### 統計

```
GET    /stats    完整統計資訊
```

---

## 📝 使用範例

### 建立資源

```bash
curl -X POST https://your-worker.workers.dev/resources \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: your-key" \
  -H "X-Batch-Id: batch-001" \
  -d '{
    "type": "memory",
    "name": "我的第一個記憶",
    "content": "這是記憶內容",
    "tags": ["重要", "工作"],
    "layer": "L1"
  }'
```

### 批次同步

```bash
curl -X POST https://your-worker.workers.dev/sync/batch \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: your-key" \
  -d '{
    "batch_id": "sync-2024-01-19-001",
    "source": "D1",
    "target": "KV",
    "conflict_resolution": "SOT_WINS",
    "resources": [
      {
        "id": "mem-001",
        "operation": "UPDATE",
        "data": {
          "type": "memory",
          "content": "更新的內容"
        }
      }
    ]
  }'
```

### 查詢衝突

```bash
curl https://your-worker.workers.dev/conflicts?resolved=false \
  -H "X-Master-Key: your-key"
```

### 解決衝突

```bash
curl -X POST https://your-worker.workers.dev/conflicts/conflict-id/resolve \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: your-key" \
  -d '{
    "resolution": "SOT_WINS",
    "winner": "D1"
  }'
```

---

## 🗄️ 資料庫初始化

```bash
# 本地開發
npm run db:init:local

# 生產環境
npm run db:init
```

---

## 📦 部署

```bash
# 安裝依賴
npm install

# 本地開發
npm run dev

# 部署到 Cloudflare
npm run deploy
```

---

## 🔧 配置

### 環境變數

| 變數 | 說明 |
|------|------|
| MASTER_KEY | API 認證金鑰 |

### 綁定

| 綁定 | 類型 | 說明 |
|------|------|------|
| MRLIOUWORD_VAULT | KV | 記憶快取 |
| MRLIOUWORD_DB | D1 | 主資料庫 |
| MRLIOUBOOK | R2 | 檔案存儲 |

---

## 🌀 頻率層級

| 層級 | 頻率 (Hz) | 說明 |
|------|-----------|------|
| L∞ | 143.47 | 頻率源層 - 宇宙源頭 |
| L7 | 88.71 | 語意記憶層 - 智慧整合 |
| L6 | 54.82 | 系統映像層 - 意識循環 |
| L5 | 33.88 | 人格策略層 - 人格模組 |
| L4 | 20.94 | 拓撲跳點層 - 跳躍連結 |
| L3 | 12.94 | 封裝層 - Package |
| L2 | 12.67 | 原型模組層 - ProtoModule |
| L1 | 7.83 | 原子粒子層 - atom_t/δP₀ |
| L0 | 4.84 | 雲端平台層 - API 介面 |

**公式**：`f(n) = 7.83 × φ^(n-1)` (舒曼共振 × 黃金比例)

---

## 🔍 衝突解決策略

| 策略 | 說明 |
|------|------|
| SOT_WINS | 來源權威優先（預設）|
| LATEST_WINS | 最新版本優先 |
| MANUAL | 手動解決 |
| MERGE | 嘗試合併 |

---

## 📊 同步狀態

| 狀態 | 說明 |
|------|------|
| PENDING | 待同步 |
| SYNCING | 同步中 |
| SYNCED | 已同步 |
| CONFLICT | 衝突 |
| FAILED | 失敗 |
| SKIPPED | 跳過（冪等）|

---

## 🧪 測試

```bash
npm test
```

---

## 📜 授權

MR.liou © 2024-2026 | 怎麼過去，就怎麼回來

---

## 🔗 相關專案

- [mrliouword-private](https://mrliouword-private.mrliou.workers.dev) - Private AI Server
- [particle-auth-gateway](https://particle-auth-gateway.mrliou.workers.dev) - 認證網關
- [mrliouword-system](https://github.com/mrliou/mrliouword-system) - 系統總覽
