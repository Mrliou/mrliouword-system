/**
 * MrLiouWord Unified Resource Hub v2.0
 * 
 * 統一資源查詢與管理中心
 * 
 * 核心改進：
 * 1. 版本號與 SoT 支援
 * 2. 冪等 upsert 操作
 * 3. 衝突檢測與處理
 * 4. 標籤正規化（關聯表）
 * 5. 同步狀態查詢介面
 * 
 * Author: MR.liou × Claude
 * Philosophy: 怎麼過去，就怎麼回來
 */

import {
  ORIGIN,
  VERSION,
  UnifiedResource,
  ResourceMetadata,
  SoTSource,
  SyncStatus,
  Layer,
  FREQ,
  ErrorCategory,
  ConflictResolution,
  ResourceQueryRequest,
  generateIdempotencyKey
} from './types';

// ============================================
// Cloudflare 環境介面
// ============================================

interface Env {
  MRLIOUWORD_VAULT: KVNamespace;
  MRLIOUWORD_DB: D1Database;
  MRLIOUBOOK?: R2Bucket;
}

// ============================================
// 工具函數
// ============================================

function uuid(): string {
  return crypto.randomUUID();
}

async function simHash64(content: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(content);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = new Uint8Array(hashBuffer);
  return Array.from(hashArray.slice(0, 8))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function now(): number {
  return Date.now();
}

// ============================================
// 回應格式
// ============================================

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: ErrorCategory;
    message: string;
  };
  meta?: {
    total?: number;
    page?: number;
    limit?: number;
    has_more?: boolean;
  };
  origin: string;
  timestamp: number;
}

function ok<T>(data: T, meta?: ApiResponse['meta']): ApiResponse<T> {
  return {
    success: true,
    data,
    meta,
    origin: ORIGIN,
    timestamp: now()
  };
}

function err(code: ErrorCategory, message: string): ApiResponse {
  return {
    success: false,
    error: { code, message },
    origin: ORIGIN,
    timestamp: now()
  };
}

// ============================================
// 統一資源中心
// ============================================

export class UnifiedResourceHub {
  private db: D1Database;
  private kv: KVNamespace;
  private r2?: R2Bucket;
  
  constructor(env: Env) {
    this.db = env.MRLIOUWORD_DB;
    this.kv = env.MRLIOUWORD_VAULT;
    this.r2 = env.MRLIOUBOOK;
  }
  
  // ========================================
  // 資源 CRUD - 支援版本控制
  // ========================================
  
  /**
   * 取得單一資源
   */
  async getResource(id: string, includeDeleted: boolean = false): Promise<ApiResponse<UnifiedResource>> {
    const whereClause = includeDeleted ? '' : 'AND deleted_at IS NULL';
    
    const result = await this.db.prepare(`
      SELECT * FROM unified_resources WHERE id = ? ${whereClause}
    `).bind(id).first();
    
    if (!result) {
      return err('RESOURCE_NOT_FOUND', `Resource ${id} not found`);
    }
    
    // 獲取標籤
    const tags = await this.db.prepare(`
      SELECT tag FROM resource_tags WHERE resource_id = ?
    `).bind(id).all();
    
    const resource: UnifiedResource = {
      id: result.id as string,
      rev: result.rev as number,
      sot: result.sot as SoTSource,
      layer: result.layer as Layer,
      type: result.type as string,
      name: result.name as string,
      content_hash: result.content_hash as string,
      metadata: {
        origin_signature: result.origin_signature as string,
        content_type: result.content_type as string,
        size: result.size as number,
        encoding: result.encoding as string,
        checksum: result.checksum as string,
        custom: result.custom_metadata ? JSON.parse(result.custom_metadata as string) : undefined
      },
      sync_status: result.sync_status as SyncStatus,
      created_at: result.created_at as number,
      updated_at: result.updated_at as number,
      deleted_at: result.deleted_at as number | undefined
    };
    
    // 附加標籤
    (resource as any).tags = tags.results.map(t => t.tag);
    
    return ok(resource);
  }
  
  /**
   * 冪等資源更新（Upsert with Version Control）
   */
  async upsertResource(
    resource: Partial<UnifiedResource> & { 
      id?: string;
      type: string;
      name: string;
      content?: string;
      tags?: string[];
    },
    batchId?: string,
    conflictResolution: ConflictResolution = 'SOT_WINS'
  ): Promise<ApiResponse<UnifiedResource>> {
    const resourceId = resource.id || uuid();
    const idempotencyKey = batchId 
      ? generateIdempotencyKey(batchId, resourceId, 'UPSERT')
      : `upsert:${resourceId}:${now()}`;
    
    // 冪等檢查
    if (batchId) {
      const existing = await this.db.prepare(`
        SELECT result FROM idempotency_records WHERE idempotency_key = ? AND expires_at > ?
      `).bind(idempotencyKey, now()).first();
      
      if (existing) {
        const cached = JSON.parse(existing.result as string);
        return ok(cached, { total: 1 });
      }
    }
    
    // 取得現有資源
    const existingResult = await this.db.prepare(`
      SELECT * FROM unified_resources WHERE id = ?
    `).bind(resourceId).first();
    
    const currentRev = existingResult ? (existingResult.rev as number) : 0;
    const newRev = currentRev + 1;
    
    // 版本驗證（如果提供了 rev，確保單調遞增）
    if (resource.rev !== undefined && resource.rev <= currentRev) {
      return err('VERSION_MISMATCH', `Version must be greater than current (${currentRev}), got ${resource.rev}`);
    }
    
    // 計算內容雜湊
    const contentHash = resource.content 
      ? await simHash64(resource.content)
      : resource.content_hash || await simHash64(JSON.stringify(resource));
    
    // 衝突檢測
    if (existingResult && existingResult.content_hash !== contentHash) {
      // 檢查 SoT
      const existingSot = existingResult.sot as SoTSource;
      const newSot = resource.sot || 'D1';
      
      if (existingSot !== newSot && conflictResolution !== 'SOT_WINS') {
        // 記錄衝突
        await this.db.prepare(`
          INSERT INTO conflicts (id, resource_id, resource_type, source_a, source_b, rev_a, rev_b, content_hash_a, content_hash_b, detected_at, audit_log)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          uuid(),
          resourceId,
          resource.type,
          existingSot,
          newSot,
          currentRev,
          newRev,
          existingResult.content_hash,
          contentHash,
          now(),
          JSON.stringify([`[${new Date().toISOString()}] Conflict detected during upsert`])
        ).run();
        
        if (conflictResolution === 'MANUAL') {
          return err('CONFLICT_DETECTED', 'Resource has conflicting versions, manual resolution required');
        }
      }
    }
    
    // 構建完整資源
    const fullResource: UnifiedResource = {
      id: resourceId,
      rev: newRev,
      sot: resource.sot || 'D1',
      layer: resource.layer || 'L1',
      type: resource.type,
      name: resource.name,
      content_hash: contentHash,
      metadata: {
        origin_signature: resource.metadata?.origin_signature || ORIGIN,
        content_type: resource.metadata?.content_type,
        size: resource.metadata?.size || (resource.content?.length || 0),
        encoding: resource.metadata?.encoding || 'utf-8',
        checksum: resource.metadata?.checksum,
        custom: resource.metadata?.custom
      },
      sync_status: 'SYNCED',
      created_at: existingResult ? (existingResult.created_at as number) : now(),
      updated_at: now()
    };
    
    // 記錄版本歷史
    await this.db.prepare(`
      INSERT INTO version_history (resource_id, resource_type, rev, prev_rev, content_hash, data_snapshot, change_type, changed_by, changed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      resourceId,
      fullResource.type,
      newRev,
      currentRev || null,
      contentHash,
      JSON.stringify(fullResource),
      existingResult ? 'UPDATE' : 'CREATE',
      'system',
      now()
    ).run();
    
    // 寫入資源表
    await this.db.prepare(`
      INSERT OR REPLACE INTO unified_resources 
      (id, rev, sot, layer, type, name, content_hash, content_type, size, encoding, checksum, origin_signature, custom_metadata, sync_status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      fullResource.id,
      fullResource.rev,
      fullResource.sot,
      fullResource.layer,
      fullResource.type,
      fullResource.name,
      fullResource.content_hash,
      fullResource.metadata.content_type || null,
      fullResource.metadata.size || null,
      fullResource.metadata.encoding,
      fullResource.metadata.checksum || null,
      fullResource.metadata.origin_signature,
      fullResource.metadata.custom ? JSON.stringify(fullResource.metadata.custom) : null,
      fullResource.sync_status,
      fullResource.created_at,
      fullResource.updated_at
    ).run();
    
    // 更新標籤（正規化設計）
    if (resource.tags) {
      // 刪除舊標籤
      await this.db.prepare(`DELETE FROM resource_tags WHERE resource_id = ?`).bind(resourceId).run();
      
      // 插入新標籤
      for (const tag of resource.tags) {
        await this.db.prepare(`
          INSERT INTO resource_tags (resource_id, tag, created_at) VALUES (?, ?, ?)
        `).bind(resourceId, tag.trim(), now()).run();
      }
    }
    
    // 記錄冪等結果
    if (batchId) {
      await this.db.prepare(`
        INSERT OR REPLACE INTO idempotency_records (idempotency_key, batch_id, resource_id, operation, result, created_at, expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(
        idempotencyKey,
        batchId,
        resourceId,
        'UPSERT',
        JSON.stringify(fullResource),
        now(),
        now() + 24 * 60 * 60 * 1000
      ).run();
    }
    
    // 附加標籤到回傳
    (fullResource as any).tags = resource.tags || [];
    
    return ok(fullResource);
  }
  
  /**
   * 批次冪等同步
   */
  async batchSyncResources(
    resources: Array<{
      id?: string;
      type: string;
      name: string;
      content?: string;
      tags?: string[];
      layer?: Layer;
      sot?: SoTSource;
    }>,
    batchId: string,
    conflictResolution: ConflictResolution = 'SOT_WINS'
  ): Promise<ApiResponse<{
    synced: number;
    failed: number;
    conflicts: number;
    skipped: number;
    results: Array<{ id: string; status: string; error?: string }>;
  }>> {
    const results: Array<{ id: string; status: string; error?: string }> = [];
    let synced = 0, failed = 0, conflicts = 0, skipped = 0;
    
    for (const resource of resources) {
      const response = await this.upsertResource(resource, batchId, conflictResolution);
      
      if (response.success && response.data) {
        // 檢查是否冪等跳過
        const wasSkipped = response.meta?.total === 1; // 簡化判斷
        if (wasSkipped) {
          skipped++;
          results.push({ id: response.data.id, status: 'SKIPPED' });
        } else {
          synced++;
          results.push({ id: response.data.id, status: 'SYNCED' });
        }
      } else if (response.error?.code === 'CONFLICT_DETECTED') {
        conflicts++;
        results.push({ id: resource.id || 'unknown', status: 'CONFLICT', error: response.error.message });
      } else {
        failed++;
        results.push({ id: resource.id || 'unknown', status: 'FAILED', error: response.error?.message });
      }
    }
    
    return ok({ synced, failed, conflicts, skipped, results });
  }
  
  /**
   * 刪除資源（軟刪除）
   */
  async deleteResource(id: string): Promise<ApiResponse<{ deleted: boolean }>> {
    const existing = await this.db.prepare(`
      SELECT rev FROM unified_resources WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!existing) {
      return err('RESOURCE_NOT_FOUND', `Resource ${id} not found`);
    }
    
    const newRev = (existing.rev as number) + 1;
    
    // 記錄版本歷史
    await this.db.prepare(`
      INSERT INTO version_history (resource_id, resource_type, rev, prev_rev, content_hash, data_snapshot, change_type, changed_by, changed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(id, 'unknown', newRev, existing.rev, '', '{}', 'DELETE', 'system', now()).run();
    
    // 軟刪除
    await this.db.prepare(`
      UPDATE unified_resources SET deleted_at = ?, rev = ?, updated_at = ?, sync_status = 'SYNCED' WHERE id = ?
    `).bind(now(), newRev, now(), id).run();
    
    return ok({ deleted: true });
  }
  
  // ========================================
  // 查詢介面
  // ========================================
  
  /**
   * 資源查詢（支援版本範圍與 SoT 過濾）
   */
  async queryResources(request: ResourceQueryRequest = {}): Promise<ApiResponse<UnifiedResource[]>> {
    const conditions: string[] = [];
    const params: any[] = [];
    
    if (!request.include_deleted) {
      conditions.push('deleted_at IS NULL');
    }
    
    if (request.type) {
      conditions.push('type = ?');
      params.push(request.type);
    }
    
    if (request.layer) {
      conditions.push('layer = ?');
      params.push(request.layer);
    }
    
    if (request.sot) {
      conditions.push('sot = ?');
      params.push(request.sot);
    }
    
    if (request.sync_status) {
      conditions.push('sync_status = ?');
      params.push(request.sync_status);
    }
    
    if (request.rev_min !== undefined) {
      conditions.push('rev >= ?');
      params.push(request.rev_min);
    }
    
    if (request.rev_max !== undefined) {
      conditions.push('rev <= ?');
      params.push(request.rev_max);
    }
    
    if (request.created_after) {
      conditions.push('created_at >= ?');
      params.push(request.created_after);
    }
    
    if (request.created_before) {
      conditions.push('created_at <= ?');
      params.push(request.created_before);
    }
    
    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const limit = request.limit || 50;
    const offset = request.offset || 0;
    
    // 取得總數
    const countResult = await this.db.prepare(`
      SELECT COUNT(*) as total FROM unified_resources ${whereClause}
    `).bind(...params).first();
    
    const total = (countResult?.total as number) || 0;
    
    // 取得資源
    const query = `
      SELECT * FROM unified_resources ${whereClause}
      ORDER BY updated_at DESC
      LIMIT ? OFFSET ?
    `;
    
    const results = await this.db.prepare(query).bind(...params, limit, offset).all();
    
    // 批量獲取標籤
    const resources: UnifiedResource[] = [];
    for (const row of results.results) {
      const tags = await this.db.prepare(`
        SELECT tag FROM resource_tags WHERE resource_id = ?
      `).bind(row.id).all();
      
      resources.push({
        id: row.id as string,
        rev: row.rev as number,
        sot: row.sot as SoTSource,
        layer: row.layer as Layer,
        type: row.type as string,
        name: row.name as string,
        content_hash: row.content_hash as string,
        metadata: {
          origin_signature: row.origin_signature as string,
          content_type: row.content_type as string,
          size: row.size as number,
          encoding: row.encoding as string,
          checksum: row.checksum as string,
          custom: row.custom_metadata ? JSON.parse(row.custom_metadata as string) : undefined
        },
        sync_status: row.sync_status as SyncStatus,
        created_at: row.created_at as number,
        updated_at: row.updated_at as number,
        deleted_at: row.deleted_at as number | undefined,
        tags: tags.results.map(t => t.tag)
      } as any);
    }
    
    return ok(resources, {
      total,
      page: Math.floor(offset / limit) + 1,
      limit,
      has_more: offset + limit < total
    });
  }
  
  /**
   * 依標籤查詢
   */
  async queryByTags(tags: string[], matchAll: boolean = false): Promise<ApiResponse<UnifiedResource[]>> {
    if (tags.length === 0) {
      return this.queryResources();
    }
    
    let query: string;
    if (matchAll) {
      // 必須匹配所有標籤
      query = `
        SELECT r.* FROM unified_resources r
        WHERE r.deleted_at IS NULL AND r.id IN (
          SELECT resource_id FROM resource_tags WHERE tag IN (${tags.map(() => '?').join(',')})
          GROUP BY resource_id HAVING COUNT(DISTINCT tag) = ?
        )
        ORDER BY r.updated_at DESC
        LIMIT 100
      `;
      const results = await this.db.prepare(query).bind(...tags, tags.length).all();
      return ok(results.results as unknown as UnifiedResource[]);
    } else {
      // 匹配任一標籤
      query = `
        SELECT DISTINCT r.* FROM unified_resources r
        INNER JOIN resource_tags t ON r.id = t.resource_id
        WHERE r.deleted_at IS NULL AND t.tag IN (${tags.map(() => '?').join(',')})
        ORDER BY r.updated_at DESC
        LIMIT 100
      `;
      const results = await this.db.prepare(query).bind(...tags).all();
      return ok(results.results as unknown as UnifiedResource[]);
    }
  }
  
  // ========================================
  // 同步狀態查詢
  // ========================================
  
  /**
   * 取得同步狀態摘要
   */
  async getSyncStatus(): Promise<ApiResponse<{
    total_resources: number;
    by_status: Record<SyncStatus, number>;
    by_sot: Record<SoTSource, number>;
    by_layer: Record<Layer, number>;
    pending_count: number;
    conflict_count: number;
    last_sync?: number;
  }>> {
    const statusCounts = await this.db.prepare(`
      SELECT sync_status, COUNT(*) as count FROM unified_resources WHERE deleted_at IS NULL GROUP BY sync_status
    `).all();
    
    const sotCounts = await this.db.prepare(`
      SELECT sot, COUNT(*) as count FROM unified_resources WHERE deleted_at IS NULL GROUP BY sot
    `).all();
    
    const layerCounts = await this.db.prepare(`
      SELECT layer, COUNT(*) as count FROM unified_resources WHERE deleted_at IS NULL GROUP BY layer
    `).all();
    
    const conflictCount = await this.db.prepare(`
      SELECT COUNT(*) as count FROM conflicts WHERE resolved_at IS NULL
    `).first();
    
    const lastSync = await this.db.prepare(`
      SELECT MAX(completed_at) as last_sync FROM sync_operations WHERE status = 'SYNCED'
    `).first();
    
    const byStatus: Record<string, number> = {};
    for (const row of statusCounts.results) {
      byStatus[row.sync_status as string] = row.count as number;
    }
    
    const bySot: Record<string, number> = {};
    for (const row of sotCounts.results) {
      bySot[row.sot as string] = row.count as number;
    }
    
    const byLayer: Record<string, number> = {};
    for (const row of layerCounts.results) {
      byLayer[row.layer as string] = row.count as number;
    }
    
    const total = Object.values(byStatus).reduce((a, b) => a + b, 0);
    
    return ok({
      total_resources: total,
      by_status: byStatus as Record<SyncStatus, number>,
      by_sot: bySot as Record<SoTSource, number>,
      by_layer: byLayer as Record<Layer, number>,
      pending_count: byStatus['PENDING'] || 0,
      conflict_count: (conflictCount?.count as number) || 0,
      last_sync: lastSync?.last_sync as number | undefined
    });
  }
  
  /**
   * 取得版本歷史
   */
  async getVersionHistory(resourceId: string, limit: number = 20): Promise<ApiResponse<any[]>> {
    const results = await this.db.prepare(`
      SELECT * FROM version_history WHERE resource_id = ? ORDER BY rev DESC LIMIT ?
    `).bind(resourceId, limit).all();
    
    return ok(results.results.map(r => ({
      ...r,
      data_snapshot: JSON.parse(r.data_snapshot as string || '{}')
    })));
  }
  
  /**
   * 取得統計資訊
   */
  async getStats(): Promise<ApiResponse<{
    resources: {
      total: number;
      by_type: Record<string, number>;
      by_layer: Record<string, number>;
    };
    sync: {
      total_operations: number;
      success_rate: number;
      avg_duration_ms: number;
    };
    storage: {
      total_size: number;
      by_type: Record<string, number>;
    };
    frequencies: Record<string, number>;
  }>> {
    // 資源統計
    const typeCounts = await this.db.prepare(`
      SELECT type, COUNT(*) as count FROM unified_resources WHERE deleted_at IS NULL GROUP BY type
    `).all();
    
    const layerCounts = await this.db.prepare(`
      SELECT layer, COUNT(*) as count FROM unified_resources WHERE deleted_at IS NULL GROUP BY layer
    `).all();
    
    // 同步統計
    const syncStats = await this.db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'SYNCED' THEN 1 ELSE 0 END) as success,
        AVG(completed_at - started_at) as avg_duration
      FROM sync_operations
    `).first();
    
    // 儲存統計
    const sizeBySot = await this.db.prepare(`
      SELECT sot, SUM(size) as total_size FROM unified_resources WHERE deleted_at IS NULL GROUP BY sot
    `).all();
    
    const byType: Record<string, number> = {};
    for (const row of typeCounts.results) {
      byType[row.type as string] = row.count as number;
    }
    
    const byLayer: Record<string, number> = {};
    for (const row of layerCounts.results) {
      byLayer[row.layer as string] = row.count as number;
    }
    
    const storageBySot: Record<string, number> = {};
    let totalSize = 0;
    for (const row of sizeBySot.results) {
      storageBySot[row.sot as string] = (row.total_size as number) || 0;
      totalSize += (row.total_size as number) || 0;
    }
    
    const total = Object.values(byType).reduce((a, b) => a + b, 0);
    const syncTotal = (syncStats?.total as number) || 1;
    const syncSuccess = (syncStats?.success as number) || 0;
    
    return ok({
      resources: {
        total,
        by_type: byType,
        by_layer: byLayer
      },
      sync: {
        total_operations: syncTotal,
        success_rate: syncSuccess / syncTotal,
        avg_duration_ms: (syncStats?.avg_duration as number) || 0
      },
      storage: {
        total_size: totalSize,
        by_type: storageBySot
      },
      frequencies: FREQ
    });
  }
}

export default UnifiedResourceHub;
