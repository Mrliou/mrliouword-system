/**
 * MrLiouWord Unified Resource System - 類型定義
 * 
 * 核心原則：
 * - SoT (Source of Truth): 明確的來源權威
 * - Revision: 單調遞增版本線
 * - Resume: 冪等續跑機制
 * - Conflicts: 衝突審計記錄
 * 
 * Author: MR.liou × Claude
 * Philosophy: 怎麼過去，就怎麼回來
 */

// ============================================
// 基礎常數
// ============================================

export const ORIGIN = "MrLiouWord";
export const VERSION = "2.0.0";
export const SCHUMANN = 7.83;
export const PHI = 1.618033988749895;

// 來源權威類型
export type SoTSource = "KV" | "D1" | "R2" | "EXTERNAL";

// 同步狀態
export type SyncStatus = 
  | "PENDING"      // 待同步
  | "SYNCING"      // 同步中
  | "SYNCED"       // 已同步
  | "CONFLICT"     // 衝突
  | "FAILED"       // 失敗
  | "SKIPPED";     // 跳過（冪等）

// 衝突解決策略
export type ConflictResolution = 
  | "SOT_WINS"     // 來源權威優先
  | "LATEST_WINS"  // 最新版本優先
  | "MANUAL"       // 手動解決
  | "MERGE";       // 嘗試合併

// 錯誤分類
export type ErrorCategory = 
  | "VERSION_MISMATCH"    // 版本不匹配
  | "SOT_VIOLATION"       // SoT 違規
  | "INTEGRITY_ERROR"     // 完整性錯誤
  | "NETWORK_ERROR"       // 網路錯誤
  | "PERMISSION_DENIED"   // 權限拒絕
  | "RESOURCE_NOT_FOUND"  // 資源不存在
  | "CONFLICT_DETECTED"   // 檢測到衝突
  | "IDEMPOTENCY_CHECK"   // 冪等檢查失敗
  | "UNKNOWN";            // 未知錯誤

// 頻率層級
export const FREQ: Record<string, number> = {
  "L∞": SCHUMANN * PHI ** 7,
  "L7": SCHUMANN * PHI ** 6,
  "L6": SCHUMANN * PHI ** 5,
  "L5": SCHUMANN * PHI ** 4,
  "L4": SCHUMANN * PHI ** 3,
  "L3": SCHUMANN * PHI ** 2,
  "L2": SCHUMANN * PHI,
  "L1": SCHUMANN,
  "L0": SCHUMANN / PHI
};

export type Layer = "L∞" | "L7" | "L6" | "L5" | "L4" | "L3" | "L2" | "L1" | "L0";

// ============================================
// 核心資源類型
// ============================================

/**
 * 統一資源基礎結構
 */
export interface UnifiedResource {
  id: string;                    // 唯一識別符 (UUID)
  rev: number;                   // 版本號（單調遞增）
  sot: SoTSource;               // 來源權威
  layer: Layer;                  // 頻率層級
  type: string;                  // 資源類型
  name: string;                  // 資源名稱
  content_hash: string;          // 內容雜湊 (SimHash64)
  metadata: ResourceMetadata;    // 元資料
  sync_status: SyncStatus;       // 同步狀態
  created_at: number;            // 建立時間
  updated_at: number;            // 更新時間
  deleted_at?: number;           // 軟刪除時間
}

/**
 * 資源元資料
 */
export interface ResourceMetadata {
  origin_signature: string;      // 來源簽名
  content_type?: string;         // 內容類型
  size?: number;                 // 大小（bytes）
  encoding?: string;             // 編碼
  checksum?: string;             // 校驗和
  custom?: Record<string, any>;  // 自定義欄位
}

/**
 * 記憶條目（with SoT/Revision）
 */
export interface MemoryEntry {
  id: string;
  rev: number;
  sot: SoTSource;
  content: string;
  type: string;
  tags: string[];
  prev_hash: string;
  current_hash: string;
  timestamp: number;
  sync_status: SyncStatus;
  layer: Layer;
}

/**
 * 粒子條目（with SoT/Revision）
 */
export interface ParticleEntry {
  id: string;
  rev: number;
  sot: SoTSource;
  型態: string;
  data: any;
  embedding?: Float32Array;
  layer: Layer;
  freq: number;
  timestamp: number;
  sync_status: SyncStatus;
}

// ============================================
// 同步與衝突類型
// ============================================

/**
 * 同步操作
 */
export interface SyncOperation {
  id: string;                    // 操作 ID
  batch_id: string;              // 批次 ID（用於冪等）
  source: SoTSource;             // 來源
  target: SoTSource;             // 目標
  resource_id: string;           // 資源 ID
  resource_type: string;         // 資源類型
  operation: "CREATE" | "UPDATE" | "DELETE";
  source_rev: number;            // 來源版本
  target_rev?: number;           // 目標版本（如有）
  status: SyncStatus;            // 狀態
  error_category?: ErrorCategory; // 錯誤分類
  error_message?: string;        // 錯誤訊息
  started_at: number;            // 開始時間
  completed_at?: number;         // 完成時間
  idempotency_key: string;       // 冪等鍵
}

/**
 * 衝突記錄
 */
export interface ConflictRecord {
  id: string;
  resource_id: string;
  resource_type: string;
  source_a: SoTSource;
  source_b: SoTSource;
  rev_a: number;
  rev_b: number;
  content_hash_a: string;
  content_hash_b: string;
  detected_at: number;
  resolution?: ConflictResolution;
  resolved_at?: number;
  resolved_by?: string;          // 'system' | 'manual' | user_id
  winner?: SoTSource;
  audit_log: string[];           // 決策過程記錄
}

/**
 * 同步狀態報告
 */
export interface SyncStatusReport {
  batch_id: string;
  total_operations: number;
  completed: number;
  failed: number;
  conflicts: number;
  skipped: number;               // 冪等跳過
  started_at: number;
  completed_at?: number;
  operations: SyncOperation[];
  conflicts_details: ConflictRecord[];
}

// ============================================
// 追蹤日誌類型
// ============================================

/**
 * 追蹤日誌條目
 */
export interface TraceLog {
  id: string;
  timestamp: number;
  level: "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL";
  category: string;
  message: string;
  context?: {
    resource_id?: string;
    batch_id?: string;
    operation?: string;
    error_category?: ErrorCategory;
    stack_trace?: string;
    metadata?: Record<string, any>;
  };
  origin: string;
}

// ============================================
// API 請求/回應類型
// ============================================

/**
 * 批次同步請求
 */
export interface BatchSyncRequest {
  batch_id: string;              // 批次 ID（客戶端生成，用於冪等）
  source: SoTSource;
  target: SoTSource;
  resources: Array<{
    id: string;
    rev?: number;
    data: any;
    operation: "CREATE" | "UPDATE" | "DELETE";
  }>;
  conflict_resolution?: ConflictResolution;
  resume_from?: string;          // 續跑點
}

/**
 * 批次同步回應
 */
export interface BatchSyncResponse {
  success: boolean;
  batch_id: string;
  report: SyncStatusReport;
  resume_token?: string;         // 下次續跑 token
  origin: string;
}

/**
 * 資源查詢請求
 */
export interface ResourceQueryRequest {
  type?: string;
  layer?: Layer;
  sot?: SoTSource;
  sync_status?: SyncStatus;
  rev_min?: number;
  rev_max?: number;
  created_after?: number;
  created_before?: number;
  limit?: number;
  offset?: number;
  include_deleted?: boolean;
}

/**
 * 衝突查詢請求
 */
export interface ConflictQueryRequest {
  resource_type?: string;
  resolved?: boolean;
  detected_after?: number;
  limit?: number;
}

// ============================================
// 工具函數類型
// ============================================

/**
 * 生成冪等鍵
 */
export function generateIdempotencyKey(
  batchId: string, 
  resourceId: string, 
  operation: string
): string {
  return `${batchId}:${resourceId}:${operation}`;
}

/**
 * 檢查版本是否單調遞增
 */
export function isVersionMonotonic(currentRev: number, newRev: number): boolean {
  return newRev > currentRev;
}

/**
 * 計算頻率
 */
export function calculateFrequency(layer: Layer): number {
  return FREQ[layer] || SCHUMANN;
}
