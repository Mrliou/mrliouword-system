/**
 * MrLiouWord Unified Resource Worker v2.0
 * 
 * 統一資源管理 Worker - 整合 KV-D1 同步、資源中心、版本控制
 * 
 * 端點概覽：
 * - GET  /                    系統資訊
 * - GET  /status              系統狀態
 * - GET  /health              健康檢查
 * 
 * 資源管理：
 * - GET  /resources           查詢資源
 * - GET  /resources/:id       取得單一資源
 * - POST /resources           建立/更新資源
 * - DELETE /resources/:id     刪除資源
 * - GET  /resources/:id/history  版本歷史
 * 
 * 同步管理：
 * - POST /sync/batch          批次同步
 * - GET  /sync/status         同步狀態
 * - GET  /sync/status/:batchId 批次狀態
 * 
 * 衝突管理：
 * - GET  /conflicts           查詢衝突
 * - POST /conflicts/:id/resolve 解決衝突
 * 
 * 統計：
 * - GET  /stats               統計資訊
 * - GET  /frequencies         頻率常數
 * 
 * Author: MR.liou × Claude
 * Philosophy: 怎麼過去，就怎麼回來
 */

import { KvD1SyncEngine } from './kv-d1-sync';
import { UnifiedResourceHub } from './unified-resource-hub';
import { 
  ORIGIN, 
  VERSION, 
  FREQ, 
  ConflictResolution, 
  Layer, 
  SoTSource,
  ResourceQueryRequest,
  BatchSyncRequest
} from './types';

// ============================================
// 環境介面
// ============================================

interface Env {
  MRLIOUWORD_VAULT: KVNamespace;
  MRLIOUWORD_DB: D1Database;
  MRLIOUBOOK?: R2Bucket;
  MASTER_KEY?: string;
}

// ============================================
// CORS 與回應工具
// ============================================

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Master-Key, X-Batch-Id',
  'Content-Type': 'application/json',
  'X-Origin-Signature': ORIGIN,
  'X-Version': VERSION
};

function jsonResponse(data: any, status: number = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: corsHeaders
  });
}

function errorResponse(message: string, status: number = 400): Response {
  return jsonResponse({
    success: false,
    error: message,
    origin: ORIGIN,
    timestamp: Date.now()
  }, status);
}

// ============================================
// 路由處理
// ============================================

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;
    
    // CORS 預檢
    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }
    
    // 認證檢查（可選）
    const masterKey = request.headers.get('X-Master-Key');
    if (env.MASTER_KEY && masterKey !== env.MASTER_KEY) {
      // 允許部分公開端點
      const publicPaths = ['/', '/status', '/health', '/frequencies'];
      if (!publicPaths.includes(path)) {
        return errorResponse('Unauthorized', 401);
      }
    }
    
    // 初始化服務
    const syncEngine = new KvD1SyncEngine(env);
    const resourceHub = new UnifiedResourceHub(env);
    
    // 解析 JSON body
    const getBody = async () => {
      try {
        return await request.json();
      } catch {
        return {};
      }
    };
    
    try {
      // ========================================
      // 系統端點
      // ========================================
      
      if (path === '/' && method === 'GET') {
        return jsonResponse({
          name: 'MrLiouWord Unified Resource System',
          version: VERSION,
          philosophy: '怎麼過去，就怎麼回來',
          features: {
            sot: 'Source of Truth - 明確來源權威',
            revision: 'Monotonic Version Line - 單調版本線',
            resume: 'Idempotent Resume - 冪等續跑',
            conflicts: 'Conflict Audit - 衝突審計'
          },
          endpoints: {
            system: ['GET /', 'GET /status', 'GET /health'],
            resources: [
              'GET /resources',
              'GET /resources/:id',
              'POST /resources',
              'DELETE /resources/:id',
              'GET /resources/:id/history'
            ],
            sync: [
              'POST /sync/batch',
              'GET /sync/status',
              'GET /sync/status/:batchId'
            ],
            conflicts: [
              'GET /conflicts',
              'POST /conflicts/:id/resolve'
            ],
            stats: ['GET /stats', 'GET /frequencies']
          },
          layers: Object.keys(FREQ),
          origin: ORIGIN
        });
      }
      
      if (path === '/status' && method === 'GET') {
        const syncStatus = await resourceHub.getSyncStatus();
        return jsonResponse({
          status: 'operational',
          version: VERSION,
          ...syncStatus.data,
          origin: ORIGIN,
          timestamp: Date.now()
        });
      }
      
      if (path === '/health' && method === 'GET') {
        return jsonResponse({
          healthy: true,
          version: VERSION,
          origin: ORIGIN,
          timestamp: Date.now()
        });
      }
      
      if (path === '/frequencies' && method === 'GET') {
        return jsonResponse({
          frequencies: FREQ,
          schumann: 7.83,
          phi: 1.618033988749895,
          layers: {
            'L∞': '頻率源層 - 宇宙源頭',
            'L7': '語意記憶層 - 智慧整合',
            'L6': '系統映像層 - 意識循環',
            'L5': '人格策略層 - 人格模組',
            'L4': '拓撲跳點層 - 跳躍連結',
            'L3': '封裝層 - Package',
            'L2': '原型模組層 - ProtoModule',
            'L1': '原子粒子層 - atom_t/δP₀',
            'L0': '雲端平台層 - API 介面'
          },
          origin: ORIGIN
        });
      }
      
      // ========================================
      // 資源端點
      // ========================================
      
      // 查詢資源
      if (path === '/resources' && method === 'GET') {
        const query: ResourceQueryRequest = {
          type: url.searchParams.get('type') || undefined,
          layer: (url.searchParams.get('layer') as Layer) || undefined,
          sot: (url.searchParams.get('sot') as SoTSource) || undefined,
          sync_status: url.searchParams.get('sync_status') as any || undefined,
          rev_min: url.searchParams.get('rev_min') ? parseInt(url.searchParams.get('rev_min')!) : undefined,
          rev_max: url.searchParams.get('rev_max') ? parseInt(url.searchParams.get('rev_max')!) : undefined,
          limit: url.searchParams.get('limit') ? parseInt(url.searchParams.get('limit')!) : 50,
          offset: url.searchParams.get('offset') ? parseInt(url.searchParams.get('offset')!) : 0,
          include_deleted: url.searchParams.get('include_deleted') === 'true'
        };
        
        const result = await resourceHub.queryResources(query);
        return jsonResponse(result);
      }
      
      // 依標籤查詢
      if (path === '/resources/by-tags' && method === 'GET') {
        const tags = url.searchParams.get('tags')?.split(',').map(t => t.trim()) || [];
        const matchAll = url.searchParams.get('match_all') === 'true';
        const result = await resourceHub.queryByTags(tags, matchAll);
        return jsonResponse(result);
      }
      
      // 取得單一資源
      const resourceMatch = path.match(/^\/resources\/([^\/]+)$/);
      if (resourceMatch && method === 'GET') {
        const id = resourceMatch[1];
        const includeDeleted = url.searchParams.get('include_deleted') === 'true';
        const result = await resourceHub.getResource(id, includeDeleted);
        if (!result.success) {
          return errorResponse(result.error?.message || 'Not found', 404);
        }
        return jsonResponse(result);
      }
      
      // 取得版本歷史
      const historyMatch = path.match(/^\/resources\/([^\/]+)\/history$/);
      if (historyMatch && method === 'GET') {
        const id = historyMatch[1];
        const limit = url.searchParams.get('limit') ? parseInt(url.searchParams.get('limit')!) : 20;
        const result = await resourceHub.getVersionHistory(id, limit);
        return jsonResponse(result);
      }
      
      // 建立/更新資源
      if (path === '/resources' && method === 'POST') {
        const body = await getBody();
        const batchId = request.headers.get('X-Batch-Id') || undefined;
        const conflictResolution = (body.conflict_resolution as ConflictResolution) || 'SOT_WINS';
        
        const result = await resourceHub.upsertResource(body, batchId, conflictResolution);
        if (!result.success) {
          return errorResponse(result.error?.message || 'Failed to create resource', 400);
        }
        return jsonResponse(result, 201);
      }
      
      // 刪除資源
      if (resourceMatch && method === 'DELETE') {
        const id = resourceMatch[1];
        const result = await resourceHub.deleteResource(id);
        if (!result.success) {
          return errorResponse(result.error?.message || 'Failed to delete', 400);
        }
        return jsonResponse(result);
      }
      
      // ========================================
      // 同步端點
      // ========================================
      
      // 批次同步
      if (path === '/sync/batch' && method === 'POST') {
        const body: BatchSyncRequest = await getBody();
        
        if (!body.batch_id) {
          return errorResponse('batch_id is required');
        }
        if (!body.resources || !Array.isArray(body.resources)) {
          return errorResponse('resources array is required');
        }
        
        const result = await syncEngine.batchSync(body);
        return jsonResponse(result);
      }
      
      // 同步狀態
      if (path === '/sync/status' && method === 'GET') {
        const result = await syncEngine.getSyncStatus();
        return jsonResponse(result);
      }
      
      // 批次同步狀態
      const syncStatusMatch = path.match(/^\/sync\/status\/([^\/]+)$/);
      if (syncStatusMatch && method === 'GET') {
        const batchId = syncStatusMatch[1];
        const result = await syncEngine.getSyncStatus(batchId);
        return jsonResponse(result);
      }
      
      // ========================================
      // 衝突端點
      // ========================================
      
      // 查詢衝突
      if (path === '/conflicts' && method === 'GET') {
        const resolved = url.searchParams.get('resolved');
        const resolvedFilter = resolved === 'true' ? true : resolved === 'false' ? false : undefined;
        const result = await syncEngine.getConflicts(resolvedFilter);
        return jsonResponse({
          success: true,
          data: result,
          origin: ORIGIN
        });
      }
      
      // 解決衝突
      const conflictResolveMatch = path.match(/^\/conflicts\/([^\/]+)\/resolve$/);
      if (conflictResolveMatch && method === 'POST') {
        const conflictId = conflictResolveMatch[1];
        const body = await getBody();
        
        if (!body.resolution || !body.winner) {
          return errorResponse('resolution and winner are required');
        }
        
        await syncEngine.resolveConflict(conflictId, body.resolution, body.winner);
        return jsonResponse({
          success: true,
          message: 'Conflict resolved',
          origin: ORIGIN
        });
      }
      
      // ========================================
      // 統計端點
      // ========================================
      
      if (path === '/stats' && method === 'GET') {
        const result = await resourceHub.getStats();
        return jsonResponse(result);
      }
      
      // ========================================
      // 清理端點
      // ========================================
      
      if (path === '/cleanup' && method === 'POST') {
        const result = await syncEngine.cleanup();
        return jsonResponse({
          success: true,
          ...result,
          origin: ORIGIN
        });
      }
      
      // ========================================
      // 404
      // ========================================
      
      return errorResponse('Not Found', 404);
      
    } catch (e: any) {
      console.error('Worker error:', e);
      return jsonResponse({
        success: false,
        error: e.message || 'Internal Server Error',
        stack: e.stack,
        origin: ORIGIN,
        timestamp: Date.now()
      }, 500);
    }
  }
};
