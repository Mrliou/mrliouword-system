/**
 * MrLiouWord KV-D1 Sync Engine v2.0
 * 
 * 核心改進：
 * 1. SoT (Source of Truth): 明確來源權威，避免互相覆寫
 * 2. Revision: 單調版本線，防止版本倒退
 * 3. Resume: 冪等續跑機制，支援斷點恢復
 * 4. Conflicts: 衝突審計記錄，完整決策追蹤
 * 
 * Author: MR.liou × Claude
 * Philosophy: 怎麼過去，就怎麼回來
 */

import {
  ORIGIN,
  SoTSource,
  SyncStatus,
  SyncOperation,
  ConflictRecord,
  ConflictResolution,
  ErrorCategory,
  TraceLog,
  SyncStatusReport,
  BatchSyncRequest,
  BatchSyncResponse,
  MemoryEntry,
  ParticleEntry,
  generateIdempotencyKey,
  isVersionMonotonic,
  Layer,
  FREQ
} from './types';

// ============================================
// Cloudflare 環境介面
// ============================================

interface Env {
  MRLIOUWORD_VAULT: KVNamespace;
  MRLIOUWORD_DB: D1Database;
  MRLIOUBOOK?: R2Bucket;
}

// ============================================
// 工具函數
// ============================================

function uuid(): string {
  return crypto.randomUUID();
}

async function simHash64(content: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(content);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = new Uint8Array(hashBuffer);
  return Array.from(hashArray.slice(0, 8))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function now(): number {
  return Date.now();
}

// ============================================
// 追蹤日誌類別
// ============================================

class TraceLogger {
  private logs: TraceLog[] = [];
  private db: D1Database;
  
  constructor(db: D1Database) {
    this.db = db;
  }
  
  async log(
    level: TraceLog['level'],
    category: string,
    message: string,
    context?: TraceLog['context']
  ): Promise<void> {
    const entry: TraceLog = {
      id: uuid(),
      timestamp: now(),
      level,
      category,
      message,
      context,
      origin: ORIGIN
    };
    
    this.logs.push(entry);
    
    // 異步寫入 D1
    try {
      await this.db.prepare(`
        INSERT INTO trace_log (id, timestamp, level, category, message, resource_id, batch_id, operation, error_category, stack_trace, metadata, origin)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        entry.id,
        entry.timestamp,
        entry.level,
        entry.category,
        entry.message,
        context?.resource_id || null,
        context?.batch_id || null,
        context?.operation || null,
        context?.error_category || null,
        context?.stack_trace || null,
        context?.metadata ? JSON.stringify(context.metadata) : null,
        ORIGIN
      ).run();
    } catch (e) {
      console.error('TraceLogger write failed:', e);
    }
  }
  
  debug(category: string, message: string, context?: TraceLog['context']) {
    return this.log('DEBUG', category, message, context);
  }
  
  info(category: string, message: string, context?: TraceLog['context']) {
    return this.log('INFO', category, message, context);
  }
  
  warn(category: string, message: string, context?: TraceLog['context']) {
    return this.log('WARN', category, message, context);
  }
  
  error(category: string, message: string, context?: TraceLog['context']) {
    return this.log('ERROR', category, message, context);
  }
  
  getRecentLogs(): TraceLog[] {
    return this.logs.slice(-100);
  }
}

// ============================================
// 冪等性管理器
// ============================================

class IdempotencyManager {
  private db: D1Database;
  private expirationMs: number = 24 * 60 * 60 * 1000; // 24 小時
  
  constructor(db: D1Database) {
    this.db = db;
  }
  
  async check(key: string): Promise<{ exists: boolean; result?: any }> {
    const record = await this.db.prepare(`
      SELECT result, expires_at FROM idempotency_records WHERE idempotency_key = ?
    `).bind(key).first();
    
    if (record && (record.expires_at as number) > now()) {
      return { exists: true, result: JSON.parse(record.result as string) };
    }
    
    return { exists: false };
  }
  
  async record(key: string, batchId: string, resourceId: string, operation: string, result: any): Promise<void> {
    await this.db.prepare(`
      INSERT OR REPLACE INTO idempotency_records (idempotency_key, batch_id, resource_id, operation, result, created_at, expires_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      key,
      batchId,
      resourceId,
      operation,
      JSON.stringify(result),
      now(),
      now() + this.expirationMs
    ).run();
  }
  
  async cleanup(): Promise<number> {
    const result = await this.db.prepare(`
      DELETE FROM idempotency_records WHERE expires_at < ?
    `).bind(now()).run();
    return result.meta?.changes || 0;
  }
}

// ============================================
// 衝突管理器
// ============================================

class ConflictManager {
  private db: D1Database;
  private logger: TraceLogger;
  
  constructor(db: D1Database, logger: TraceLogger) {
    this.db = db;
    this.logger = logger;
  }
  
  async detect(
    resourceId: string,
    resourceType: string,
    sourceA: SoTSource,
    sourceB: SoTSource,
    revA: number,
    revB: number,
    hashA: string,
    hashB: string,
    dataA?: any,
    dataB?: any
  ): Promise<ConflictRecord> {
    const conflict: ConflictRecord = {
      id: uuid(),
      resource_id: resourceId,
      resource_type: resourceType,
      source_a: sourceA,
      source_b: sourceB,
      rev_a: revA,
      rev_b: revB,
      content_hash_a: hashA,
      content_hash_b: hashB,
      detected_at: now(),
      audit_log: [`[${new Date().toISOString()}] Conflict detected: ${sourceA}@rev${revA} vs ${sourceB}@rev${revB}`]
    };
    
    await this.db.prepare(`
      INSERT INTO conflicts (id, resource_id, resource_type, source_a, source_b, rev_a, rev_b, content_hash_a, content_hash_b, data_a, data_b, detected_at, audit_log)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      conflict.id,
      conflict.resource_id,
      conflict.resource_type,
      conflict.source_a,
      conflict.source_b,
      conflict.rev_a,
      conflict.rev_b,
      conflict.content_hash_a,
      conflict.content_hash_b,
      dataA ? JSON.stringify(dataA) : null,
      dataB ? JSON.stringify(dataB) : null,
      conflict.detected_at,
      JSON.stringify(conflict.audit_log)
    ).run();
    
    await this.logger.warn('CONFLICT', `Conflict detected for ${resourceType}:${resourceId}`, {
      resource_id: resourceId,
      error_category: 'CONFLICT_DETECTED'
    });
    
    return conflict;
  }
  
  async resolve(
    conflictId: string,
    resolution: ConflictResolution,
    winner: SoTSource,
    resolvedBy: string = 'system'
  ): Promise<void> {
    const timestamp = now();
    
    // 取得現有審計日誌
    const existing = await this.db.prepare(`
      SELECT audit_log FROM conflicts WHERE id = ?
    `).bind(conflictId).first();
    
    const auditLog: string[] = existing?.audit_log 
      ? JSON.parse(existing.audit_log as string) 
      : [];
    auditLog.push(`[${new Date().toISOString()}] Resolved: ${resolution}, winner=${winner}, by=${resolvedBy}`);
    
    await this.db.prepare(`
      UPDATE conflicts SET resolution = ?, resolved_at = ?, resolved_by = ?, winner = ?, audit_log = ?
      WHERE id = ?
    `).bind(resolution, timestamp, resolvedBy, winner, JSON.stringify(auditLog), conflictId).run();
    
    await this.logger.info('CONFLICT', `Conflict ${conflictId} resolved: ${resolution}`, {
      resource_id: conflictId,
      metadata: { resolution, winner, resolvedBy }
    });
  }
  
  async getUnresolved(limit: number = 50): Promise<ConflictRecord[]> {
    const results = await this.db.prepare(`
      SELECT * FROM conflicts WHERE resolved_at IS NULL ORDER BY detected_at DESC LIMIT ?
    `).bind(limit).all();
    
    return results.results.map(r => ({
      ...r,
      audit_log: JSON.parse(r.audit_log as string || '[]')
    })) as ConflictRecord[];
  }
}

// ============================================
// 版本管理器
// ============================================

class VersionManager {
  private db: D1Database;
  private logger: TraceLogger;
  
  constructor(db: D1Database, logger: TraceLogger) {
    this.db = db;
    this.logger = logger;
  }
  
  async getCurrentVersion(resourceId: string, table: string): Promise<number> {
    const result = await this.db.prepare(`
      SELECT rev FROM ${table} WHERE id = ? ORDER BY rev DESC LIMIT 1
    `).bind(resourceId).first();
    return (result?.rev as number) || 0;
  }
  
  async validateVersion(resourceId: string, table: string, newRev: number): Promise<boolean> {
    const currentRev = await this.getCurrentVersion(resourceId, table);
    return isVersionMonotonic(currentRev, newRev);
  }
  
  async recordHistory(
    resourceId: string,
    resourceType: string,
    rev: number,
    prevRev: number | null,
    contentHash: string,
    dataSnapshot: any,
    changeType: 'CREATE' | 'UPDATE' | 'DELETE' | 'RESTORE',
    changedBy: string = 'system'
  ): Promise<void> {
    await this.db.prepare(`
      INSERT INTO version_history (resource_id, resource_type, rev, prev_rev, content_hash, data_snapshot, change_type, changed_by, changed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      resourceId,
      resourceType,
      rev,
      prevRev,
      contentHash,
      JSON.stringify(dataSnapshot),
      changeType,
      changedBy,
      now()
    ).run();
  }
  
  async getHistory(resourceId: string, limit: number = 20): Promise<any[]> {
    const results = await this.db.prepare(`
      SELECT * FROM version_history WHERE resource_id = ? ORDER BY rev DESC LIMIT ?
    `).bind(resourceId, limit).all();
    
    return results.results.map(r => ({
      ...r,
      data_snapshot: JSON.parse(r.data_snapshot as string || '{}')
    }));
  }
}

// ============================================
// KV-D1 同步引擎
// ============================================

export class KvD1SyncEngine {
  private kv: KVNamespace;
  private db: D1Database;
  private logger: TraceLogger;
  private idempotency: IdempotencyManager;
  private conflicts: ConflictManager;
  private versions: VersionManager;
  
  // 來源權威配置
  private sotConfig: Record<string, SoTSource> = {
    memories: 'D1',
    particles: 'D1',
    personas: 'D1',
    absorbed: 'D1',
    unified_resources: 'D1'
  };
  
  constructor(env: Env) {
    this.kv = env.MRLIOUWORD_VAULT;
    this.db = env.MRLIOUWORD_DB;
    this.logger = new TraceLogger(this.db);
    this.idempotency = new IdempotencyManager(this.db);
    this.conflicts = new ConflictManager(this.db, this.logger);
    this.versions = new VersionManager(this.db, this.logger);
  }
  
  // ========================================
  // 記憶同步
  // ========================================
  
  async syncMemory(
    batchId: string,
    memory: Partial<MemoryEntry> & { id: string; content: string },
    operation: 'CREATE' | 'UPDATE' | 'DELETE',
    conflictResolution: ConflictResolution = 'SOT_WINS'
  ): Promise<SyncOperation> {
    const idempotencyKey = generateIdempotencyKey(batchId, memory.id, operation);
    const sot = this.sotConfig.memories;
    
    // 冪等檢查
    const existing = await this.idempotency.check(idempotencyKey);
    if (existing.exists) {
      await this.logger.info('SYNC', `Idempotent skip for memory ${memory.id}`, {
        batch_id: batchId,
        resource_id: memory.id,
        operation
      });
      return {
        ...existing.result,
        status: 'SKIPPED' as SyncStatus
      };
    }
    
    const syncOp: SyncOperation = {
      id: uuid(),
      batch_id: batchId,
      source: sot,
      target: sot === 'D1' ? 'KV' : 'D1',
      resource_id: memory.id,
      resource_type: 'memory',
      operation,
      source_rev: memory.rev || 1,
      status: 'SYNCING',
      started_at: now(),
      idempotency_key: idempotencyKey
    };
    
    try {
      // 版本驗證
      const currentRev = await this.versions.getCurrentVersion(memory.id, 'memories');
      const newRev = (memory.rev || currentRev) + 1;
      
      if (operation !== 'CREATE' && !isVersionMonotonic(currentRev, newRev)) {
        throw {
          category: 'VERSION_MISMATCH' as ErrorCategory,
          message: `Version mismatch: current=${currentRev}, attempted=${newRev}`
        };
      }
      
      // 計算內容雜湊
      const contentHash = await simHash64(memory.content);
      
      // 檢查 KV 中是否有不同版本
      const kvKey = `memory:${memory.id}`;
      const kvData = await this.kv.get(kvKey, 'json') as MemoryEntry | null;
      
      if (kvData && kvData.current_hash !== contentHash && kvData.rev >= newRev) {
        // 衝突檢測
        const conflict = await this.conflicts.detect(
          memory.id,
          'memory',
          'KV',
          'D1',
          kvData.rev,
          newRev,
          kvData.current_hash,
          contentHash,
          kvData,
          memory
        );
        
        if (conflictResolution === 'SOT_WINS') {
          // D1 為 SoT，忽略 KV 版本
          await this.conflicts.resolve(conflict.id, 'SOT_WINS', 'D1');
        } else if (conflictResolution === 'LATEST_WINS' && kvData.rev > newRev) {
          // KV 版本更新，跳過同步
          syncOp.status = 'CONFLICT';
          await this.conflicts.resolve(conflict.id, 'LATEST_WINS', 'KV');
          throw {
            category: 'CONFLICT_DETECTED' as ErrorCategory,
            message: 'KV has newer version, sync skipped'
          };
        }
      }
      
      // 構建完整記憶條目
      const fullMemory: MemoryEntry = {
        id: memory.id,
        rev: newRev,
        sot,
        content: memory.content,
        type: memory.type || 'general',
        tags: memory.tags || [],
        prev_hash: kvData?.current_hash || '',
        current_hash: contentHash,
        timestamp: now(),
        sync_status: 'SYNCED',
        layer: memory.layer || 'L1'
      };
      
      // 寫入 D1（SoT）
      if (operation === 'CREATE' || operation === 'UPDATE') {
        await this.db.prepare(`
          INSERT OR REPLACE INTO memories (id, rev, sot, content, type, prev_hash, current_hash, layer, sync_status, timestamp, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          fullMemory.id,
          fullMemory.rev,
          fullMemory.sot,
          fullMemory.content,
          fullMemory.type,
          fullMemory.prev_hash,
          fullMemory.current_hash,
          fullMemory.layer,
          fullMemory.sync_status,
          fullMemory.timestamp,
          now()
        ).run();
        
        // 同步標籤
        await this.db.prepare(`DELETE FROM memory_tags WHERE memory_id = ?`).bind(memory.id).run();
        for (const tag of fullMemory.tags) {
          await this.db.prepare(`
            INSERT INTO memory_tags (memory_id, tag, created_at) VALUES (?, ?, ?)
          `).bind(memory.id, tag, now()).run();
        }
      } else if (operation === 'DELETE') {
        await this.db.prepare(`
          UPDATE memories SET deleted_at = ?, sync_status = 'SYNCED', updated_at = ? WHERE id = ?
        `).bind(now(), now(), memory.id).run();
      }
      
      // 同步到 KV
      if (operation === 'DELETE') {
        await this.kv.delete(kvKey);
      } else {
        await this.kv.put(kvKey, JSON.stringify(fullMemory));
      }
      
      // 記錄版本歷史
      await this.versions.recordHistory(
        memory.id,
        'memory',
        newRev,
        currentRev || null,
        contentHash,
        fullMemory,
        operation === 'CREATE' ? 'CREATE' : operation === 'DELETE' ? 'DELETE' : 'UPDATE'
      );
      
      syncOp.status = 'SYNCED';
      syncOp.target_rev = newRev;
      syncOp.completed_at = now();
      
      await this.logger.info('SYNC', `Memory ${memory.id} synced successfully`, {
        batch_id: batchId,
        resource_id: memory.id,
        operation
      });
      
    } catch (e: any) {
      syncOp.status = 'FAILED';
      syncOp.error_category = e.category || 'UNKNOWN';
      syncOp.error_message = e.message || String(e);
      syncOp.completed_at = now();
      
      await this.logger.error('SYNC', `Memory sync failed: ${e.message}`, {
        batch_id: batchId,
        resource_id: memory.id,
        operation,
        error_category: syncOp.error_category,
        stack_trace: e.stack
      });
    }
    
    // 記錄同步操作
    await this.db.prepare(`
      INSERT INTO sync_operations (id, batch_id, source, target, resource_id, resource_type, operation, source_rev, target_rev, status, error_category, error_message, idempotency_key, started_at, completed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      syncOp.id,
      syncOp.batch_id,
      syncOp.source,
      syncOp.target,
      syncOp.resource_id,
      syncOp.resource_type,
      syncOp.operation,
      syncOp.source_rev,
      syncOp.target_rev || null,
      syncOp.status,
      syncOp.error_category || null,
      syncOp.error_message || null,
      syncOp.idempotency_key,
      syncOp.started_at,
      syncOp.completed_at || null
    ).run();
    
    // 記錄冪等結果
    await this.idempotency.record(idempotencyKey, batchId, memory.id, operation, syncOp);
    
    return syncOp;
  }
  
  // ========================================
  // 粒子同步
  // ========================================
  
  async syncParticle(
    batchId: string,
    particle: Partial<ParticleEntry> & { id: string; 型態: string; data: any },
    operation: 'CREATE' | 'UPDATE' | 'DELETE',
    conflictResolution: ConflictResolution = 'SOT_WINS'
  ): Promise<SyncOperation> {
    const idempotencyKey = generateIdempotencyKey(batchId, particle.id, operation);
    const sot = this.sotConfig.particles;
    
    // 冪等檢查
    const existing = await this.idempotency.check(idempotencyKey);
    if (existing.exists) {
      return { ...existing.result, status: 'SKIPPED' as SyncStatus };
    }
    
    const syncOp: SyncOperation = {
      id: uuid(),
      batch_id: batchId,
      source: sot,
      target: sot === 'D1' ? 'KV' : 'D1',
      resource_id: particle.id,
      resource_type: 'particle',
      operation,
      source_rev: particle.rev || 1,
      status: 'SYNCING',
      started_at: now(),
      idempotency_key: idempotencyKey
    };
    
    try {
      const currentRev = await this.versions.getCurrentVersion(particle.id, 'particles');
      const newRev = (particle.rev || currentRev) + 1;
      
      if (operation !== 'CREATE' && !isVersionMonotonic(currentRev, newRev)) {
        throw {
          category: 'VERSION_MISMATCH' as ErrorCategory,
          message: `Version mismatch: current=${currentRev}, attempted=${newRev}`
        };
      }
      
      const layer = particle.layer || 'L1';
      const freq = FREQ[layer] || 7.83;
      
      const fullParticle: ParticleEntry = {
        id: particle.id,
        rev: newRev,
        sot,
        型態: particle.型態,
        data: particle.data,
        embedding: particle.embedding,
        layer,
        freq,
        timestamp: now(),
        sync_status: 'SYNCED'
      };
      
      // 寫入 D1
      if (operation === 'CREATE' || operation === 'UPDATE') {
        await this.db.prepare(`
          INSERT OR REPLACE INTO particles (id, rev, sot, type, data, layer, freq, sync_status, timestamp, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          fullParticle.id,
          fullParticle.rev,
          fullParticle.sot,
          fullParticle.型態,
          JSON.stringify(fullParticle.data),
          fullParticle.layer,
          fullParticle.freq,
          fullParticle.sync_status,
          fullParticle.timestamp,
          now()
        ).run();
      } else if (operation === 'DELETE') {
        await this.db.prepare(`
          UPDATE particles SET deleted_at = ?, sync_status = 'SYNCED', updated_at = ? WHERE id = ?
        `).bind(now(), now(), particle.id).run();
      }
      
      // 同步到 KV
      const kvKey = `particle:${particle.id}`;
      if (operation === 'DELETE') {
        await this.kv.delete(kvKey);
      } else {
        await this.kv.put(kvKey, JSON.stringify(fullParticle));
      }
      
      // 記錄版本歷史
      await this.versions.recordHistory(
        particle.id,
        'particle',
        newRev,
        currentRev || null,
        await simHash64(JSON.stringify(particle.data)),
        fullParticle,
        operation === 'CREATE' ? 'CREATE' : operation === 'DELETE' ? 'DELETE' : 'UPDATE'
      );
      
      syncOp.status = 'SYNCED';
      syncOp.target_rev = newRev;
      syncOp.completed_at = now();
      
    } catch (e: any) {
      syncOp.status = 'FAILED';
      syncOp.error_category = e.category || 'UNKNOWN';
      syncOp.error_message = e.message || String(e);
      syncOp.completed_at = now();
    }
    
    await this.db.prepare(`
      INSERT INTO sync_operations (id, batch_id, source, target, resource_id, resource_type, operation, source_rev, target_rev, status, error_category, error_message, idempotency_key, started_at, completed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      syncOp.id, syncOp.batch_id, syncOp.source, syncOp.target, syncOp.resource_id,
      syncOp.resource_type, syncOp.operation, syncOp.source_rev, syncOp.target_rev || null,
      syncOp.status, syncOp.error_category || null, syncOp.error_message || null,
      syncOp.idempotency_key, syncOp.started_at, syncOp.completed_at || null
    ).run();
    
    await this.idempotency.record(idempotencyKey, batchId, particle.id, operation, syncOp);
    
    return syncOp;
  }
  
  // ========================================
  // 批次同步
  // ========================================
  
  async batchSync(request: BatchSyncRequest): Promise<BatchSyncResponse> {
    const report: SyncStatusReport = {
      batch_id: request.batch_id,
      total_operations: request.resources.length,
      completed: 0,
      failed: 0,
      conflicts: 0,
      skipped: 0,
      started_at: now(),
      operations: [],
      conflicts_details: []
    };
    
    await this.logger.info('BATCH_SYNC', `Starting batch sync: ${request.batch_id}`, {
      batch_id: request.batch_id,
      metadata: { total: request.resources.length }
    });
    
    for (const resource of request.resources) {
      let syncOp: SyncOperation;
      
      // 根據資源類型路由
      if (resource.data?.type === 'memory' || resource.data?.content) {
        syncOp = await this.syncMemory(
          request.batch_id,
          { id: resource.id, ...resource.data },
          resource.operation,
          request.conflict_resolution
        );
      } else {
        syncOp = await this.syncParticle(
          request.batch_id,
          { id: resource.id, 型態: resource.data?.型態 || 'unknown', ...resource.data },
          resource.operation,
          request.conflict_resolution
        );
      }
      
      report.operations.push(syncOp);
      
      switch (syncOp.status) {
        case 'SYNCED':
          report.completed++;
          break;
        case 'FAILED':
          report.failed++;
          break;
        case 'CONFLICT':
          report.conflicts++;
          break;
        case 'SKIPPED':
          report.skipped++;
          break;
      }
    }
    
    report.completed_at = now();
    
    // 獲取衝突詳情
    report.conflicts_details = await this.conflicts.getUnresolved(50);
    
    await this.logger.info('BATCH_SYNC', `Batch sync completed: ${request.batch_id}`, {
      batch_id: request.batch_id,
      metadata: {
        completed: report.completed,
        failed: report.failed,
        conflicts: report.conflicts,
        skipped: report.skipped
      }
    });
    
    return {
      success: report.failed === 0,
      batch_id: request.batch_id,
      report,
      origin: ORIGIN
    };
  }
  
  // ========================================
  // 狀態查詢
  // ========================================
  
  async getSyncStatus(batchId?: string): Promise<any> {
    if (batchId) {
      const operations = await this.db.prepare(`
        SELECT * FROM sync_operations WHERE batch_id = ? ORDER BY started_at DESC
      `).bind(batchId).all();
      
      return {
        batch_id: batchId,
        operations: operations.results,
        origin: ORIGIN
      };
    }
    
    const stats = await this.db.prepare(`
      SELECT 
        status,
        COUNT(*) as count,
        MAX(completed_at) as last_completed
      FROM sync_operations
      GROUP BY status
    `).all();
    
    const unresolvedConflicts = await this.conflicts.getUnresolved(10);
    
    return {
      sync_stats: stats.results,
      unresolved_conflicts: unresolvedConflicts.length,
      recent_conflicts: unresolvedConflicts,
      origin: ORIGIN
    };
  }
  
  // ========================================
  // 衝突管理
  // ========================================
  
  async getConflicts(resolved?: boolean): Promise<ConflictRecord[]> {
    if (resolved === undefined) {
      const results = await this.db.prepare(`
        SELECT * FROM conflicts ORDER BY detected_at DESC LIMIT 100
      `).all();
      return results.results.map(r => ({
        ...r,
        audit_log: JSON.parse(r.audit_log as string || '[]')
      })) as ConflictRecord[];
    }
    
    const results = await this.db.prepare(`
      SELECT * FROM conflicts WHERE ${resolved ? 'resolved_at IS NOT NULL' : 'resolved_at IS NULL'} ORDER BY detected_at DESC LIMIT 100
    `).all();
    
    return results.results.map(r => ({
      ...r,
      audit_log: JSON.parse(r.audit_log as string || '[]')
    })) as ConflictRecord[];
  }
  
  async resolveConflict(conflictId: string, resolution: ConflictResolution, winner: SoTSource): Promise<void> {
    await this.conflicts.resolve(conflictId, resolution, winner);
  }
  
  // ========================================
  // 版本歷史
  // ========================================
  
  async getVersionHistory(resourceId: string): Promise<any[]> {
    return this.versions.getHistory(resourceId);
  }
  
  // ========================================
  // 清理
  // ========================================
  
  async cleanup(): Promise<{ idempotency_cleaned: number }> {
    const cleaned = await this.idempotency.cleanup();
    return { idempotency_cleaned: cleaned };
  }
}

export default KvD1SyncEngine;
