# FlowPersona.FusionEngine.Core

T時間軸: -1
X維座標: 1
Y維座標: -1
Z維座標: -1
子分類: 人格系統
最後更新日期: 2025年11月25日
標籤: 文檔, 核心代碼
檔案類型: 文件
狀態: 已整理
相關檔案: Mr.liou 分析師人格 v0.1 (開發版) (Mr%20liou%20%E5%88%86%E6%9E%90%E5%B8%AB%E4%BA%BA%E6%A0%BC%20v0%201%20(%E9%96%8B%E7%99%BC%E7%89%88)%202d68eeeec5b581568199ca00b281dba4.md), Echo.Persona 與 Mr.liou 系統架構綜合分析 (Echo%20Persona%20%E8%88%87%20Mr%20liou%20%E7%B3%BB%E7%B5%B1%E6%9E%B6%E6%A7%8B%E7%B6%9C%E5%90%88%E5%88%86%E6%9E%90%202d68eeeec5b5813ba42fdd74128323c5.md)
系統層級: 人格和粒子語言層
維度標籤: 正X軸, 負Y軸, 負Z軸, 過去
路徑: /開發實驗夥伴工作室 / 粒子百科