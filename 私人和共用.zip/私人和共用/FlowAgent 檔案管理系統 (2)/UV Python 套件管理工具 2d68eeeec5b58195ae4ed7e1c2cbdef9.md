# UV Python 套件管理工具

T時間軸: 0
X維座標: 0
Y維座標: -1
Z維座標: 0
子分類: 工具、套件和頁面管理
最後更新日期: 2025年12月9日
標籤: 工具
檔案類型: 文件
狀態: 已整理
相關檔案: FlowAgent - GitHub 部署專案 (FlowAgent%20-%20GitHub%20%E9%83%A8%E7%BD%B2%E5%B0%88%E6%A1%88%202d68eeeec5b581d5967be24cce94b42b.md), Sphinx 文檔系統 (Sphinx%20%E6%96%87%E6%AA%94%E7%B3%BB%E7%B5%B1%202d68eeeec5b581d487f0ea812dd2204f.md)
系統層級: 實現層與工程層
維度標籤: 現在, 負Y軸
路徑: /開發實驗夥伴工作室 / 粒子百科/