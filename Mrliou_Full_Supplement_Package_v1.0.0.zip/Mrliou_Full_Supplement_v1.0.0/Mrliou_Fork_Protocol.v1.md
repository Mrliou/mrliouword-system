# Mrliou_Fork_Protocol.v1
origin_signature: Mrliou

## 0. Purpose
Define objective fork vs extension classification and the obligations of forks to prevent false inheritance.

## 1. Definitions
Extension (E):
- Additive changes strictly above L7
- Does not modify A (Immutable Core) nor C (Descended Substrate)
- Preserves provenance anchors and naming sovereignty

Fork (F):
- Any modification to A or C
- Any change that alters the descent mapping ↓ or redefines Σ/Ω/Φ/Λ/⊘
- Any attempt to override completion boundary, provenance rules, or evolution policy

## 2. Fork Trigger Conditions (hard)
F1: Edits/rewrites any A document
F2: Changes Closure criteria or the unique descent mapping
F3: Removes or weakens provenance/trace requirements
F4: Renames origin_signature away from "Mrliou" while claiming inheritance

## 3. Obligations
O1: Fork MUST rename itself (system_name, artifact prefix) and MUST NOT use "Mrliou" prefix for its own identity.
O2: Fork MUST cite the original completion hash + provenance reference.
O3: Fork MUST provide an explicit compatibility statement (compatible / incompatible / unknown) and list divergences.
O4: Fork MUST not claim as Mrliou Core.

## 4. Extension Obligations
E1: Must keep Mrliou prefix
E2: Must include trace anchor and reference completion hash
E3: Must be additive only above L7

## 5. Minimal Fork Record
ForkRecord := { fork_name, base_completion_hash, divergences[], created_at }
